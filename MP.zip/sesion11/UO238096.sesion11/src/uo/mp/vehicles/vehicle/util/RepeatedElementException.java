package uo.mp.vehicles.vehicle.util;

public class RepeatedElementException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RepeatedElementException() {
		super();
		
	}

	public RepeatedElementException(String msg) {
		super(msg);
		
	}
	
	
	@Override
	public String toString() {
		return "RepeatedElementException [getMessage()=" + getMessage()
				+ ", getCause()=" + getCause() + "]";
	}
	
	

}
