package uo.mp.vehicles.vehicle;

public class Truck extends Vehicle {
	private int numberOfAxles;
	private int tare;
	
	public Truck(String plate, int cc, int horsepower, int years, 
			String brand, int numberOfAxles, int tare) {
		super(plate, cc, horsepower, years, brand);
		this.numberOfAxles = numberOfAxles;
		this.tare = tare;
	}

	public int getNumberOfAxles() {
		return numberOfAxles;
	}

	public int getTare() {
		return tare;
	}

	@Override
	public String toString() {
		return "Truck [Plate= " + getPlate() 
				+ ", Cc= " + getCc() 
				+ ", Horsepower= " + getHorsepower()
				+ ", Years= " + getYears() 
				+ ", Brand= " + getBrand() 
				+ ", NumberOfAxles= " + getNumberOfAxles() 
				+ ", Tare= " + getTare() 
			+ "]";
	}

	@Override
	public double getRoadTax() {
		return 100 + numberOfAxles * 10 + getYears() * 20 + getCc() / 6;
	}

	@Override
	public String serialize() {
		return String.format("truck\t%s\t%d\t%d\t%d\t%s\t%d\t%d", 
				getPlate(), 
				getCc(),
				getHorsepower(), 
				getYears(), 
				getBrand(),
				getTare(),
				getNumberOfAxles());
				}

	}


