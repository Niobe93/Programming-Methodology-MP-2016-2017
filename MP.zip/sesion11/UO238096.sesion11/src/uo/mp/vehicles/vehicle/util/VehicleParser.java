package uo.mp.vehicles.vehicle.util;


import java.util.LinkedList;
import java.util.List;

import com.sun.media.sound.InvalidFormatException;

import uo.mp.util.Logger;
import uo.mp.vehicles.file.FileLogger;
import uo.mp.vehicles.vehicle.Car;
import uo.mp.vehicles.vehicle.Motorbike;
import uo.mp.vehicles.vehicle.Truck;
import uo.mp.vehicles.vehicle.Vehicle;

public class VehicleParser {
	private Logger logger = new FileLogger();

	public List<Vehicle> parse(List<String> lines) {
		List<Vehicle> vehicles = new LinkedList<Vehicle>();
		
		for (int ln=0; ln<lines.size(); ln++){
			String line = lines.get(ln);
			
			if (isBlankLine(line)){
				log(ln, "L�nea en blanco", line);
				continue;}	
		
			Vehicle v;			
			
		try {
			v = parseLine(line);
			this.searchRepeatedVehicle(vehicles, v);
			vehicles.add(v);
			} 
		catch ( RepeatedElementException | InvalidFormatException e) {	
			log(ln, e.getMessage(), line);} 
		}			
		return vehicles;
	}
	
	private Vehicle parseLine(String line) throws InvalidFormatException{
		String [] parts = line.split("\t");
		validNumberOfParts(parts);		
	return createVehicle(parts);}
	
		
	private Vehicle createVehicle(String [] parts) throws InvalidFormatException{
		String type = parts[0];
		String plate = parts[1];		
		int cc = toInteger(parts[2]);			
		int horsepower = toInteger(parts[3]);
		int years = toInteger(parts[4]);
		String brand = parts[5];		
		Object vehicle = null;
		
				
		if (type.equals("car"))	
			vehicle = new Car(plate, cc, horsepower, years, brand);
		    
		else if (type.equals("motorbike"))
			vehicle = new Motorbike(plate, cc, horsepower, years, brand);
		
		else if (type.equals("truck")){
			int numberOfAxles = toInteger(parts[6]);
		    int tare = toInteger(parts[7]);			
		    vehicle = new Truck(plate, cc, horsepower, years, brand,numberOfAxles, tare);}		
		else 
			throw new InvalidFormatException(type + " El tipo de veh�culo no es v�lido ");
		
		return (Vehicle)vehicle;	
		
	}
	
	private int toInteger ( String string) throws InvalidFormatException{
		try {
			return Integer.parseInt(string);}
		catch (NumberFormatException e){
			throw new InvalidFormatException(e.getMessage());			
		}		
	}
	private boolean isBlankLine(String line){
		return line==null || line.length()==0;
	}
	private void log ( int i, String error, String line){
		String msg = String.format("L�nea %d. Error con contenido %s , %s\n", i, error,line);
		logger.log(msg);
	}
	
	private void validNumberOfParts(String[]parts) throws InvalidFormatException {
		if (( parts.length <6)|(parts.length > 8)|(parts.length == 7) )		
			throw new InvalidFormatException("N�mero de campos incorrecto: " + parts.length);			
		} 
    
	private void searchRepeatedVehicle(List<Vehicle> v,Vehicle vehicle)throws RepeatedElementException   {
    	for ( Vehicle veh: v){    		   	
    	    if (vehicle.getPlate().equals(veh.getPlate())){    	    	
    		    throw new RepeatedElementException("Veh�culo repetido: " + vehicle.getPlate());}}
	
	}

}

