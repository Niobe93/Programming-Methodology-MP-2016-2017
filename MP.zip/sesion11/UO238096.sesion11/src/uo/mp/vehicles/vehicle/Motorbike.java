package uo.mp.vehicles.vehicle;

public class Motorbike extends Vehicle {

	public Motorbike(String plate, int cc, int horsepower, int years, String brand) {
		super(plate, cc, horsepower, years, brand);
	}

	@Override
	public double getRoadTax() {
		return 30 + getCc() * 0.5 + 10 * getYears();
	}

	@Override
	public String toString() {
		return "Motorbike [Plate= " + getPlate() 
				+ ", Cc= " + getCc() 
				+ ", Horsepower= " + getHorsepower()
				+ ", Years= " + getYears() 
				+ ", Brand= " + getBrand() 
			+ "]";
	}
	
	@Override
	public String serialize() {
		return String.format("motorbike\t%s\t%d\t%d\t%d\t%s", 
				getPlate(), 
				getCc(),
				getHorsepower(), 
				getYears(), 
				getBrand());
				}

	}


