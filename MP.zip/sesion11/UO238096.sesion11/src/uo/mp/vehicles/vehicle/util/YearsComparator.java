package uo.mp.vehicles.vehicle.util;

import java.util.Comparator;

import uo.mp.vehicles.vehicle.Vehicle;

public class YearsComparator implements Comparator<Vehicle>{

	@Override
	public int compare(Vehicle vehicle1, Vehicle vehicle2) {		
		return (vehicle1.getYears()-(vehicle2.getYears()));
	}
}
