package uo.mp.vehicles.vehicle.util;

public class InvalidFormatException extends Exception {

	private static final long serialVersionUID = 1L;
	
	
	public InvalidFormatException () {
		super();
	}

	public InvalidFormatException(String message) {
		super(message);
		
	}
	
	@Override
	public String toString() {
		return "InvalidFormatException [getMessage()=" + getMessage()
				+ ", getCause()=" + getCause() + "]";
	}
	
}
