package uo.mp.vehicles;



import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import uo.mp.util.Console;
import uo.mp.vehicles.parcel.DoesNotExistException;
import uo.mp.vehicles.parcel.ParcelDeliveryCompany;
import uo.mp.vehicles.ui.Menu;
import uo.mp.vehicles.ui.VehicleBuilder;
import uo.mp.vehicles.vehicle.Vehicle;
import uo.mp.vehicles.vehicle.util.InvalidFormatException;
import uo.mp.vehicles.vehicle.util.RepeatedElementException;

public class Main {
	private static final int EXIT = 0;

	private ParcelDeliveryCompany company = new ParcelDeliveryCompany(); // crea objeto compa�ia
	
	public static void main(String[] args) throws Exception {
		new Main().run();
	}

	private void run() throws Exception {
		Menu menu = new Menu();
		int option = EXIT;
		do {
			menu.show();
			option = menu.readOption();
			try {
				processOption(option);
			
			} catch (RuntimeException e){
				handleStop(e);
			} catch (Exception e) {
				handleDefault(e);
			
			}
		} while (option != EXIT);
		
		Console.println("Execution finished");
	}

	private void processOption(int option) throws RepeatedElementException, DoesNotExistException, IOException, InvalidFormatException {
		switch( option ) {
			case EXIT: return;
			case 1: loadFile(); break;
			case 2: addVehicle(); break;
			case 3: removeVehicle(); break;
			case 4: saveToFile(); break;
			case 5: importFromZip(); break;
			case 6: exportToZip(); break;
			case 7: showVehiclesByBrand(); break;
			case 8: showVehiclesByAge(); break;
			case 9: computeTotalFleetTaxes(); break;
		}
	}

	

	private void computeTotalFleetTaxes() {
		Console.printf("Total amount of taxes: %.2f\n", company.getTotalRoadTax());
	}

	private void showVehiclesByAge() {
		List<Vehicle> sorted = company.getVehiclesByYear();
		listVehicles( sorted );
	}

	private void showVehiclesByBrand() {
		List<Vehicle> sorted = company.getVehiclesByBrand();
		listVehicles( sorted );
	}

	private void exportToZip() {
		String fileName = Console.readString("output file name?");
		company.saveToZipFile( fileName );
}

	private void importFromZip() throws FileNotFoundException, RepeatedElementException {
		String fileName = Console.readString("input zip file name?");
		company.loadZipFile( fileName );
	}

      private void saveToFile() {
		String fileName = Console.readString("output file name?");
		company.saveToFile( fileName );
	}

	private void removeVehicle() throws DoesNotExistException {
		String plate = Console.readString("plate number?");
		company.removeVehicle( plate );
	}

	private void addVehicle() throws RepeatedElementException, InvalidFormatException {
		Vehicle v = new VehicleBuilder().build();
		company.addVehicle( v );
	}

	private void loadFile() throws  IOException, RepeatedElementException {
		String fileName = Console.readString("File name?");
		company.loadFile(fileName);
	}

	private void listVehicles(List<Vehicle> vehicles) {
		Console.println("\nList of vehicles");
		Console.println("------------------");
		for (Vehicle v: vehicles) {
			System.out.println( v );
		}
	}
	private void  handleDefault(Exception e){
		
		String msg = ("Se ha producido un error al procesar la operaci�n.\n" + e.getMessage() 
				+ " Resuelva el problema y ejecute de nuevo.\n");
		Console.println(msg);
	}
	
	private void handleStop(RuntimeException rte){
		String msg = ("Se ha producido un error interno al procesar la operaci�n.\n" + rte.getMessage() 
				+ " Contacte con el administrador.\n");
		Console.println(msg);
		rte.printStackTrace();
		System.exit(-1);
	}
	
	
}
