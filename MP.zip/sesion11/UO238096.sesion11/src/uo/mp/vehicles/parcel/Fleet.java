package uo.mp.vehicles.parcel;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import uo.mp.vehicles.vehicle.Vehicle;
import uo.mp.vehicles.vehicle.util.BrandComparator;
import uo.mp.vehicles.vehicle.util.RepeatedElementException;
import uo.mp.vehicles.vehicle.util.YearsComparator;


public class Fleet {
	private List<Vehicle> vehicles = new ArrayList<>();
	
	public List<Vehicle>getVehicled(){
		Collections.sort(vehicles);
		return vehicles;
	}

	public List<Vehicle> getVehicledByBrand() {
	 Sorter.sort(vehicles, new BrandComparator());
	 return vehicles;
	}

	public List<Vehicle> getVehicledByYear() {
		Sorter.sort(vehicles, new YearsComparator());
		return vehicles;
	}

	public void add(List<Vehicle> newVehicles) throws RepeatedElementException {
		checkNull(newVehicles);
		for(Vehicle v: newVehicles) {
			this.add( v );
		}
	}

	public void add(Vehicle v) throws RepeatedElementException {
		checkNull(v);
		if((searchByPlate(v.getPlate())!=-1))
			 throw new RepeatedElementException("Veh�culo Repetido");
		vehicles.add( v );
	}

	public List<Vehicle> getVehicles() {
		return new ArrayList<Vehicle>( vehicles );
	}

	public void remove(String plate) throws DoesNotExistException {
		checkNull(plate);		
		int pos = searchByPlate( plate );
		if ( pos == -1)
			 throw new DoesNotExistException("No se ha encontrado el veh�culo");
		vehicles.remove(pos);
	}

	private int searchByPlate(String plate) {
		for(int i = 0; i < vehicles.size(); i++) {
			Vehicle v = vehicles.get(i);
			if ( v.getPlate().equals( plate ) ) {
				return i;
			}
		}
		return -1;
	}
	
	private void checkNull(Object v) {
		if (v == null)
			throw new IllegalArgumentException("Error: el par�metro es null");
	}
	
	
	}

