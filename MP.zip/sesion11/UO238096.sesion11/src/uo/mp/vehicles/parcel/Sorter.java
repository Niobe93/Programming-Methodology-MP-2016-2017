package uo.mp.vehicles.parcel;

import java.util.Comparator;


import java.util.LinkedList;
import java.util.List;

import uo.mp.vehicles.vehicle.Vehicle;



public class Sorter {
	public static void sort(List<Vehicle> list) {
		List<Vehicle>tmp= new LinkedList<Vehicle>();
		for (Vehicle v : list){
			int pos = searchPosition(v,tmp);
			tmp.add(pos,v);	}
		copyFromTo(tmp, list);

	}

	public static void sort(List<Vehicle> list, Comparator<Vehicle> comparator) {
		List<Vehicle>tmp = new LinkedList<>();
		for (Vehicle v : list){
			int pos = searchPosition(v,tmp, comparator);
			tmp.add(pos,v);	}
		copyFromTo(tmp, list);
	}
	
	
	private static int searchPosition(Vehicle v, List<Vehicle> tmp,	Comparator<Vehicle> comparator) {
		for (int i = 0; i < tmp.size(); i++){
			 Vehicle current = tmp.get(i);
			 if (comparator.compare(v,current) <0){
				 return i; }
			}			 
		return tmp.size();	}
	

	private static void copyFromTo(List<Vehicle> fromInitial, List<Vehicle> toFinal) {
		toFinal.clear();
		for(Vehicle v: fromInitial) {
			toFinal.add( v );}
	}
	
	private static int searchPosition(Vehicle v, List<Vehicle>tmp){
		for (int i = 0; i < tmp.size(); i++){
		 Vehicle current = tmp.get(i);
		 if ( v.compareTo(current)<0)
			 return i;
		}			 
	return tmp.size();}

}
