package uo.mp.vehicles.parcel;

import java.util.Comparator;

import uo.mp.collection.List;
import uo.mp.list.LinkedList;
import uo.mp.vehicles.vehicle.Vehicle;



public class Sorter {
	public static void sort(List<Vehicle> list) {
		
		copyFromTo(tmp, list);

	}

	public static void sort(List<Vehicle> list, Comparator<Vehicle> comparator) {
		
		copyFromTo(tmp, list);

	}
	
	
	
	private static void copyFromTo(List<Vehicle> fromInitial, List<Vehicle> toFinal) {
		toFinal.clear();
		for(Vehicle v: fromInitial) {
			toFinal.add( v );
		}
	}


}
