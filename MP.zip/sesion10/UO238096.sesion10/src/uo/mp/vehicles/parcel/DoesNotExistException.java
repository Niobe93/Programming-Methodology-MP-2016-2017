package uo.mp.vehicles.parcel;

public class DoesNotExistException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DoesNotExistException() {
		super();
	}

	public DoesNotExistException(String message) {
		super(message);
		
	}

	@Override
	public String toString() {
		return "DoesNotExistException [getMessage()=" + getMessage()
				+ ", getCause()=" + getCause() + "]";
	}
	
	

}
