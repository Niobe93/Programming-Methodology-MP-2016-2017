package uo.mp.vehicles;


import java.util.List;

import uo.mp.util.Console;
import uo.mp.vehicles.parcel.DoesNotExistException;
import uo.mp.vehicles.parcel.ParcelDeliveryCompany;
import uo.mp.vehicles.parcel.RepeatedElementException;
import uo.mp.vehicles.ui.Menu;
import uo.mp.vehicles.ui.VehicleBuilder;
import uo.mp.vehicles.vehicle.Vehicle;

public class Main {
	private static final int EXIT = 0;

	private ParcelDeliveryCompany company = new ParcelDeliveryCompany(); // crea objeto compa�ia
	
	public static void main(String[] args) {
		new Main().run();
	}

	private void run() {
		Menu menu = new Menu();
		int option = EXIT;
		do {
			menu.show();
			option = menu.readOption();
			try {
				processOption(option);
			} catch (Exception e) {
				handleDefault(e);
			}
		} while (option != EXIT);
		
		Console.println("Execution finished");
	}

	private void processOption(int option) throws RepeatedElementException, DoesNotExistException {
		switch( option ) {
			case EXIT: return;
			case 1: loadFile(); break;
			case 2: addVehicle(); break;
			case 3: removeVehicle(); break;
//			case 4: saveToFile(); break;
//			case 5: importFromZip(); break;
//			case 6: exportToZip(); break;
			case 7: showVehiclesByBrand(); break;
			case 8: showVehiclesByAge(); break;
			case 9: computeTotalFleetTaxes(); break;
		}
	}

	private void computeTotalFleetTaxes() {
		Console.printf("Total amount of taxes: %.2f\n", company.getTotalRoadTax());
	}

	private void showVehiclesByAge() {
		List<Vehicle> sorted = company.getVehiclesByYear();
		listVehicles( sorted );
	}

	private void showVehiclesByBrand() {
		List<Vehicle> sorted = company.getVehiclesByBrand();
		listVehicles( sorted );
	}

//	private void exportToZip() {
//		String fileName = Console.readString("output file name?");
//		company.saveToZipFile( fileName );
//	}
//
//	private void importFromZip() {
//		String fileName = Console.readString("input zip file name?");
//		company.loadZipFile( fileName );
//	}
//
//	private void saveToFile() {
//		String fileName = Console.readString("output file name?");
//		company.saveToFile( fileName );
//	}

	private void removeVehicle() throws DoesNotExistException {
		String plate = Console.readString("plate number?");
		company.removeVehicle( plate );
	}

	private void addVehicle() throws RepeatedElementException {
		Vehicle v = new VehicleBuilder().build();
		company.addVehicle( v );
	}

	private void loadFile() throws RepeatedElementException {
		String fileName = Console.readString("File name?");
		company.loadFile( fileName );
	}

	private void listVehicles(List<Vehicle> vehicles) {
		Console.println("\nList of vehicles");
		Console.println("------------------");
		for (Vehicle v: vehicles) {
			System.out.println( v );
		}
	}
	private void  handleDefault(Exception e){
		
		String msg = ("Se ha producido un error al procesar la operaci�n.\n" + e.getMessage() 
				+ " Resuelva el problema y ejecute de nuevo.\n");
		Console.println(msg);
	}

}
