package uo.mp.vehicles.ui;

import uo.mp.util.Console;
import uo.mp.vehicles.vehicle.Car;
import uo.mp.vehicles.vehicle.Motorbike;
import uo.mp.vehicles.vehicle.Truck;
import uo.mp.vehicles.vehicle.Vehicle;

public class VehicleBuilder {

	public Vehicle build() {
		String type = Console.readString("Type of vehicle? (car | truck | moto)");
		switch( type ) {
			case "car": return buildCar();
			case "truck": return buildTruck();
			case "moto": return buildMoto();
		}
		return null;
	}

	private Vehicle buildMoto() {
		String plate = askForPlate();
		int cc = askForCC();
		int hp = askForHp();
		int years = askForYears();
		String brand = askForBrand();

		return new Motorbike(plate, cc, hp, years, brand);
	}

	private Vehicle buildTruck() {
		String plate = askForPlate();
		int cc = askForCC();
		int hp = askForHp();
		int years = askForYears();
		String brand = askForBrand();
		int axles = askForAxles();
		int tare = askForTare();

		return new Truck(plate, cc, hp, years, brand, axles, tare);
	}

	private Vehicle buildCar() {
		String plate = askForPlate();
		int cc = askForCC();
		int hp = askForHp();
		int years = askForYears();
		String brand = askForBrand();

		return new Car(plate, cc, hp, years, brand);
	}

	private String askForBrand() {
		return askForString("Brand?");
	}

	private int askForYears() {
		return askForAnInteger("Age in years?");
	}

	private int askForHp() {
		return askForAnInteger("Horse power?");
	}

	private int askForCC() {
		return askForAnInteger("Cubic centimeters?");
	}

	private String askForPlate() {
		return askForString("Plate number?");
	}

	private int askForTare() {
		return askForAnInteger("Tare?");
	}

	private int askForAxles() {
		return askForAnInteger("Number of axles?");
	}

	private int askForAnInteger(String prompt) {
		return Console.readInteger( prompt );
	}

	private String askForString(String prompt) {
		return Console.readString( prompt );
	}

}
