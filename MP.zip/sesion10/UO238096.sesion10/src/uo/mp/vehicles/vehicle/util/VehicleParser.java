package uo.mp.vehicles.vehicle.util;


import java.util.LinkedList;
import java.util.List;

import uo.mp.util.ConsoleLogger;
import uo.mp.util.Logger;
import uo.mp.vehicles.vehicle.Car;
import uo.mp.vehicles.vehicle.Motorbike;
import uo.mp.vehicles.vehicle.Truck;
import uo.mp.vehicles.vehicle.Vehicle;

public class VehicleParser {
	private Logger logger = new ConsoleLogger();

	public List<Vehicle> parse(List<String> lines) {
		List<Vehicle> vehicles = new LinkedList<Vehicle>();
		for (int ln=0; ln<lines.size(); ln++){
			String line = lines.get(ln);
			
			Vehicle v =parseLine(line);
			vehicles.add(v);
		}
		return vehicles;
	}

	
	private Vehicle parseLine(String line){
		String [] parts = line.split("\t");
		return createVehicle(parts);		
	}
	
		
	private Vehicle createVehicle(String [] parts){
		String type = parts[0];
		String plate = parts[1];		
		int cc = Integer.parseInt(parts[2]);			
		int horsepower = Integer.parseInt(parts[3]);
		int years = Integer.parseInt(parts[4]);
		String brand = parts[5];		
		Object vehicle = null;
		if (type.equals("car"))	
			vehicle = new Car(plate, cc, horsepower, years, brand);
		else if (type.equals("motorbike"))
			vehicle = new Motorbike(plate, cc, horsepower, years, brand);
		else if (type.equals("truck")){
			int numberOfAxles = Integer.parseInt(parts[6]);
		    int tare = Integer.parseInt(parts[7]);
			vehicle = new Truck(plate, cc, horsepower, years, brand,numberOfAxles, tare);}
		
		return (Vehicle)vehicle;	
	
	}
}
