package uo.mp.util;

public interface Logger {

	void log(String msg);

}
