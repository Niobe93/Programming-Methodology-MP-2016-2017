package mp.UO238096_greenHouse;

import java.io.PrintStream;
import java.util.Random;

/**
 * Title: TemperatureSensor
 * Description: Clase que simula un sensor de temperatura
 */
public class TemperatureSensor implements Checkable{

	/**
	 * Simula una medici�n de temperatura
	 * @return La temperatura medida por el sensor aleatorio [5-40]
	 */
	   public int getTemperature() {
		return new Random(System.currentTimeMillis()).nextInt(36)+5;}
	   
	/**
	 * Metodo que simula un checkeo del sensor de humedad
	 */
	@Override
	public void check(PrintStream out) {
		out.println("Comprobando sensor de temperatura autom�tico");}
	
}
