package mp.UO238096_greenHouse;

import java.io.PrintStream;

/**
 * Title: AutomaticDoor
 * Description: Clase que simula una puerta automatica
  */
public class AutomaticDoor extends Door implements Checkable  {

	/**
	 * Metodo que simula abrir una puerta
	 */
	@Override
	public void open(PrintStream out){
		if (!isOpened()) {
			out.println ("  La puerta autom�tica se abre ");
			setOpened(true);}}
	
	/**
	 * Metodo que simula cerrar una puerta
	 */
	@Override
	public void close(PrintStream out){
		if (isOpened()) {
			out.println ("  La puerta autom�tica se cierra ");
			setOpened(false);}}
	/**
	 * Metodo que checkea la puerta automatica
	 */
	@Override
	public void check(PrintStream out) {
		out.println("Comprobando la puerta autom�tica");}
	
}
