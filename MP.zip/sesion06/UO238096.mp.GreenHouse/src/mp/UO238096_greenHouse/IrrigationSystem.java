package mp.UO238096_greenHouse;

/**
 * Title: IrrigationSystem
 * Description: Clase que simula un sistema de irrigacion
 */
public class IrrigationSystem {
	
	public enum Position {OFF,LOW,MEDIUM,HIGH};	
	private Position position;
	
	/**
	 * Metodo que devuelve el valor del atributo position
	 * @return valor position
	 */	
	public Position getPosition() {
		return position;}

	/**
	 * Metodo que modifica el valor del atributo position
	 * @param position
	 */	
	public void setPosition(Position position) {
		this.position = position;}
	
}
