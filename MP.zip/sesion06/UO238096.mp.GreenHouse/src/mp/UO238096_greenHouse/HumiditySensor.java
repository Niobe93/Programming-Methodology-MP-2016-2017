package mp.UO238096_greenHouse;

import java.io.PrintStream;
import java.util.Random;

/**
 * Title: HuniditySensor
 * Description: Clase que simula un sensor de humedad
 */

public class HumiditySensor implements Checkable {
	
	/**
	 * Simula una medici�n de humedad
	 * @return La humedad medida por el sensor aleatorio [0-100]
	 */	
	 public int getHumidity() {
		return new Random(System.currentTimeMillis()).nextInt(101);}

   /**
	* Metodo que simula un checkeo del sensor de humedad
	*/
	@Override
	public void check(PrintStream out) {
		out.println("Comprobando sensor de humedad autom�tico");}

}
