package mp.UO238096_greenHouse;

import java.io.PrintStream;
/**
 * Title: Checkable
 * Description: Interfaz que agrupa los objetos que puedes ser checkeados
  */

public interface Checkable {
  
	public void check (PrintStream out);
}
