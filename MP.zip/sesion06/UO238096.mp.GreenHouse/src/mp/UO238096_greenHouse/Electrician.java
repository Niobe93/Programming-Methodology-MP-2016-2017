package mp.UO238096_greenHouse;

import java.util.List;








/**
 * Title: Electrician
 * Description: Clase que simula un electricista
  */
public class Electrician {
	
	private String name, surname;
	
	/**
	 * Constructor de la clase electrician con parametros
	 * @param name, surname string
	 */
	public Electrician ( String name, String surname){
		this.setName(name);
		this.setSurname(surname);}
	
	/**
	 * Metodo que chekea los objetos del array Checkeables
	 * @param array checkeables
	 */
	public void check ( List<Checkable> checkables){
		for ( Checkable checkable: checkables)
			checkable.check(System.out);}
	
	/**
	 * Metodo que devuelve el valor del atributo name
	 * @return valor de name
	 */
	public String getName() {
		return name;}

	/**
	 * Metodo que modifica el valor del atributo name
	 * @param valor de name
	 */
	private void setName(String name) {
		this.name = name;}
	/**
	 * Metodo que devuelve el valor del atributo surname
	 * @return valor de surname
	 */
	public String getSurname() {
		return surname;}
	/**
	 * Metodo que modifica el valor del atributo surname
	 * @param surname
	 */
	private void setSurname(String surname) {
		this.surname = surname;}

}
