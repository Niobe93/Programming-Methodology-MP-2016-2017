package mp.UO238096_greenHouse;

import java.io.PrintStream;

/**
 * Title: Door
 * Description: Clase que simula una puerta
  */
public class Door {

	private boolean opened;
	
	/**
	 * Constructor de la clase door
	 */
	public Door() {
		setOpened(false);}
	
	/**
	 * Metodo que devuelve el valor del atributo is openend
	 * @return valor de isopened
	 */
	public boolean isOpened() {
		return opened;}
	
	/**
	 * Metodo que simula abrir una puerta
	 */
	public void open(PrintStream out){
		if (!isOpened()) {
			out.println ("  La puerta se abre ");
			setOpened(true);}}
	
	/**
	 * Metodo que simula cerrar una puerta
	 */
	public void close(PrintStream out){
		if (isOpened()) {
			out.println ("  La puerta se cierra ");
			setOpened(false);}}
	
	/**
	 * Metodo que modifica el valor de isopened
	 */
	protected void setOpened(boolean opened) {
		this.opened = opened;
	}
}
