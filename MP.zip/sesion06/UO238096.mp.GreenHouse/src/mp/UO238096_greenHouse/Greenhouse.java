package mp.UO238096_greenHouse;

import java.io.PrintStream;
import java.util.ArrayList;

import mp.UO238096_greenHouse.IrrigationSystem.Position;

/**
 * Title: GreenHouse 
 * Description: Clase que simula un invernadero 
 */
public class Greenhouse {

	private final static byte MAX_TEMPERATURE = 22;
	private final static byte MIN_TEMPERATURE = 19;
	private final static int MAX_HUMIDITY = 55;
	private final static int MIN_HUMIDITY = 45;

	private IrrigationSystem irrigator;
	private ArrayList<TemperatureSensor> Tsensors = new ArrayList<TemperatureSensor>();
	private ArrayList<HumiditySensor> Hsensors = new ArrayList<HumiditySensor>();
	private ArrayList<Door> doors = new ArrayList<Door>();
	private ArrayList<Checkable> checkables = new ArrayList<Checkable>();
	
	/**
	 * Constructor con un parametro de clase irrigador
	 */
	public Greenhouse(IrrigationSystem irrigator) {		
		this.irrigator = irrigator;	}
	/**
	 *M�todo que a�ade al array de sensores de temperatura y al array Checkeables un sensor de temperatura
	 */
	public void addTSensor(TemperatureSensor sensor) {		
		checkables.add(sensor);
		Tsensors.add(sensor);}
	/**
	 *M�todo que a�ade al array de sensores de humedad y al array Checkeables un sensor de temperatura
	 */
	public void addHSensor(HumiditySensor sensor) {		
		checkables.add(sensor);
		Hsensors.add(sensor);}
	/**
	 *M�todo que a�ade al array de puertas una puerta y al array Checkeables si es puerta automatica
	 */
	public void addDoors(Door door) {
		doors.add(door);
		if (door instanceof Checkable){
		    checkables.add((Checkable) door);}}
	/**
	 *M�todo que devuelve una array de los objeto Checkeables
	 */
	public ArrayList<Checkable> getCheckables() {
		return checkables;}

	/**
	 * Simula el trabajo de un operador que abre o cierra las puertas teniendo
	 * en cuenta la temperatura y sube o baja los niveles de riego dependiendo de la humedad
	 */
	public void operatorLooksThru(PrintStream out) {
		out.println("****OPERADOR****\n");
		checkTemperature(out);
		checkHumidity(out);	}

	/**
	 * M�todo privado que controla la humedad subiendo o bajando los niveles de irrigacion
	 * en funci�n de la misma
	 * 
	 * Cuando la humedad media es MAYOR que el limite se baja un nivel de irrigacion 
	 * Cuando la humedad media es 20 veces MAYOR que el limite se baja al m�nimo el nivel de irrigacion 
	 * Cuando la humedad media es MENOR que el limite se sube un nivel de irrigacion 
	 * Cuando la humedad media es 20 veces MENOR que el limite se sube al m�ximo el nivel de irrigacion
	 * Si los niveles son correctos no se hace nada.
	 */
	private void checkHumidity(PrintStream out) {
		int averageHumidity = getAverageHumidity();
		if ((averageHumidity <= MAX_HUMIDITY)&& (averageHumidity >= MIN_HUMIDITY))
			System.out.printf("Humedad dentro de los l�mites correctos.\n");
		if (averageHumidity > MAX_HUMIDITY)
			this.decreaseLevelPosition();
		System.out.printf("Humedad superior al l�mite, bajando un nivel de irrigaci�n.\n");
		if (averageHumidity < MIN_HUMIDITY)
			this.increaseLevelPosition();
		System.out.printf("Humedad inferior al l�mite, subiendo un nivel de irrigaci�n.\n");
		if (averageHumidity > (MAX_HUMIDITY+20)) 
			irrigator.setPosition(Position.LOW);
		System.out.printf("Humedad superior 20 veces al l�mite, bajando el nivel de irrigaci�n al min.\n");
		if (averageHumidity < (MIN_HUMIDITY-20)) 
			irrigator.setPosition(Position.HIGH);
		System.out.printf("Humedad inferior 20 veces al l�mite, subiendo el nivel de irrigaci�n al m�x.\n");
	}
	
	/**
	 * M�todo privado que controla la temperatura cerrando o abriendo puertas en funci�n de la misma
	 * 
	 * Cuando la temp media es MAYOR que MAX_TEMPERATURE se abren el 10% por cada grado de diferencia
	 * de las puertas disponibles para bajar la temperatura  
	 * Cuando la temp media es MENOR que MIN_TEMPERATURE se cierran el 10% por cada grado de diferencia
	 * de las puertas disponibles para aumentar la temperatura 	 
	 */
	private void checkTemperature(PrintStream out) {
		double averageTemperature = getAverageTemperature();
		if (averageTemperature > MAX_TEMPERATURE) {
			int difTemperature = (int) (averageTemperature - MAX_TEMPERATURE);
			int doorsToOpen = (int) (difTemperature * 10.0 * doors.size()) / 100;
			this.openDoors(doorsToOpen, out);
			System.out.println("Abriendo puertas.\n");}
		if (averageTemperature < MIN_TEMPERATURE) {
			int difTemperature = (int) (MIN_TEMPERATURE - averageTemperature);
			int doorsToClose = (int) (difTemperature * 10.0 * doors.size()) / 100;
			this.closeDoors(doorsToClose, out);
			System.out.println("Cerrando puertas.\n");}
		
		System.out.printf("La temperature %f es correcta.\n\n",
				averageTemperature);}
	
	/**
	 * M�todo privado que abre las puertas que le pasemos como par�metro
	 * @param numero de puertas 
	 */
	private void openDoors(int doorsToOpen, PrintStream out) {
		int count = 0;
		for (Door doors : doors) {
			if ((doors.isOpened() == false) && (count <= doorsToOpen)) {
				doors.open(out);
				count++;}}
	}
	
	/**
	 * M�todo privado que cierra las puertas que le pasemos como par�metro
	 * @param numero de puertas 
	 */
	private void closeDoors(int doorsToClose, PrintStream out) {
		int count = 0;
		for (Door doors : doors) {
			if ((doors.isOpened() == true) && (count <= doorsToClose)) {
				doors.close(out);
				count++;}}
	}

	/**
	 * M�todo privado que calcula la temperatura media del invernadero
	 * @return La temperatura media del invernadero
	 */
	private double getAverageTemperature() {
		double addition = 0;
		for (TemperatureSensor sensor : Tsensors)
			addition += sensor.getTemperature();
		return addition / Tsensors.size();}
	
	/**
	 * M�todo privado que calcula la humedad media del invernadero
	 * @return La humedad media del invernadero
	 */
	private int getAverageHumidity() {
		int addition = 0;
		for (HumiditySensor sensor : Hsensors)
			addition += sensor.getHumidity();
		return addition / Hsensors.size();}
	
	/**
	 * M�todo privado que incrementa un nivel de irrigacion
	 */
	private void increaseLevelPosition(){
		if (irrigator.getPosition()== Position.LOW)
			irrigator.setPosition(Position.MEDIUM);
		if (irrigator.getPosition()== Position.MEDIUM)
			irrigator.setPosition(Position.HIGH);}  
	/**
	 *M�todo privado que decrementa un nivel de irrigacion
	 */
	private void decreaseLevelPosition(){
		if (irrigator.getPosition()== Position.HIGH)
			irrigator.setPosition(Position.MEDIUM);
		if (irrigator.getPosition()== Position.MEDIUM)
			irrigator.setPosition(Position.LOW);}  
}

