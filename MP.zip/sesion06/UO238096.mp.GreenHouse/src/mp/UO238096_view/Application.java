package mp.UO238096_view;


import mp.UO238096_greenHouse.AutomaticDoor;

import mp.UO238096_greenHouse.Door;
import mp.UO238096_greenHouse.Electrician;
import mp.UO238096_greenHouse.Greenhouse;
import mp.UO238096_greenHouse.HumiditySensor;
import mp.UO238096_greenHouse.IrrigationSystem;
import mp.UO238096_greenHouse.TemperatureSensor;

/**
 * Title: Application
 * Description: Clase que ejecuta el programa
 * 
 */
public class Application {
	
	/**
	 * M�todo principal que lanza la aplicaci�n 
	 * @param args
	 */
	public static void main(String[] args) {
		new Application().run();}

	/**
	 * M�todo que ejecuta la aplicaci�n
	 */
	
	public void run() {
		Greenhouse greenhouse = new Greenhouse(new IrrigationSystem());
		
		//A�adimos objetos al invernadero
		for(int i=0; i<10; i++) {
			greenhouse.addTSensor(new TemperatureSensor());
			greenhouse.addDoors(new Door());
			greenhouse.addDoors(new AutomaticDoor());
			greenhouse.addHSensor(new HumiditySensor());}
		
		
		//Llamamos al metodo del operador que controla la temperatura y la humedad
		greenhouse.operatorLooksThru(System.out);
		greenhouse.operatorLooksThru(System.out);
		greenhouse.operatorLooksThru(System.out);
		
		
		//Once a month llamamos al electricista
		Electrician electrician = new Electrician ( "Jose", "Garcia");
		electrician.check(greenhouse.getCheckables());}
	
}
