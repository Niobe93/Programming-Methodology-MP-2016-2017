package sesion3_dome.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import sesion3_dome.model.VideoGame.Platforms;

public class VideoGameTest {
	private VideoGame vg;

	@Before
	public void setUp() throws Exception {
		vg = new VideoGame("The last of us", "‎Naughty Dog",
				Platforms.PLAYSTATION, 1);
	}

	@Test
	public void testSetNumberOfPlayers() {
		// CASO1 introduzco un número de jugadores limite superior
		vg.setNumberOfPlayers(50);
		assertEquals(50, vg.getNumberOfPlayers());
		// CASO2 introduzco un numero de jugadores correcto
		vg.setNumberOfPlayers(1);
		assertEquals(1, vg.getNumberOfPlayers());
		// CASO2 introduzco un numero de jugadores correcto
		vg.setNumberOfPlayers(20);
		assertEquals(20, vg.getNumberOfPlayers());
		// Pruebas negativas
		// CASO3 introduzco un numero de jugadores 0
		try {
			vg.setNumberOfPlayers(0);
			fail();
		} catch (Exception e) {
			assertEquals("Error: parámetro incorrecto", e.getMessage());
		}
		// CASO4 introduzco un numero de jugadores 60
		try {
			vg.setNumberOfPlayers(60);
			fail();
		} catch (Exception e) {
			assertEquals("Error: parámetro incorrecto", e.getMessage());
		}
		// CASO5 introduzco un numero de jugadores negativos
		try {
			vg.setNumberOfPlayers(-10);
			fail();
		} catch (Exception e) {
			assertEquals("Error: parámetro incorrecto", e.getMessage());
		}
	}

	@Test
	public void testSetAuthor() {
		// CASO1 introduzco un nombre de autor correcto
		vg.setAuthor("Hideo Kojima");
		assertEquals("Hideo Kojima", vg.getAuthor());

		// CASO2 introduzco un nombre de autor null
		try {
			vg.setAuthor(null);
			fail();
		} catch (Exception e) {
			assertEquals("Error: parámetro incorrecto", e.getMessage());
		}

		// CASO3 introduzco un nombre de autor en blanco
		try {
			vg.setAuthor(" ");
			fail();
		} catch (Exception e) {
			assertEquals("Error: parámetro incorrecto", e.getMessage());
		}
	}

	@Test
	public void testSetPlatform() {
		//CASO 1 introduczo un valor de plataforma correcto 
		assertEquals(Platforms.PLAYSTATION ,vg.getPlatform());
		//CASO 2 cambiamos la plataforma y comprobamos que la cambia correctamente
		vg.setPlatform(Platforms.XBOX);
		assertEquals(Platforms.XBOX, vg.getPlatform());
		//CASO 3 cambiamos la plataforma y comprobamos que la cambia correctamente
		vg.setPlatform(Platforms.NINTENDO);
		assertEquals(Platforms.NINTENDO, vg.getPlatform());
		
		// CASO 4 cambiamos la plataforma a un objeto null
		try {
			vg.setPlatform(null);
			fail();
		} catch (Exception e) {
			assertEquals("Error: parámetro incorrecto", e.getMessage());
		}				
	}

}
