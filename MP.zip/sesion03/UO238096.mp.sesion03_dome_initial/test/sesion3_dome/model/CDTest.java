package sesion3_dome.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import sesion3_dome.model.CD;

public class CDTest {
	private CD cd;

	@Before
	public void setUp() {
		cd = new CD("Come Together", "Beatles", 70, 4);
	}

	@Test
	public void testSetTitle() {

		// caso 1 introduzco un nombre correcto
		cd.setTitle("Yellow Submarine");
		assertEquals("Yellow Submarine", cd.getTitle());
		
		// caso 2 introduzco cadena vacia(espacios en blanco)
		try {
			cd.setTitle(" ");
			fail();
		} catch (Exception e) {
			assertEquals("Error: par�metro incorrecto", e.getMessage());
		}
		
	}

	@Test
	public void testSetOwn() {

		// caso 1 estando en false paso a true
		cd.setOwn(true);
		assertEquals(true, cd.getOwn());
		// caso 2 estando en true paso a false
		cd.setOwn(false);
		assertEquals(false, cd.getOwn());
	}

	@Test
	public void testSetArtist() {

		// caso 1 introduzco un nombre correcto
		cd.setArtist("John Lennon");
		assertEquals("John Lennon", cd.getArtist());
	
		// caso 2 introduzco cadena vacia(espacios en blanco)
		try {
			cd.setArtist("    ");
			fail();
		} catch (Exception e) {
			assertEquals("Error: par�metro incorrecto", e.getMessage());
		}
	}

	@Test
	public void testSetNumberOfTracks() {

		// caso 1 introduzco un n�mero de pistas correcto
		cd.setNumberOfTracks(50);
		assertEquals(50, cd.getNumberOfTracks());
		// caso 2 introduzco pistas negativas
		try {
			cd.setNumberOfTracks(-10);
			fail();
		} catch (Exception e) {
			assertEquals("Error: par�metro incorrecto", e.getMessage());
		}

	}

	@Test
	public void testSetPlayingTime() {

		// caso 1 introduzco un tiempo correcto (positivo)
		cd.setPlayingTime(10);
		assertEquals(10, cd.getPlayingTime());
		// caso 2 introduzco tiempo negativo
		try {
			cd.setPlayingTime(-10);
			fail();
		} catch (Exception e) {
			assertEquals("Error: par�metro incorrecto", e.getMessage());
		}
	}

	@Test
	public void testSetComment() {

		// caso 1 introduzco un comentario correcto
		cd.setComment("Excelente");
		assertEquals("Excelente", cd.getComment());

		// caso 2 introduzco cadena vacia(espacios en blanco)
		try {
			cd.setComment("  ");
			fail();
		} catch (Exception e) {
			assertEquals("Error: par�metro incorrecto", e.getMessage());
		}
		

	}

}
