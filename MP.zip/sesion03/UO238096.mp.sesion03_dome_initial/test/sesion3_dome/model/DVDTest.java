package sesion3_dome.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import sesion3_dome.model.DVD;

public class DVDTest {

	private DVD dvd;
	
	@Before
	public void setUp()
	{
		dvd = new DVD("La guerra de las Galaxias","George Lucas",125);
	}

	@Test
	public void testSetTitle() {
		
		// caso 1 introduzco un nombre correcto
		dvd.setTitle("Stars Wars");
		assertEquals("Stars Wars",dvd.getTitle());
		// caso 2 introduzco cadena vacia(espacios en blanco)
		try {
			dvd.setTitle("   ");
			fail();
		} catch (Exception e) {
			assertEquals("Error: par�metro incorrecto", e.getMessage());
				}
	}
	
	@Test
	public void testSetDirector() {
	
		// caso 1 introduzco un nombre correcto
		dvd.setDirector("Jorge Lucas");
		assertEquals("Jorge Lucas",dvd.getDirector());
		// caso 2 introduzco cadena vacia(espacios en blanco)
		try {
			dvd.setDirector("   ");
			fail();
		} catch (Exception e) {
			assertEquals("Error: par�metro incorrecto", e.getMessage());
		}
		
	}
	
	@Test
	public void testSetPlayingTime() {
		
		// caso 1 introduzco un tiempo correcto (positivo)
		dvd.setPlayingTime(126);
		assertEquals(126,dvd.getPlayingTime());
		// caso 2 introduzco tiempo negativo
		try {
			dvd.setPlayingTime(-10);
			fail();
		} catch (Exception e) {
			assertEquals("Error: par�metro incorrecto", e.getMessage());
		}
	}
	
	
	@Test
	public void testSetOwn() {
	
		// caso 1 estando en false paso a true
		dvd.setOwn(true);
		assertEquals(true,dvd.getOwn());
		// caso 2 estando en true paso a false
		dvd.setOwn(false);
		assertEquals(false,dvd.getOwn());
	}
	@Test
	public void testSetComment() {
		
		// caso 1 introduzco un comentario correcto
		dvd.setComment("Excelente");
		assertEquals("Excelente",dvd.getComment());
		// caso 2 introduzco cadena vacia(espacios en blanco)
		try {
			dvd.setComment(" ");
			fail();
		} catch (Exception e) {
			assertEquals("Error: par�metro incorrecto", e.getMessage());
				}
	}


}
