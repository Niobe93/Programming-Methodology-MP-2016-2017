package sesion3_dome.model;

import java.io.PrintStream;

public class VideoGame extends Item {
	public enum Platforms {XBOX, NINTENDO, PLAYSTATION};
	public final static int MAX_PLAYERS = 50;

	private int numberOfPlayers;
	private String author;
	private Platforms platform;

	public VideoGame(String theTitle, String theAuthor, Platforms thePlatform,
																		int thePlayers) {
		super(theTitle);
		setAuthor(theAuthor);
		setPlatform(thePlatform);
		setNumberOfPlayers(thePlayers);
	}

	protected void setNumberOfPlayers(int numberOfPlayers) {
		if ((numberOfPlayers <=0)| (numberOfPlayers >50))
			throw new RuntimeException("Error: par�metro incorrecto");
		this.numberOfPlayers = numberOfPlayers;
	}

	protected void setAuthor(String author) {
		if ((author == null) | ( author == (" ")))
			throw new RuntimeException("Error: par�metro incorrecto");
		this.author = author;
	}

	protected void setPlatform(Platforms platform) {
		if (platform == null)
			throw new RuntimeException("Error: par�metro incorrecto");
		this.platform = platform;
	}

	public int getNumberOfPlayers() {
		return numberOfPlayers;
	}

	public Platforms getPlatform() {
		return platform;
	}

	public String getAuthor() {
		return author;
	}

	public int getPlayingTime() {
		return 0;
	}

	public void print(PrintStream out) {

		out.print("VIDEOGAME: ");
		super.print(out);
		out.println("Author " + getAuthor());
		out.println("Plataform " + getPlatform());
		out.println("Number of players " + getNumberOfPlayers());
		out.println("");
	}

}
