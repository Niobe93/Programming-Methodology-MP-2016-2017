package sesion3_dome.model;

import java.io.PrintStream;

public class Item {

	private String title;
	private boolean gotIt;
	private String comment;

	public Item() {
		super();
	}

	public Item(String title) {
		super();
		setTitle(title);
		setOwn(true);
		setComment("Comment:");
	}

	protected void setTitle(String title) {
		if ((title.trim().isEmpty()))
			throw new RuntimeException("Error: par�metro incorrecto");

		this.title = title;
	}

	protected void setOwn(boolean ownIt) {
		this.gotIt = ownIt;
	}

	

	protected void setComment(String comment) {
		if ((comment.trim().isEmpty())){
			throw new RuntimeException("Error: par�metro incorrecto");}

		this.comment = comment;
	}

	protected String getComment() {
		return comment;
	}

	protected boolean getOwn() {
		return gotIt;
	}

	protected String getTitle() {
		return this.title;
	}

	
	public void print(PrintStream out) {
		out.print(getTitle());
		if (getOwn()) {
			out.println("*");
		} else {
			out.println();
		}
		out.println(getComment());
	}

	}