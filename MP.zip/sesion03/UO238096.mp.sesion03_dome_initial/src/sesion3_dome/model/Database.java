package sesion3_dome.model;

import java.io.PrintStream;
import java.util.ArrayList;

public class Database {

	private ArrayList<Item> items;

	public Database() {
		this.items = new ArrayList<Item>();
	}

	public void addItem(Item item) {
		if (item == null)
			throw new RuntimeException("Error, el par�metro no puede ser null");
		items.add(item);
	}

	public int numberOfItemsOwned() {
		int count = 0;
		for (Item item : items) {
			if (item.getOwn())
				count++;
		}
		return count;
	}

	public int searchItem(Item theItem) {
		if (theItem == null)
			throw new RuntimeException("Error, el par�metro no puede ser null");
		return items.indexOf(theItem);
	}

	public int gatherAllTime() {
		int count = 0;
		for (Item item : items) {
			if ( item instanceof CD)
			       count = count + ((CD) item).getPlayingTime();
			if ( item instanceof DVD)
			       count = count + ((DVD) item).getPlayingTime();}
		return count;

	}

	public void list(PrintStream out) {
		for (Item item : items) {
			item.print(out);
		}
	}

	public void printResponsables(PrintStream out) {
		for (Item item : items) {
			if (item.getOwn() == true) {
				if (item instanceof CD)
					out.println("Responsable of CD " + item.getTitle() + " is "
							+ ((CD) item).getArtist());
				if (item instanceof VideoGame)
					out.println("Responsable of VideoGame " + item.getTitle()
							+ " is " + ((VideoGame) item).getAuthor());
				if (item instanceof DVD)
					out.println("Responsable of DVD " + item.getTitle()
							+ " is " + ((DVD) item).getDirector());
			}
		}
	}

	public int getSize() {
		return items.size();
	}

}
