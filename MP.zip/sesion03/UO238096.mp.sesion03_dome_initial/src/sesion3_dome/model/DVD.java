package sesion3_dome.model;

import java.io.PrintStream;

public class DVD extends Item {
	private String director;
	private int playingTime;

	public DVD(String theTitle, String theDirector, int time) {
		super(theTitle);
		setDirector(theDirector);
		setPlayingTime(time);
	}

	protected void setDirector(String director) {
		if( director.trim().isEmpty())
			throw new RuntimeException("Error: par�metro incorrecto");

		this.director = director;
	}
	
	protected void setPlayingTime(int playingTime) {
		if (playingTime < 0)
			throw new RuntimeException("Error: par�metro incorrecto");

		this.playingTime = playingTime;
	}
	protected int getPlayingTime() {
		return this.playingTime;
	}

	public String getDirector() {
		return this.director;
	}

	public void print(PrintStream out) {
		out.print("DVD: ");		
		super.print(out);
		out.println(getPlayingTime() + "mins");
		out.println("Director" +getDirector());
		out.println("");

	}}

