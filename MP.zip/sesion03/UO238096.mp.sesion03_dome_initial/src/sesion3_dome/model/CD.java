package sesion3_dome.model;

import java.io.PrintStream;

public class CD extends Item {

	private String artist;
	private int numberOfTracks;
	private int playingTime;
	
	public CD(String theTitle, String theArtist, int tracks, int time) {
		super(theTitle);
		setArtist(theArtist);
		setNumberOfTracks(tracks);
		setPlayingTime(time);
	}

	public void setArtist(String artist) {
		if ( artist.trim().isEmpty())
			throw new RuntimeException("Error: par�metro incorrecto");
		this.artist = artist;
	}
	protected void setPlayingTime(int playingTime) {
		if (playingTime < 0)
			throw new RuntimeException("Error: par�metro incorrecto");

		this.playingTime = playingTime;
	}
	protected int getPlayingTime() {
		return this.playingTime;
	}

	public void setNumberOfTracks(int numberOfTracks) {

		if (numberOfTracks <= 0)
			throw new RuntimeException("Error: par�metro incorrecto");

		this.numberOfTracks = numberOfTracks;
	}

	public String getArtist() {
		return this.artist;
	}

	public int getNumberOfTracks() {
		return this.numberOfTracks;
	}

	public void print(PrintStream out) {
		out.print("CD: ");
		super.print(out);
		out.println(getPlayingTime() + "mins");
		out.println("Artist" + getArtist());
		out.println("Tracks: " + getNumberOfTracks());
		out.println("");

	}
}