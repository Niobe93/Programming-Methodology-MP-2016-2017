package sesion03.view;

import sesion3_dome.model.CD;
import sesion3_dome.model.DVD;
import sesion3_dome.model.Database;
import sesion3_dome.model.VideoGame;
import sesion3_dome.model.VideoGame.Platforms;

public class Main {

	public static void main(String[] args) {
		new Main().run();

	}
	public void run(){
		Database db = new Database();
		db.addItem(new CD ("Nevermind", "Nirvana",12,64));
		db.addItem(new CD ("The Queen Is Dead", "The Smiths",10,51));
		db.addItem(new CD ("A Night at the Opera", "Queen",12,74));
		db.addItem(new DVD("Spirited Away", "‎Hayao Miyazaki",124));
		db.addItem(new DVD ("Into the wild", "Sean Penn",140));
		db.addItem(new DVD ("Interstellar", "Christopher Nolan",169));
		db.addItem(new VideoGame ("The last of us", "‎Naughty Dog",Platforms.PLAYSTATION,1 ));
		db.addItem(new VideoGame ("Halo 5: Guardians", "‎Microsoft",Platforms.XBOX,24 ));
		db.addItem(new VideoGame ("Super Mario", "‎Nintendo",Platforms.NINTENDO,2 ));
		
		db.numberOfItemsOwned();
		db.list(System.out);
		db.printResponsables(System.out);
		
	}

}
