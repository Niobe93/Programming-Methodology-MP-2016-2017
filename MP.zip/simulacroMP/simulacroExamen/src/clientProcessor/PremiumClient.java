package clientProcessor;

public class PremiumClient extends Client{

	private int amountCondoned;
	
	public PremiumClient(String name, String surname, int amount, int amountCondoned) {
		super(name, surname, amount);
		this.amountCondoned = amountCondoned;
	}

	public int getAmountCondoned() {
		return amountCondoned;
	}

	public void setAmountCondoned(int amountCondoned) {
		this.amountCondoned = amountCondoned;
	}
	
	private int getAmountFinal(){
		return getAmount()-getAmountCondoned();
		
	}
	public String toString(){
		return ("Client "+ getName()+ " Surname "+ getSurname());
	}
		
	public String serialize(){
		return String.format("%s/%s/%i",getName(),getSurname(),getAmountFinal());
	}
	
}
