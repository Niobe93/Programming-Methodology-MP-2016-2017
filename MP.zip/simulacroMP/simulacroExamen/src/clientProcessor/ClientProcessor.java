package clientProcessor;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

public class ClientProcessor {

	
	private List clients = new ArrayList<Client>();
	
	private void loadClients(String namefile) throws FileNotFoundException{
		List<String>lines= new FileUtil().loadLines(namefile);
		
	}
	
	private void saveToResult(String namefile, List<String>lines){
		
	}
	
	private Client createClient ( String [] lines ){
		Client client = null;
		String typeClient = lines[0];
		String nameClient = lines[1];
		String surNameClient = lines[2];
		int amountClient = Integer.parseInt(lines[3]);
		int amountCondoned = 0;
		if (typeClient == "PremiumClient"){
			amountCondoned = Integer.parseInt(lines[4]);
			client = new PremiumClient(nameClient, surNameClient, amountClient, amountCondoned);
		}
		if (typeClient == "Client"){			
			client = new Client(nameClient, surNameClient, amountClient);
		}		
		return client;
		
	}

	
	
}
