package clientProcessor;

public class Client implements Comparable<Client>{

	private String name;
	private String surname;
	private int amount;
	
	public Client(String name, String surname, int amount) {
		
		super();
		this.name = name;
		this.surname = surname;
		this.amount = amount;
	}
	
	public String getName() {
		return name;
	}

	public String getSurname() {
		return surname;
	}

	public int getAmount() {
		return amount;
	}
	
	private int getAmountFinal(){
		return getAmount();
	}

	public String toString(){
		return ("Client "+ getName()+ " Surname "+ getSurname());
	}
		
	public String serialize(){
		return String.format("%s/%s/%i",getName(),getSurname(),getAmountFinal());
	}


	@Override
	public int compareTo(Client m) {		
		return this.getName().compareTo(m.getName());
	}
	}
	
		
	

