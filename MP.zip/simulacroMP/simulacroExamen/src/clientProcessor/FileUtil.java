package clientProcessor;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class FileUtil {

	public List<String> loadLines(String namefile)
			throws FileNotFoundException {

		BufferedReader in = new BufferedReader(new FileReader(namefile));
		List<String> res = new LinkedList<>();
		try {
			while (in.ready()) {
				res.add(in.readLine());
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

		finally {
			close(in);
		}

		return res;
	}
	
	public void saveLines(String namefile, List<String>lines){
		BufferedWriter out = null;		
		try {
			out = new BufferedWriter(new FileWriter(namefile));
			for(String line : lines){
				out.write(line);
				out.newLine();				
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		finally {
			close(out);
		}
	}

	private void close(Closeable in) {
		try {
			in.close();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

	}
}
