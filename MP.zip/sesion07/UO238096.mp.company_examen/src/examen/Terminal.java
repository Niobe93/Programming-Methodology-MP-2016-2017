package examen;

import java.io.PrintStream;

public class Terminal {
	
	private String extension;

	public Terminal(String extension) {
		setExtension(extension);
	}

	public String getExtension() {
		return extension;
	}

	private void setExtension(String extension) {
		this.extension = extension;
	}
	
	public double consumoTerminal(){
		return 0.0;
	}
	
	public void facturacion(PrintStream out){
		out.println("Extension del terminal: " +getExtension());		
	}
	
	public boolean equals(Terminal terminal){
		return false;
	}

}
