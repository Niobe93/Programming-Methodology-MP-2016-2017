package examen;

import java.io.PrintStream;

public class ModemUSB extends Terminal implements Conectable
{
	private int megabytesDescargados;

	public ModemUSB(String extension) {
		super(extension);
		
	}

	public int getMegabytesDescargados() {
		return megabytesDescargados;
	}

	private void setMegabytesDescargados(int megabytesDescargados) {
		this.megabytesDescargados = megabytesDescargados;
	}
	
	
	@Override
	public double consumoTerminal(){
		double total= 0.0;
		int cocienteGB= getMegabytesDescargados()/1024;
		
		
		if (getMegabytesDescargados()<=1024)
			total=9.99;
		if (getMegabytesDescargados()>1024){
			if((getMegabytesDescargados()/1024*cocienteGB)==0)
			     total= 9.99+(cocienteGB*12.90);
			else
				 total= 9.99+(cocienteGB*12.90)+12.90;}
		return total;
		
	}

	@Override
	public void conect(int conect) {
		setMegabytesDescargados(getMegabytesDescargados()+conect);
		
	}
	
	@Override
	public void facturacion(PrintStream out){
		super.facturacion(out);
		out.println("Consumo: "+ this.consumoTerminal()+"\n");
		
	}
	
	 @Override
	    public boolean equals(Terminal terminal){
	    	ModemUSB modem = (ModemUSB) terminal;
	    	if ( modem.getExtension().equals(this.getExtension())){
	    		if (modem.getMegabytesDescargados()>10000)
	    			return true;}
	    	return false;
	    }
}
