package examen;

import java.io.PrintStream;

public class Fijo extends Terminal
{
	private int minutosHablados;

	public Fijo(String extension,int minutosHablados) {
		super(extension);
		this.minutosHablados = minutosHablados;
	}

	public int getMinutosHablados() {
		return minutosHablados;
	}

	public void setMinutosHablados(int minutosHablados) {
		this.minutosHablados = minutosHablados;
	}
	
	@Override
	public double consumoTerminal(){
		double total= 0.0;
		if ( getMinutosHablados()<=100)
			total=0.0;
		if (getMinutosHablados()> 100)
			total = getMinutosHablados()*0.05;
		return total;
	}
	
	@Override
	public void facturacion(PrintStream out){
		super.facturacion(out);
		out.println("Consumo: "+ this.consumoTerminal()+"\n");
		
	}
	
}
