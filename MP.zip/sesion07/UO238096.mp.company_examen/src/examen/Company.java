package examen;

import java.io.PrintStream;
import java.util.ArrayList;


public class Company {
	private ArrayList<Terminal>terminales;
	private ArrayList<Conectable>conectables;	
 
	

	public Company() {
		super();
		terminales = new ArrayList<Terminal>();
		conectables = new ArrayList<Conectable>();
	}

	//1. A�adir un terminal
	public void add(Terminal terminal){
		if (terminal == null)
			throw new RuntimeException("Error el parametro no puede ser null");
		
		terminales.add(terminal);
		if(terminal instanceof Conectable)
			conectables.add((Conectable) terminal);
	}
	
	//2. calcular el consumo total	
	
	public double consumoTotal(){
		double consumo= 0.0;
		for ( Terminal terminal: terminales)
			consumo = consumo + terminal.consumoTerminal();
		return consumo;	
		
	}
	
	//3. Mostrar la facturaci�n de los terminales 
	
	public void facturacion(PrintStream out){
		
		for ( Terminal terminal: terminales)
			terminal.facturacion(out);}
	
	//4. Cancelar un terminal conectable
	
	public boolean cancelarTerminal(Terminal terminal){
		if (!(terminal instanceof Conectable))
			return false;
		for (Conectable termin: conectables){
		    if (termin.equals(terminal)){
		    	terminales.remove(termin);
		    	conectables.remove(termin);
			    return true;}}
		return false;	
	}	
	
	public int getSize(){  
		
		return terminales.size();
		
	}	
	}

