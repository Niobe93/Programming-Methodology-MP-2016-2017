package examen;

public interface Conectable {

	
	void conect( int conect);
}
