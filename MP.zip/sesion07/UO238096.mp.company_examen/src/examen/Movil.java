package examen;

import java.io.PrintStream;

public class Movil extends Terminal implements Conectable
{
	
	private double importePorMinuto;
	private int minutosHablados;
	private int megabytesDescargados;
	
	
	
	
	public Movil(String extension,int minutosHablados,double importePorMinuto) {
		super(extension);
		setImportePorMinuto(importePorMinuto);
		setMinutosHablados(minutosHablados);}
		
	public double getImportePorMinuto() {
		return importePorMinuto;
	}
	private void setImportePorMinuto(double importePorMinuto) {
		this.importePorMinuto = importePorMinuto;
	}
	public int getMinutosHablados() {
		return minutosHablados;
	}
	private void setMinutosHablados(int minutosHablados) {
		this.minutosHablados = minutosHablados;
	}
	public int getMegabytesDescargados() {
		return megabytesDescargados;
	}
	private void setMegabytesDescargados(int megabytesDescargados) {
		this.megabytesDescargados = megabytesDescargados;
	}
	
	@Override
	public double consumoTerminal(){
		double total=0.0;
		total = (getMinutosHablados()*getImportePorMinuto());
		total = total + (getMegabytesDescargados()*0.1);
		return total;
	}
	
	@Override
	public void facturacion(PrintStream out){
		super.facturacion(out);
		out.println("Consumo: "+ this.consumoTerminal()+"\n");
		
	}

    @Override
    public boolean equals(Terminal terminal){
    	Movil movil = (Movil)terminal;
    	if (this.getMinutosHablados()> 900)
    	   if ( movil.getExtension().equals(this.getExtension())){    		
    			return true;}
    	return false;
    }


	@Override
	public void conect(int conect) {
		setMegabytesDescargados(getMegabytesDescargados()+conect);
		
	}
	
	
	
	
}

