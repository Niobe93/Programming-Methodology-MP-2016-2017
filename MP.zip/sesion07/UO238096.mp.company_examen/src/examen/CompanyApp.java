package examen;



public class CompanyApp {
	public static void main(String[] args) {
		new CompanyApp().run();
	}

	private void run() {
		Company company = new Company();
		 Movil movil1 = new Movil("5050", 720, 0.18);
		 Movil movil2 = new Movil("6070", 1200, 0.18);
	     Movil movil3 = new Movil("6075", 3500, 0.18);
		 
		 ModemUSB usb1 = new ModemUSB("8051");
	     ModemUSB usb2 = new ModemUSB("8052");
	     ModemUSB usb3 = new ModemUSB("8054");
		 
		 //1. A�adir un terminales

		 company.add(movil1);
		 company.add(movil2);
		 company.add(movil3);
		 company.add(new Fijo("2030", 75));
		 company.add(new Fijo("1111", 220));
		 company.add(new Fijo("1122", 350));
		 company.add(new Fijo("2222", 85));
		 company.add(usb1);
		 company.add(usb2);
		 company.add(usb3);
		 
        movil1.conect(350);
        movil2.conect(600);
        movil3.conect(600);
        movil3.conect(600);
      
        
        usb3.conect(1000);
        usb3.conect(8000);
        usb3.conect(8000);  
		
//		 
//		// 2. calcular el consumo total
		      System.out.println(company.consumoTotal());
	
//		//3. Mostrar la facturaci�n de los terminales
		   
		      company.facturacion(System.out);
		      
//		//4. Cancelar un terminal conectable
		 
		      company.cancelarTerminal(usb1);
		      
		      
//		//Se muestra la facturaci�n de los terminales OTRA VEZ para comprobar que se han borrardo

		      company.facturacion(System.out);
		      
	}
}
