package test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import examen.Company;
import examen.Fijo;
import examen.ModemUSB;
import examen.Movil;


public class testCompany {

	
	private Movil movil1;
	private ModemUSB modem1;
	private Company company;
	@Before
	public void setUp() throws Exception {
		
		modem1 = new ModemUSB("8051");
		movil1 = new Movil("5050", 720, 0.18);
		company = new Company();
	}

	@Test
	public void testCalcularConsumo() {
		//CASO 1 llamamos al metodo sin ningun terminal
		assertEquals(0 ,company.consumoTotal(),0.1);
		//CASO 2 llamamos al metodo con dos terminales y calculamos el importe total
		company.add(modem1);
	    company.add(movil1);
	    assertEquals(139.59 ,company.consumoTotal(),0.1);
	    //CASO 3 a�adimos consumo de datos al movil y calculamos el importe
	    movil1.conect(1024);
	    assertEquals(241.99 ,company.consumoTotal(),0.1);
	    //CASO 4 al modem le cambiamos para que tenga en total que pagar por 3 gb
	    modem1.conect(2300); // serian 3 importes de 12,9 mas la tarifa base que ya estaba incluida
	    assertEquals(280.69 ,company.consumoTotal(),0.1);
	}
	
	@Test
	public void testCancelar() {
		
	    //CASO 1  a�adimos dos objetos 
		company.add(modem1);
	    company.add(movil1);
	    //buscamos a ubn objeto que si existe y comprobamos que lo borra
	    assertEquals(true, company.cancelarTerminal(movil1));
	    assertEquals(1,company.getSize());
	    //volvemos a buscarlo para comprobar que no existe
	    assertEquals(false, company.cancelarTerminal(movil1));
	    //CASO 2 intentamos borrar un obejto que no es conectable
	    Fijo fijo = new Fijo ("2222", 85);
	    assertEquals(false, company.cancelarTerminal(fijo));
	}

}
