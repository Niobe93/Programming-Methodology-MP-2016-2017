package uo.mp.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import uo.mp.analyzer.WordAnalyzer;

public class WordAnalyzerTest {
	private WordAnalyzer hollow, empty, aabbac, mississippi;

	@Before
	public void setUp() throws Exception {
		hollow = new WordAnalyzer("hollow");
		empty = new WordAnalyzer("empty");
		aabbac = new WordAnalyzer("aabbac");
		mississippi = new WordAnalyzer("mississippi");
	}

	@Test
	public void testWordAnalyzer() {
		WordAnalyzer wa = new WordAnalyzer("pata");
		assertEquals("pata", wa.getWord());
		try{
		 wa = new WordAnalyzer(null);		
		} catch (Exception e){
			assertEquals("error, parametro null", e.getMessage());			
		}
	}

	@Test
	public void testFirstRepeatedCharacter() {
		assertEquals('l', hollow.firstRepeatedCharacter());
		assertEquals( 0, empty.firstRepeatedCharacter());
		assertEquals('s', mississippi.firstRepeatedCharacter());
		assertEquals('a', aabbac.firstRepeatedCharacter());
		
	}

	@Test
	public void testFirstMultipleCharacter() {
		assertEquals('o', hollow.firstMultipleCharacter());
		assertEquals(0, empty.firstMultipleCharacter());
		assertEquals('i', mississippi.firstMultipleCharacter());
		assertEquals('a', aabbac.firstMultipleCharacter());
	}

	@Test
	public void testCountGroupsOfRepeatedCharacters() {
		assertEquals(1, hollow.countGroupsOfRepeatedCharacters());
		assertEquals(0, empty.countGroupsOfRepeatedCharacters());
		assertEquals(3, mississippi.countGroupsOfRepeatedCharacters());
		assertEquals(2, aabbac.countGroupsOfRepeatedCharacters());
	}

}
