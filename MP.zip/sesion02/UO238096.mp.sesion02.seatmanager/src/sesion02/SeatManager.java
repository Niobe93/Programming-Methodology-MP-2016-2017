package sesion02;

/**
 * Class SeatManager. 
 * 
 * @author Gema Rico Pozas 
 * @version 6/2/2017
 */
import java.util.ArrayList;
public class SeatManager
{   
    //CONSTANTES
    public final static int DEFAULT_ROWS = 4;
    public final static int DEFAULT_COLUMNS=4;

    public final static int MAX_ROWS=10;    
    public final static int MAX_COLUMNS=4;
  
    // ATRIBUTOS
    private Person [][] seats;    

    /**
     * Constructor of class SeatManager
     */
    public SeatManager(){
    	
        seats = new Person [DEFAULT_ROWS][ DEFAULT_COLUMNS];
    }

	/**
     * Constructor of class SeatManager con parametros
     * 
     * @param el numero de filas 
     * @param el numero de columnas
     * 
     */    
    public SeatManager(int rows, int columns)
    {
        if ((rows > MAX_ROWS)|| (rows < 0)|| (columns > MAX_COLUMNS)|| (columns < 0))
        	throw new RuntimeException ("Error, par�metros incorrectos");
        seats = new Person [rows][ columns];
    }

    /**
     * Metodo que reserva un asiento para la persona recibida como parametro 
     * en la fila y columna recibida como parametro
     *
     * @param  persona para la reserva de tipo person
     * @param columna de la matriz
     * @param fila de la matriz
     * 
     * @return True si puede sentarse o false si esta ocupado
     */
    public boolean bookSeat(Person person, int column, int row)
    {
        if ((person == null) || (column < 0) || (column >=MAX_COLUMNS) || 
        		( row <0 ) || (row > MAX_ROWS))
            throw new RuntimeException("Error: parametros incorrectos");
        if (seats[row][column]==null)
        {
            seats[row][column]=person; 
            return true;
        }     
        return false;     
     }  
   
    /**
     * Metodo que devuelve un ArrayList con las personas sentadas en ventanilla  
     * cuya edad est� comprendida en el intervalo [edad m�nima, edad m�xima].
     * 
     * @param min_age edad minima del intervalo
     * @param max_age edad maxima del intervalo
     * 
     * @return arrayList con las personas sentadas en ventanilla  
     * cuya edad est� comprendida en el intervalo 
     */
    public ArrayList<Person> findPassengersByAge(int max_age, int min_age)
    {    	
        if ((max_age > Person.MAX_AGE) || (min_age < Person.MIN_AGE))
        	
 		   return null;
        
        else 
        {
        ArrayList<Person> passengers =new ArrayList<Person>();
        
        for (int i=0; i< seats.length ; i ++){
           if(seats[i][0]!=null){        	   
               if((seats[i][0].getAge()>= min_age)&&(seats[i][0].getAge()<= max_age)) 
                      passengers.add(seats[i][0]); }
           if(seats[i][3]!=null){
               if((seats[i][3].getAge()>= min_age)&&(seats[i][3].getAge()<= max_age)) 
                     passengers.add(seats[i][3]); }}              
                
        return passengers;}
    }    
     
   

	// Metodos para hacer las pruebas
    /**
     * Metodo que devuelve el valor de la matriz
     * @return matriz
     */
    public Person[][] getSeats() {
  		return seats;
  	}
    /**
     * Metodo que devuelve el valor de la persona
     * @return persona
     */
    public Person getPerson(int column, int row)
    {
        if((column < 0) || (column >MAX_COLUMNS) || ( row <0 ) || (row >MAX_ROWS))
            throw new RuntimeException ("Error: parametros incorrectos");
        return seats[row][column];
    }

    /**
     * Metodo que nos dice cuantos pasajeros estan sentados en el avion
     * 
     * @return  el numero de pasajeros sentados en el avion
     */
    public int getSize()
    {
        int contadorPassanger =0;
        for (int i=0; i< seats.length ; i ++)
        { for (int j=0; j < seats[i].length ; j++)  
             if(seats[i][j]!=null)
                    contadorPassanger ++;          
        }
        return contadorPassanger;
    }

}
