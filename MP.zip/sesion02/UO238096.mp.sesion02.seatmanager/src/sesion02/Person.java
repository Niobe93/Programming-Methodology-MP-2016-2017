package sesion02;

/**
 * Clase Person
 * 
 * @author Gema Rico Pozas
 * @version 6/2/2017
 */
import java.util.Random;

public class Person {
	public final static int MIN_AGE = 0;
	public final static int MAX_AGE = 120;
	public final static int ADULTHOOD_AGE = 18;
	public final static int RETIREMENT_AGE = 65;
	public final static boolean GENDER_FEMALE = false;
	public final static boolean GENDER_MALE = true;

	private final static String femaleNames[] = { "Ana", "Laura", "Maria",
			"Bea" };
	private final static String maleNames[] = { "Jose", "Pedro", "Miguel",
			"Javier" };
	private final static String surnames[] = { "Fernandez", "Rico", "Garcia",
			"Lopez" };

	// Atributos de la clase Person (propiedades, características, datos o
	// variables instancia)
	private String name;
	private int age;
	private String surname;
	private boolean gender; // true indicará Masculino, false Femenino

	/**
	 * Constructor for objects of class Person
	 */
	public Person() {
		Random random = new Random();
		setGender(random.nextBoolean());
		if (getGender() == true)
			setName(maleNames[random.nextInt(maleNames.length)]);
		else
			setName(femaleNames[random.nextInt(femaleNames.length)]);

		setSurname(surnames[random.nextInt(surnames.length)]);
		setAge(random.nextInt(MAX_AGE));
	}

	/**
	 * Constructor for objects of class Person
	 */
	public Person(int age) {
		this();
		setAge(age);
	}

	/**
	 * Metodo que modifica el valor del nombre de la persona.
	 * 
	 * @param nuevo nombre para la persona, de tipo String
	 *
	 */
	private void setName(String name) {
		this.name = name;
	}

	/**
	 * Metodo que devuelve el valor del atributo name
	 * 
	 * @return nombre de la persona, de tipo String
	 */
	public String getName() {
		return name;
	}

	/**
	 * Metodo que modifica el valor del apellido de la persona.
	 *
	 * @param nuevo apellido para la persona, de tipo String
	 * 
	 */
	private void setSurname(String surname) {
		this.surname = surname;
	}

	/**
	 * Metodo que devuelve el valor del atributo surname
	 *
	 * 
	 * @return apellido de la persona, del tipo String
	 */
	public String getSurname() {
		return surname;
	}

	/**
	 * Metodo que modifica el valor del atributo genero de la persona
	 *
	 * @param cambio de genero, de tipo boolean donde true es masculino y false es
	 *            femenino.
	 * 
	 */
	private void setGender(boolean gender) {
		this.gender = gender;

	}
	/**
	 * Metodo que devuelve el valor del atributo gender.
	 * 
	 * @return genero de la persona, del tipo boolean donde true es masculino y
	 *         false es femenino.
	 */
	public boolean getGender() {
		return gender;
	}

	/**
	 * Metodo que modifica el valor del atributo age de la persona.
	 *
	 * @param cambio de edad del tipo int, DEBE ser mayor que 0.
	 */
	private void setAge(int age) {
		if ((age >= MIN_AGE) && (age < MAX_AGE))
			this.age = age;
		}

	/**
	 * Metodo que devuelve el valor del atributo Age de la persona.
	 * @return edad de la persona del tipo int.
	 */
	public int getAge() {
		return age;
	}

	/**
	 * Metodo que muestra por pantalla (salida estandar) una cadena de
	 * caracteres con informacion del estado de un objeto.
	 *
	 */
	public void print() {
		System.out.println(toString());
	}

	/**
	 * Metodo que devuelve una cadena de caracteres.
	 *
	 * @return una cadena con la representacion textual del objeto (estado)
	 */

	public String toString()
	{
		if (this.getGender() == true)
			return " Edad: " + this.getAge() + " Nombre: " + this.getName()
					+ " Apellidos: " + this.getSurname()
					+ " Género: Masculino";
		else
			return " Edad: " + this.getAge() + " Nombre: " + this.getName()
					+ " Apellidos: " + this.getSurname() + " Género: Femenino";

	}

	/**
	 * Metodo que devuelve los a�os que le quedan a la persona para alcanzar
	 * diferentes etapas.
	 *
	 * @return devuelve segun la edad : si es menor de edad devuelve los a�os
	 *         hasta la mayoria de edad (18); si es adulto, los a�os que le
	 *         faltan hasta la edad de jubilacion (65); y si esta jubilado los
	 *         años transcurridos desde la edad de jubilacion.
	 */

	public int getCriticalAge()	{
		{
			if (getAge() < ADULTHOOD_AGE)
				return (ADULTHOOD_AGE - getAge());

			else if (getAge() < RETIREMENT_AGE)
				return (RETIREMENT_AGE - getAge());

			else
				return (getAge() - RETIREMENT_AGE);
		}}

	/**
	 * Metodo que devuelve si el genero es femenino.
	 *
	 * @return devuelve el valor del atributo genero femenino
	 */

	public boolean isGirl()	{
		if (getGender() == GENDER_FEMALE)
			return true;
		else
			return false;
	}	
	/**
	 * Metodo que devuelve una cadena de caracteres.
	 *
	 * @return una cadena con la representacion en mayusculas de el nombre y
	 *         el apellido y la longitud de ambos y la edad de la persona
	 */
	public String getHashCode() {

		return this.getAge() + "-"
				+ this.getName().substring(0, 2).toUpperCase() + "-"
				+ this.getSurname().substring(0, 4).toUpperCase() + "-"
				+ this.getState();
	}
	/**
	 * Metodo que devuelve una cadena de caracteres.
	 *
	 * @return una cadena con el estado de edad de la persona
	 */
	private String getState() {
		if (getAge() < ADULTHOOD_AGE)
			return "CHILD";
		else if (getAge() < RETIREMENT_AGE)
			return "ADULT";
		else
			return "RETIRED";

	}
}
