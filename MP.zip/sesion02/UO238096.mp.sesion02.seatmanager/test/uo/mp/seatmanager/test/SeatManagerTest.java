package uo.mp.seatmanager.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import org.junit.Before;
import org.junit.Test;

import sesion02.Person;
import sesion02.SeatManager;

public class SeatManagerTest {
	private SeatManager seats;
	private Person person1, person2, person3, person4;
	private ArrayList<Person> passengers;

	@Before
	public void setUp() throws Exception {
		seats = new SeatManager();
		person1 = new Person(12);
		person2 = new Person(20);
		person3 = new Person(9);
		person4 = new Person(50);
		passengers = new ArrayList<Person>();

	}

	@Test
	public void testBookSeat() {

		// CASO 1 Llamamos al metodo bookseat e intentamos sentar a una persona
		assertEquals(true, seats.bookSeat(person1, 3, 2));
		assertEquals(person1, seats.getPerson(3, 2));

		// CASO 2 Llamamos al metodo bookseat e intentamos sentar a otra persona
		assertEquals(true, seats.bookSeat(person2, 2, 2));
		assertEquals(person2, seats.getPerson(2, 2));

		// CASO 3 Llamamos al metodo bookseat e intentamos sentar a otra persona
		assertEquals(true, seats.bookSeat(person3, 0, 0));
		assertEquals(person3, seats.getPerson(0, 0));

		// CASO 4 Llamamos al metodo bookseat e intentamos sentar a una persona
		// en un sitio ocupado
		assertEquals(false, seats.bookSeat(person3, 3, 2));
		assertEquals(person1, seats.getPerson(3, 2));

		// CASO 5 Llamamos al metodo bookseats con parametros incorrectos
		// primero con objeto persona null
		try {
			seats.bookSeat(null, 0, 0);
		} catch (Exception e) {
			assertEquals("Error: parametros incorrectos", e.getMessage());
		}
		// segundo con parametro column por debajo del limite inferior
		try {
			seats.bookSeat(person1, -1, 0);
		} catch (Exception e) {
			assertEquals("Error: parametros incorrectos", e.getMessage());
		}
		// tercero con parametro row por debajo del limite inferior
		try {
			seats.bookSeat(person1, 0, -1);
		} catch (Exception e) {
			assertEquals("Error: parametros incorrectos", e.getMessage());
		}
		// cuarto con parametro column por encima del limite superior
		try {
			seats.bookSeat(person1, 5, 3);
		} catch (Exception e) {
			assertEquals("Error: parametros incorrectos", e.getMessage());
		}
		// quinto con parametro row por encima del limite superior
		try {
			seats.bookSeat(person1, 3, 11);
		} catch (Exception e) {
			assertEquals("Error: parametros incorrectos", e.getMessage());
		}
	}

	@Test
	public void testFindPassengersByAge() {

		// Primero sentamos a varias personas en ventanillas
		// en el avi�n con el m�todo book seat con rango de edad de 0-50
		
		seats.bookSeat(person1, 0, 0); // 12 a�os
		seats.bookSeat(person2, 3, 1); // 20 a�os
		seats.bookSeat(person3, 0, 2); // 9 a�os
		seats.bookSeat(person4, 3, 3); // 50 a�os
		
		// y algunos pasajeros en pasillo
		seats.bookSeat(person1, 2, 0);
		seats.bookSeat(person2, 1, 1);
		seats.bookSeat(person3, 2, 2);
		seats.bookSeat(person4, 1, 3);

		// CASO 1 Llamamos al metodo findPassengersByAge y seleccionamos un
		// rango
		// de edad entre 0 y 50.

		assertEquals(person1, seats.findPassengersByAge(50, 0).get(0));
		assertEquals(person2, seats.findPassengersByAge(50, 0).get(1));
		assertEquals(person3, seats.findPassengersByAge(50, 0).get(2));
		assertEquals(person4, seats.findPassengersByAge(50, 0).get(3));

		// CASO 2 Llamamos al metodo findPassengersByAge y seleccionamos un
		// rango
		// de edad entre 10 y 20.

		assertEquals(person1, seats.findPassengersByAge(20, 10).get(0));
		assertEquals(person2, seats.findPassengersByAge(20, 10).get(1));

		// CASO 3 Llamamos al metodo findPassengersByAge y seleccionamos un
		// rango
		// de edad entre 51 y 100. NO HAY PASAJEROS EN EL RANGO
		
		passengers = new ArrayList<Person>(); // array vacio
		
		assertEquals(passengers, seats.findPassengersByAge(51, 100));

		// CASO 4 Llamamos al metodo findpassanger con parametros incorrectos
		
		// primero de edad maxima superior al limite
		
		assertEquals(null, seats.findPassengersByAge(130, 10));
		
		// segundo de edad minima inferior al limite
		
		assertEquals(null, seats.findPassengersByAge(50, -1));

	}

}
