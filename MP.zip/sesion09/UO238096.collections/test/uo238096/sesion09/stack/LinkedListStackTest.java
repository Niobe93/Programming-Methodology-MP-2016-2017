package uo238096.sesion09.stack;

import uo238096.sesion09.stack.LinkedListStack;
import uo238096.sesion09.stack.ListStack;

/**
 * Title: LinkedListStacktest
 * 
 * @author Gema Rico Pozas
 * @version 1.0
 */
public class LinkedListStackTest extends ListStackTest {

	@Override
	protected ListStack createList() {
		return new LinkedListStack();
	}
}
