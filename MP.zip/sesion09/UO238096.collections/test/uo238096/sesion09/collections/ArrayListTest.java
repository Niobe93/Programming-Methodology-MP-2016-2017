package uo238096.sesion09.collections;

import uo238096.sesion09.collections.ArrayList;
import uo238096.sesion09.collections.List;

/**
 * Title: ArrayListtest
 * 
 * @author Gema Rico Pozas
 * @version 1.0
 */
public class ArrayListTest extends ListTest {

	@Override
	protected List createList() {
		return new ArrayList();
	}

}
