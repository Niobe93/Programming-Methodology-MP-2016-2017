package uo238096.sesion09.collections;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import uo238096.sesion09.collections.List;

/**
 * Title: Listtest
 * 
 * @author Gema Rico Pozas
 * @version 1.0
 */
public abstract class ListTest {
	private List list;

	@Before
	public void setUp() {
		list = createList();

	}

	protected abstract List createList(); // debe estar implementado en las
											// subclases

	@Test
	public void testListIsEmptyWhenCreated() {
		assertEquals(0, list.size());
		assertTrue(list.isEmpty());
	}

	@Test
	public void testToStringEmpty() {
		assertEquals("[]", list.toString());
	}

	@Test
	public void testToStringInteger() {
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		assertEquals("[1, 2, 3, 4]", list.toString());
	}

	@Test
	public void testAdd() {
		list.add(1);
		list.add("Gema");
		list.add(3);
		list.add("RE");
		assertEquals(4, list.size());

	}

	@Test
	public void testToStringString() {
		list.add("testing");
		list.add("with");
		list.add("the");
		list.add("JUnit");
		list.add("framework");
		assertEquals("[testing, with, the, JUnit, framework]", list.toString());
	}

	@Test
	public void testRemoveByIndex() {
		list.add("testing");
		list.add("with");
		list.add("the");
		list.add("JUnit");
		list.add("framework");
		assertEquals(5, list.size());
		assertEquals("testing", list.remove(0));
		assertEquals("with", list.remove(0));
		try {
			list.remove(8);
			fail();
		} catch (Exception e) {
			assertEquals("Error el par�metro es incorrecto", e.getMessage());
		}
		try {
			list.remove(-5);
			fail();
		} catch (Exception e) {
			assertEquals("Error el par�metro es incorrecto", e.getMessage());
		}
	}

}
