package uo238096.sesion09.queue;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import uo238096.sesion09.queue.ListQueue;

/**
 * Title: ListQueueTest
 * 
 * @author Gema Rico Pozas
 * @version 1.0
 */
public abstract class ListQueueTest {

	private ListQueue list;

	@Before
	public void setUp() {
		list = createList();
	}

	protected abstract ListQueue createList();

	@Test
	public void enqueueTest() {
		// CASO 1 llamamos al metodo enqueue y a�adimos un objeto, comprobando
		// que el tama�o de la
		// coleccion crece y que el objeto a que apunta peek en la cola es
		// correcto
		list.enqueue(1);
		assertEquals(1, list.peek());
		assertEquals(1, list.size());

		// CASO 2 llamamos al metodo enqueue y a�adimos un objeto, comprobando
		// que el tama�o de la
		// coleccion crece y que el objeto a que apunta peek en la cola es
		// correcto
		list.enqueue(2);
		assertEquals(2, list.size());
		assertEquals(1, list.peek());

		// CASO 3 llamamos al metodo enqueue y a�adimos un objeto, comprobando
		// que el tama�o de la
		// coleccion crece y que el objeto a que apunta peek en la cola es
		// correcto
		list.enqueue(3);
		assertEquals(3, list.size());
		assertEquals(1, list.peek());

		// CASO 4 borramos un objeto ( LIFO --> deber�a salir el ultimo que ha
		// entrado)
		list.dequeue();
		assertEquals(2, list.size());
		list.dequeue();
		assertEquals(1, list.size());
		assertEquals(3, list.peek());

		// CASO 6 provamos con un objeto null
		try {
			list.enqueue(null);
			fail();
		} catch (Exception e) {
			assertEquals("Error el par�metro no puede ser null", e.getMessage());
		}

	}

	@Test
	public void peekTest() {
		// CASO 1 llamamos al metodo enqueue y a�adimos varios objetos,
		// comprobando que el tama�o de la
		// coleccion crece y que el objeto a que apunta peek en la cola es
		// correcto
		list.enqueue("H");
		list.enqueue("o");
		list.enqueue("l");
		list.enqueue("a");
		assertEquals("H", list.peek());
		assertEquals(4, list.size());

		// CASO 2 borramos un objeto ( LIFO --> deber�a salir el ultimo que ha
		// entrado) y por tanto
		// peek apunta al suguente el la lista
		list.dequeue();
		list.dequeue();
		assertEquals("l", list.peek());

		// CASO 4 desapilamos con la lista vac�a
		list.dequeue();
		list.dequeue();
		assertEquals(null, list.peek());

	}

	@Test
	public void dequeueTest() {
		// CASO 1 llamamos al metodo enqueue y a�adimos varios objetos,
		// comprobando que el tama�o de la
		// coleccion crece
		list.enqueue("H");
		list.enqueue("o");
		list.enqueue("l");
		list.enqueue("a");
		assertEquals(4, list.size());
		// CASO 2 llamamos al metodo dequeue y borramos varios objetos,
		// comprobando que el tama�o de la
		// coleccion decrece
		list.dequeue();
		list.dequeue();
		assertEquals(2, list.size());
		assertEquals("l", list.peek());
		// CASO 3 desapilamos con la lista vac�a
		list.dequeue();
		list.dequeue();// lista vacia
		assertEquals(null, list.dequeue());
	}
}
