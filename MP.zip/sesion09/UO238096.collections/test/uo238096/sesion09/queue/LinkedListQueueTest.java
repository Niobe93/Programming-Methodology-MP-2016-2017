package uo238096.sesion09.queue;

import uo238096.sesion09.queue.LinkedListQueue;
import uo238096.sesion09.queue.ListQueue;

/**
 * Title: LinkedListQueuetest
 * 
 * @author Gema Rico Pozas
 * @version 1.0
 */

public class LinkedListQueueTest extends ListQueueTest {

	@Override
	protected ListQueue createList() {
		return new LinkedListQueue();
	}
}
