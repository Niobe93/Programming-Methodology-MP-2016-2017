package uo238096.sesion09.queue;

import uo238096.sesion09.queue.ArrayListQueue;
import uo238096.sesion09.queue.ListQueue;

/**
 * Title: ArrayListQueuetest
 * 
 * @author Gema Rico Pozas
 * @version 1.0
 */
public class ArrayListQueueTest extends ListQueueTest {

	@Override
	protected ListQueue createList() {
		return new ArrayListQueue();
	}

}
