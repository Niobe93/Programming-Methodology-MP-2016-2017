package uo238096.sesion09.queue;

import uo238096.sesion09.collections.LinkedList;

/**
 * Title: LinkedListQueue
 * 
 * @author Gema Rico Pozas
 * @version 1.0
 */

public class LinkedListQueue extends ListQueue  {

	public LinkedListQueue() {
		super(new LinkedList());
	}
}
