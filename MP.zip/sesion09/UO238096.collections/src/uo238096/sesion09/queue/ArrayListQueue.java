package uo238096.sesion09.queue;

import uo238096.sesion09.collections.ArrayList;

/**
 * Title: ArrayListQueue
 * 
 * @author Gema Rico Pozas
 * @version 1.0
 */
public class ArrayListQueue extends ListQueue {

	public ArrayListQueue() {
		super(new ArrayList());
	}
}
