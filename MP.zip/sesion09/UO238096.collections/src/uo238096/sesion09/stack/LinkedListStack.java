package uo238096.sesion09.stack;

import uo238096.sesion09.collections.LinkedList;

/**
 * Title: LinkedListStack
 * 
 * @author Gema Rico Pozas
 * @version 1.0
 */
public class LinkedListStack extends ListStack implements Stack {

	public LinkedListStack() {
		super(new LinkedList());

	}
}