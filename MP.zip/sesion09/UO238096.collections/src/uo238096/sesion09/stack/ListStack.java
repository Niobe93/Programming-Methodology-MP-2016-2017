package uo238096.sesion09.stack;

import uo238096.sesion09.collections.List;

/**
 * Title: ListStack
 * 
 * @author Gema Rico Pozas
 * @version 1.0
 */

public class ListStack {

	public final static int TOP = 0; // cima de la pila
	private List list;

	public ListStack(List list) {
		this.list = list;
	}

	/**
	 * a�ade un elemento en la parte superior de la pila
	 * 
	 * @param element
	 *            El objeto que se a�ade
	 */
	public void push(Object element) {
		checkElement(element);
		list.addFirst(element);

	}

	/**
	 * Devuelve el objeto del tope de de la pila sin borrarlo
	 * 
	 * @return El objeto del tope de la pila
	 */
	public Object peek() {
		if (this.isEmpty())
			return null;
		return list.get(TOP);
	}

	/**
	 * Borra y devuelve el objeto del tope de la pila
	 * 
	 * @return El objeto borrado de la pila
	 */
	public Object pop() {
		if (isEmpty())
			return null;
		Object toReturn = list.get(TOP);
		list.remove(TOP);
		return toReturn;

	}

	/**
	 * Devuelve el n�mero de elementos que hay en la pila
	 * 
	 * @return El n�mero de elementos de la pila
	 */
	public int size() {
		return list.size();
	}

	/**
	 * Indica si la pila est� vac�a o no
	 * 
	 * @return true si la pila est� vac�a; false en caso contrario.
	 */
	public boolean isEmpty() {
		return list.isEmpty();
	}

	private void checkElement(Object object) {
		if (object == null)
			throw new IllegalArgumentException(
					"Error el par�metro no puede ser null");
	}

}
