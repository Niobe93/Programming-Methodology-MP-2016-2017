package uo238096.sesion08.collections;

public class LinkedListTest extends ListTest {

	
	
	@Override
	protected List createList() {
		return new LinkedList();
	}

}
