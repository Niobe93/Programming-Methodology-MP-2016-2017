package uo238096.sesion08.collections;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ ArrayListTest.class, LinkedListTest.class })
public class AllTests {

}
