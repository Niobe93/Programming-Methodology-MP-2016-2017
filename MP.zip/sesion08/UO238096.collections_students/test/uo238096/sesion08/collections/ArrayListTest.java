package uo238096.sesion08.collections;

public class ArrayListTest extends ListTest {

		
	@Override
	protected List createList() {
		return new ArrayList();
	}

}

