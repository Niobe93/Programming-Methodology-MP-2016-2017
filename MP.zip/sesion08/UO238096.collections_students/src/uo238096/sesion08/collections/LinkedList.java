package uo238096.sesion08.collections;

import java.util.Iterator;

/**
 * Title: LinkedList
 * @author Gema Rico Pozas
 * @version 1.0
 */

public class LinkedList implements List {
	private class Node{
		private Object value;
		private Node next;
		
		Node(Object value, Node next) {
			this.value = value;
			this.next = next;
		}		
	}
	private Node head;
	private int numberOfElements;
	

	@Override
	public boolean contains(Object o) {		
		return false;
	}

	@Override
	public int size() {		
		return numberOfElements;
	}

	@Override
	public boolean isEmpty() {
		if (this.size()==0)
		   return true;
		else 
		   return false;
	}

	@Override
	public void add(Object element) {
		checkElement(element);
		if(this.isEmpty()== true){
			head = new Node(element, null);	}
		else {
			Node last = getNode(size()-1);
			last.next = new Node(element, null);}		
		numberOfElements++;}
	

	@Override
	public Object remove(Object element) {
		checkElement(element);
		checkState();
		int position = this.search(element);
		if (position != -1)
		    return this.remove(position);		
		return null;}

	@Override
	public void clear() {
		head = null;
		numberOfElements= 0;}
	
		@Override
	public void add(int index, Object element) {
		checkElement(element);}

	@Override
	public Object remove(int index) {
		if ((index <0)| index > this.size())
			throw new RuntimeException ( "Error el par�metro es incorrecto");
		if (isEmpty()) return null;
		Object value;
		if (index == 0){
			value = head.value;
			head = head.next;}
		else {
			Node previous = getNode(index - 1);
			value = previous.next.value;
			previous.next = previous.next.next;	}
		
		numberOfElements--;
		return value; }

	@Override
	public int indexOf(Object o) {	
		checkElement(o);
		return this.search(o);}

	@Override
	public Object get(int index) {		
		return null;}

	@Override
	public Object set(int index, Object element) {	
		return null;}

	@Override
	public boolean equals(Object o){
		if(o == this)
			return true;
		if(!(o instanceof List))
			return false;
		List other = (List) o;
		if (this.size() != other.size())
			return false;
		int index= 0;
		for (Node node = head ; node!= null; node= node.next)
			if (!(node.value.equals(other.get(index))))
				return false;
			index ++;
		return true;
	}
	
	@Override
	public int hashCode(){
		int hashCode = 1;
	      for(Node node = head ; node!= null; node= node.next)
	          hashCode = 31 * hashCode + (node == null ? 0 : node.hashCode());
		return  hashCode;
	}
	@Override
	public String toString(){
		StringBuilder sb = new StringBuilder("[");
		Node node = head;
		if (this.isEmpty()==false){
		     for ( int i = 0; i <size()-1; i ++){
			     sb.append(node.value.toString()).append(", ");
			     node=node.next;}
		sb.append(node.value.toString());
		}
		sb.append("]");
		return sb.toString();	
		
	}
	private Node getNode(int index){
		if ( index <0)
			throw new RuntimeException ( "Error el par�metro no puede ser negativo");
		Node node = head;
		int position = 0;
		while (position < index){
			node = node.next;
			position++;}
		return node;		
	}
	
	private int search(Object element){
		Node node = head;
		int position = 0;
		while (position < size()){
			if ( node.value.equals(element))
				return position;
			node = node.next;
			position++;	}
		return position;}		
	
	
	private void checkElement(Object object){
		if ( object == null)			
			throw new IllegalArgumentException("Error el par�metro no puede ser null");	}
	
	private void checkState(){
		if (isEmpty())			
			throw new IllegalStateException("Error la lista esta vacia");}

	@Override
	public Iterator<Object> iterator() {		
		return new LinkedListIterator();}
	
	// implementaciobn de iterador
	
	private class LinkedListIterator implements Iterator<Object>{
		
		private Node next = head;
		private Node lastReturn = null;
		
		@Override
		public boolean hasNext() {
			return next!= null;  // devuelve true si hay elementos en la coleccion y next es distinto de null
		}

		@Override
		public Object next() {
			lastReturn= next;
			next= next.next;
			return lastReturn.value;}			
	}	
	
	
}
