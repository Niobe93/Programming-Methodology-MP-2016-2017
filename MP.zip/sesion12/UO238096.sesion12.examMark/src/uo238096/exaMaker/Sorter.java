package uo238096.exaMaker;

import java.util.Comparator;


import java.util.LinkedList;
import java.util.List;



public class Sorter {
	public static void sort(List<Mark> list) {
		List<Mark>tmp= new LinkedList<Mark>();
		for (Mark v : list){
			int pos = searchPosition(v,tmp);
			tmp.add(pos,v);	}
		copyFromTo(tmp, list);

	}

	public static void sort(List<Mark> list, Comparator<Mark> comparator) {
		List<Mark>tmp = new LinkedList<>();
		for (Mark v : list){
			int pos = searchPosition(v,tmp, comparator);
			tmp.add(pos,v);	}
		copyFromTo(tmp, list);
	}
	
	
	private static int searchPosition(Mark v, List<Mark> tmp,Comparator<Mark> comparator) {
		for (int i = 0; i < tmp.size(); i++){
			Mark current = tmp.get(i);
			 if (comparator.compare(v,current) <0){
				 return i; }
			}			 
		return tmp.size();	}
	

	private static void copyFromTo(List<Mark> fromInitial, List<Mark> toFinal) {
		toFinal.clear();
		for(Mark v: fromInitial) {
			toFinal.add( v );}
	}
	
	private static int searchPosition(Mark v, List<Mark>tmp){
		for (int i = 0; i < tmp.size(); i++){
			Mark current = tmp.get(i);
		 if ( v.compareTo(current)<0)
			 return i;
		}			 
	return tmp.size();}

}
