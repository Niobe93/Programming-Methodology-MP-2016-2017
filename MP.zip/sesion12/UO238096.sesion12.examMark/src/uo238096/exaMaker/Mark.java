package uo238096.exaMaker;

public class Mark implements Comparable<Mark>{
    String student;
	
	String value;
	
	
	
	public Mark(String student, String value) {
		super();
		this.student = student;
		this.value = value;
	}

	public String getID() {
		return student;
		
	}

	public String getValue() {
		
		return value;
	}
	public String serialize(){
			return String.format("%s\t%s",getID(), getValue());

	}
	@Override
	public int compareTo (Mark m){
		return this.getID().compareTo(m.getID());		
	}

}
