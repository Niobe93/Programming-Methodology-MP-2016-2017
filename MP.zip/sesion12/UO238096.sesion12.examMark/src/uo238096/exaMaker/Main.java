package uo238096.exaMaker;

import java.io.FileNotFoundException;
import java.util.List;


public class Main {

	private static final String EXAM_MODEL_FILE = "exam.model.txt";
	private static final String ANSWERS_FILE_GZ = "answers.txt.gz";
	//private static final String ANSWERS_FILE = "answers.txt";
	private static final String RESULTS_FILE = "results.txt";

	public static void main(String[] args) {
		new Main().run();
	}

	private void run()  {
		  
			try {
				execute();
			} catch (RuntimeException e){
				handleSystemError(e);
			} catch (Exception e) {
				handleUserError(e);	
			}
		}

	private void execute() throws FileNotFoundException {
		ExamMarker ex = new ExamMarker();
		ex.loadQuestions( EXAM_MODEL_FILE );
		//ex.loadAnswers( ANSWERS_FILE );
		ex.loadAnswersForZip(ANSWERS_FILE_GZ);
		ex.mark();
		showMarks( ex.getMarks());
		showMarks( ex.getMarksByMark() );
		showMarks( ex.getMarksByIDStudent() );
		ex.saveResults( RESULTS_FILE );
	}

	private void showMarks(List<Mark> marks) {
		System.out.println("---------------------------------------------");
		System.out.println("Lista de notas");
		for(Mark mark: marks) {
			System.out.println( mark.getID() + " " + mark.getValue() );
		}
	}
	

	private void handleSystemError(RuntimeException e) {
		String msg = "Ha ocurrido un error. "
				+ e.getMessage()
				+ "\nEl programa debe finalizar. "
				+ "Por favor, contacta con tu administrador";
		System.out.println( msg );
		e.printStackTrace();
	}

	private void handleUserError(Exception e) {
		String msg = "Ha ocurrido un error al proceasar la operaci�n. "
				+ e.getMessage()
				+ "\nPor favor, soluciona el problema e int�ntalo de nuevo";
		System.out.println( msg );
	}

}
