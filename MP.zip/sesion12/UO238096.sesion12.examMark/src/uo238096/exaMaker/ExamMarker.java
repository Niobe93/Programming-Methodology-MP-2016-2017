package uo238096.exaMaker;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import uo238096.comparator.IdComparator;
import uo238096.comparator.MarkComparator;
import uo238096.delivery.Delivery;
import uo238096.exaMaker.Mark;
import uo238096.fileUtil.FileUtil;
import uo238096.fileUtil.ZipFile;
import uo238096.parser.DeliveryParser;
import uo238096.parser.QuestionParser;
import uo238096.question.Question;





public class ExamMarker {

	private List<Question> questions = new ArrayList<>();
	private List<Delivery> answers = new ArrayList<>();
	private List<Mark> marks = new ArrayList<>();

	public void loadQuestions(String examModelFile) throws FileNotFoundException {
		List<String> lines = new FileUtil().loadLines( examModelFile );
		List<Question> questions = new QuestionParser().parse( lines );
		addQuestions( questions );
	}
	
	public void loadQuestionsForZip(String examModelFile) throws FileNotFoundException {
		List<String> lines = new ZipFile().loadLines( examModelFile );
		List<Question> questions = new QuestionParser().parse( lines );
		addQuestions( questions );
	}
	
    public void saveResults(String resultsFile) {
    	List<String>res = this.serialize(getMarks());
        new FileUtil().saveToFile(resultsFile, res);
   	}
	

	private void addQuestions(List<Question> quests) {
		for ( Question d : quests){
			   questions.add(d);
		}
	}

	public void loadAnswers(String answersFile) throws FileNotFoundException {
		List<String> lines = new FileUtil().loadLines( answersFile );
		List<Delivery> answers = new DeliveryParser().parse( lines );
		addAnswers( answers );
	}
	public void loadAnswersForZip(String answersFile) throws FileNotFoundException {
		List<String> lines = new ZipFile().loadLines( answersFile );
		List<Delivery> answers = new DeliveryParser().parse( lines );
		addAnswers( answers );
	}

	private void addAnswers(List<Delivery> ans) {
		for ( Delivery d : ans){
			   answers.add(d);
		}
	}
	
	public void mark() {
		String id = "";
		String respuesta;
		Double finalnote=0.0;
		Question pregunta;		
		List<String> res = new ArrayList<>();
		for (Delivery d : answers) {
			finalnote=0.0;
			id = d.getID();
			copyFromTo(d.getAnswers(), res);
			for (int i = 0; i < res.size(); i++) {
				respuesta = res.get(i);				
				pregunta = questions.get(i);
				finalnote = finalnote+ pregunta.getMarkForAnswer(respuesta);}
			marks.add(new Mark(id, String.valueOf(finalnote)));}
		} 	  
	
	
	
	private List<String> serialize ( List<Mark> marks){
		List<String>res = new ArrayList<>();
		for (Mark nota:marks){
			res.add(nota.serialize());
		}
		
		return res;		
	}
	private static void copyFromTo(List<String> fromInitial, List<String> toFinal) {
		toFinal.clear();
		for(String s: fromInitial) {
			toFinal.add( s );}
	}
	
	public List<Mark> getMarks() {
		return new ArrayList<>( marks );
	}

	public List<Mark> getMarksByIDStudent() {
		Sorter.sort(marks, new IdComparator());
		return	marks;
		}

	public List<Mark> getMarksByMark() {
		Sorter.sort(marks, new MarkComparator());
		return	marks;
		}
	}

	
	
	
	



