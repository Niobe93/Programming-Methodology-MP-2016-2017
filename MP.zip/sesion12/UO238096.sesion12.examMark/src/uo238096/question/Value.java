package uo238096.question;

public class Value extends Question {

	private double value;
	
	public Value(int number, double weight, double value) {
		super(number, weight);
		this.value= value;		
	}

	public double getValue() {
		return value;
	}

	@Override
	public double getMarkForAnswer(String answer) {
		double res = Double.parseDouble(answer);
		if((value <= res+0.1)|(value >= res-0.1))
		   return super.getWeight();
		else
			return super.getWeight()-(super.getWeight()*0.1);
	}

	
}
