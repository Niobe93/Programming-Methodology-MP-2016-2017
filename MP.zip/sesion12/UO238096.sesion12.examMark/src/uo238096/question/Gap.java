package uo238096.question;

public class Gap extends Question {

	private String correctWord;
	
	public Gap(int number, double weight, String correctWord) {
		super(number, weight);
		this.correctWord= correctWord;
	}

	public String getCorrectWord() {
		return correctWord;
	}

	@Override
	public double getMarkForAnswer(String answer) {
		if(answer.equals(correctWord))
		  return super.getWeight();
		else
			return 0;
	}

	
}
