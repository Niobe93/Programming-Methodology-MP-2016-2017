package uo238096.question;

public class Choice  extends Question{
	
	private String option;
	
	public Choice(int number, double weight, String option) {
		super(number, weight);
		this.option=option;
	}
	
	public String getOption() {
		return option;
	}

	@Override
	public double getMarkForAnswer(String answer) {
		if(answer.equals(option))
			return super.getWeight();
		else
			return super.getWeight()-(super.getWeight()*0.2);
	}
	
	
}
