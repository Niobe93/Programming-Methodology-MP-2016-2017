package uo238096.question;

public abstract class Question {

	private int number ; //numero que tiene asignada la pregunta en el examen
	private double weight; //peso , valor del examen final
	
	
	public Question(int number, double weight) {
		super();
		this.number = number;
		this.weight = weight;
	}


	public int getNumber() {
		return number;
	}


	protected double getWeight() {
		return weight;
	}
	
	public abstract double getMarkForAnswer(String answer);		
		
	
}
