package uo238096.parser;

import java.util.LinkedList;
import java.util.List;







import uo238096.exception.InvalidLineFormatException;
import uo238096.question.Choice;
import uo238096.question.Gap;
import uo238096.question.Question;
import uo238096.question.Value;

public class QuestionParser {

	public List<Question> parse(List<String> lines) {
		List<Question> questions = new LinkedList<Question>();

		for (int ln = 0; ln < lines.size(); ln++) {
			String line = lines.get(ln);
			try {
				assertNotBlank(line);

			} catch (InvalidLineFormatException e1) {
				System.err.println("Error: l�nea en blanco");
				continue;
			}

			Question q;

			try {
				q = parseLine(line, ln);
				questions.add(q);
			} catch (InvalidLineFormatException e) {
				System.err.println("Error: formato de l�nea incorrecto");
				continue;
			}

		}
		return questions;
	}
	
	

	
	private Question parseLine(String line, int ln) throws InvalidLineFormatException{
		this.assertNotBlank(line);
		String [] parts = line.split("\t");
		assertThreeData(parts);		
	    return createQuestion(parts,ln);}
	
		
	private Question createQuestion(String [] parts, int ln) throws InvalidLineFormatException{
		String typeQuestion = parts[0];
		Double weight =  Double.parseDouble(parts[1]);	
		String answer = parts[2];			
		Object question = null;
		
				
		if (typeQuestion.equals("gap"))	
			question = new Gap(ln, weight, answer );
		    
		else if (typeQuestion.equals("choice"))	
			question = new Choice(ln, weight, answer);
		
		else if (typeQuestion.equals("value"))	
			question = new Value(ln, weight,Double.parseDouble(answer) );		
		else 
			throw new InvalidLineFormatException(typeQuestion + " El tipo de pregunta no es v�lida ");
		
		return (Question) question;	
		
	}
	
	
	private boolean assertNotBlank(String line) throws InvalidLineFormatException{
		if ((line==null) || (line.length()==0))
			throw new InvalidLineFormatException("L�nea en blanco: " + line);
		return false;
	}
	
	
	private void assertThreeData(String[]parts) throws InvalidLineFormatException {
		if ( parts.length != 3)	
			throw new InvalidLineFormatException("N�mero de campos incorrecto: " + parts.length);			
		} 
    
	}


