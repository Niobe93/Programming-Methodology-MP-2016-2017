package uo238096.parser;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import uo238096.delivery.Delivery;
import uo238096.exception.InvalidLineFormatException;

public class DeliveryParser {

	public List<Delivery> parse(List<String> lines) {
		List<Delivery> answers = new LinkedList<Delivery>();

		for (int ln = 0; ln < lines.size(); ln++) {
			String line = lines.get(ln);
			try {
				assertNotBlank(line);

			} catch (InvalidLineFormatException e1) {
				System.err.println("Error: l�nea en blanco");
				continue;
			}

			Delivery a;

			try {
				a = parseLine(line);
				answers.add(a);
			} catch (InvalidLineFormatException e) {
				System.err.println("Error: formato de l�nea incorrecto");
				continue;
			}

		}
		return answers;
	}
	
	

	
	private Delivery parseLine(String line) throws InvalidLineFormatException{
		this.assertNotBlank(line);
		String [] parts = line.split("\t");
		return createDelivery(parts);}
	
		
	private Delivery createDelivery(String [] parts) throws InvalidLineFormatException{
		String ID = parts[0];
		List<String> answers = new ArrayList<>();
		for (int i = 1; i < parts.length; i++){
		      answers.add(parts[i]);}		
		Object delivery =  new Delivery(ID, answers);		
		return (Delivery) delivery;			
	}
	
	
	private boolean assertNotBlank(String line) throws InvalidLineFormatException{
		if ((line==null) || (line.length()==0))
			throw new InvalidLineFormatException("L�nea en blanco: " + line);
		return false;
	}	
    
	}


