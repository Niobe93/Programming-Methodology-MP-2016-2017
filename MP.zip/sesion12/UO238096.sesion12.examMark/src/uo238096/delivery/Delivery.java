package uo238096.delivery;

import java.util.List;

public class Delivery {

	String ID;
	List<String>answers;
	
	public Delivery(String ID, List<String>answers) {		
		setID(ID);
		setAnswers(answers);
	}
	
	public void setAnswers(List<String> answers) {
		this.answers = answers;
	}

	public String getID() {
		return ID;
	}
	private void setID(String iD) {
		ID = iD;
	}
	public List<String> getAnswers() {
		return answers;
	}
	public String getAnswer(int position){		
		return answers.get(position);		
	}
	public void addAnswer(String answer){
		answers.add(answer);
	}
	
	
}
