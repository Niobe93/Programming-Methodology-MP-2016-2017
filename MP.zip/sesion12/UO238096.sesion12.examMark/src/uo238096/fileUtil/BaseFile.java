package uo238096.fileUtil;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public abstract class BaseFile {

	protected abstract BufferedReader createReaderChain(String inFileName)
			throws FileNotFoundException;

	protected abstract BufferedWriter createWriterChain(String outFileName);

	public List<String> loadLines(String inFileName)
			throws FileNotFoundException {
		BufferedReader in = createReaderChain(inFileName);
		List<String> res = new LinkedList<>();

		try {
		while (in.ready()) {
			res.add(in.readLine());	}
		}
		catch (IOException e) {
			throw new RuntimeException(e);	
		} 
		finally 
		{close(in);}
		
		return res;
	}

	public void saveToFile(String outFileName, List<String> lines) {

		BufferedWriter out =  createWriterChain(outFileName);

		try {
			for (String line : lines) {				
				out.write(line);
				out.newLine();
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		} finally {
			close(out);
		}
	}


	private void close(Closeable in) {
		try {in.close();} 
		catch (IOException e) {
			throw new RuntimeException(e);}	
		}
}
