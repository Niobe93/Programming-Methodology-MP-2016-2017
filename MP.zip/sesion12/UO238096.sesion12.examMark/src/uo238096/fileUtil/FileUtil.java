package uo238096.fileUtil;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileUtil extends BaseFile{

	@Override
	protected BufferedReader createReaderChain(String inFileName)throws FileNotFoundException{
		return new BufferedReader(new FileReader(inFileName));
	}

	@Override
	protected BufferedWriter createWriterChain(String examModelFile) {
		try {
			return new BufferedWriter(new FileWriter(examModelFile));
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		
	}	
}