package uo238096.fileUtil;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class ZipFile extends BaseFile{

	@Override
	protected BufferedReader createReaderChain(String inFileName) throws FileNotFoundException {
		try {
			return new BufferedReader(new InputStreamReader(new GZIPInputStream 
					(new FileInputStream(inFileName))));
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		
		
	}

	@Override
	protected BufferedWriter createWriterChain(String outFileName) {
		try {
			return new BufferedWriter(new OutputStreamWriter
					(new GZIPOutputStream (new FileOutputStream(outFileName))));
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		
	}	
	
	 
	
	 
	

}

