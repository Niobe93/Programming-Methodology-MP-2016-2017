package uo238096.comparator;

import java.util.Comparator;

import uo238096.exaMaker.Mark;

public class IdComparator implements Comparator<Mark>{

	@Override
	public int compare(Mark mark1, Mark mark2) {		
		return (mark1.getID().compareTo(mark2.getID()));
	}
}
