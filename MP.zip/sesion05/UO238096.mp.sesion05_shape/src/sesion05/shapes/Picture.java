package sesion05.shapes;

import java.io.PrintStream;

/**
 * Title: Picture * 
 * @author Gema Rico Pozas
 * @version 1.0
 */

public class Picture implements Drawable {
	private int scale;
	private String name;
	private int posX;
	private int posY;

	/**
	 * Constructor de la clase triangle con par�metros
	 * 
	 * @param posY coordenada eje y vertice 1
	 * @param posX coordenada eje x vertice 1
	 * @param name nombre de la fotografia
	 * @param scale escala de la fotografia
	 */
	public Picture(int scale, String name, int posX, int posY) {
		setScale(scale);
		setName(name);
		setPosX(posX);
		setPosY(posY);
	}

	// GETTERS Y SETTERS
	/**
	 * M�todo que modifica el atributo scale
	  */
	private void setScale(int scale) {
		this.scale = scale;}

	/**
	 * M�todo que modifica el atributo name
	 */
	private void setName(String name) {
		this.name = name;}

	/**
	 * M�todo que modifica el atributo posX
	 */
	private void setPosX(int posX) {
		this.posX = posX;}

	/**
	 * M�todo que modifica el atributo posY
	 */
	private void setPosY(int posY) {
		this.posY = posY;}

	/**
	 * M�todo que devuelve el valor del atributo scale
	 */
	public int getScale() {
		return scale;}

	/**
	 * M�todo que devuelve el valor del atributo name
	 */
	public String getName() {
		return name;}

	/**
	 * M�todo que devuelve el valor del atributo posX
	 */
	public int getPosX() {
		return posX;}

	/**
	 * M�todo que devuelve el valor del atributo posY
	 */
	public int getPosY() {
		return posY;}
	
	
	/**
	* M�todo que simula dibujar una fotografia
	*/
	public void draw(PrintStream out) {
	}

}
