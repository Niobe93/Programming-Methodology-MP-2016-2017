package sesion05.shapes;

import java.io.PrintStream;
/**
 * Title: Drawable 
 * @author Gema Rico Pozas
 * @version 1.0
 */

//INTEFAZ DRAWABLE
public interface Drawable {
	void draw(PrintStream out);
}
