package sesion05.shapes;

import java.io.PrintStream;
import java.util.ArrayList;

/**
 * Title: Dibujo
 * Description: Clase que contiene las figuras que ser�n dibujadas.
 * Copyright: Copyright (c) 2017
 * Escuela de Ingenier�a Inform�tica
 * Metodolog�a de la Programaci�n 
 * @author Profesores de Metodolog�a de la programaci�n
 * @version 1.0
 */


//CLASE DRAWING
public class Drawing {

	private ArrayList<Drawable> drawables;
	
	/**
	 * Constructor de la clase drawing 
	 */
	public Drawing(){
		drawables = new ArrayList<Drawable>();		
	}		
	/**
	 * M�todo que a�ade a la colecci�n objetos drawables
	 * 
	 *@param objeto de la interfaz drawable
	 */
	 public void add(Drawable drawable) {
		drawables.add(drawable);}

	/**
	 * Muestra por consola el dibujo de cada objeto drawable
	 */
	  public void draw(PrintStream out) {
		for(Drawable drawable: drawables){
			drawable.draw(out);}
		}
	

}

