package sesion05.shapes;

/**
 * Title: Colour
 * @author Gema Rico Pozas
 * @version 1.0
 */


public class Colour {

	public static enum Colouring {RED,ORANGE,BLACK,WHITE,PINK,BLUE,GREEN,YELLOW;	
	}
}
