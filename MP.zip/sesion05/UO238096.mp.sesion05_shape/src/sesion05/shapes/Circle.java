package sesion05.shapes;

import java.io.PrintStream;

import sesion05.shapes.Colour.Colouring;

/**
 * Title: Circle 
 * @author Gema Rico Pozas
 * @version 1.0
 */

public class Circle implements Drawable {
	private int posX;
	private int posY;
	private int radius;
	private Colouring colour;
	
	/**
	* Constructor de la clase circle con par�metros
	* 
	* @param posY coordenada eje y
	* @param posX coordenada eje x
	* @param colour color
	* @param int radius 
	*/	
	public Circle(int posY, int posX, int radius, Colouring colour) {
		setPosY(posY);
		setPosX(posX);
		setRadius(radius);
		setColour(colour);
	}

	// GETTERS Y SETTERS
	/**
	 * M�todo que modifica el atributo color
	 */
	private void setColour(Colouring colour) {
		this.colour = colour;}

	/**
	 * M�todo que modifica el atributo posX
	 */
	private void setPosY(int posY) {
		this.posY = posY;}

	/**
	 * M�todo que devuelve el valor de color
	 */
	public Colouring getColour() {
		return colour;}

	/**
	 * M�todo que modifica el atributo posX
	 */
	private void setPosX(int posX) {
		this.posX = posX;}

	/**
	 * M�todo que devuelve el valor de posX
	 */
	public int getPosX() {
		return posX;}

	/**
	 * M�todo que devuelve el valor de posY
	 */
	public int getPosY() {
		return posY;}

	/**
	 * M�todo que devuelve el valor de radius
	 */
	public int getRadius() {
		return radius;}
	/**
	* M�todo que modifica el valor del radius
	*/
	private void setRadius(int radius) {
		this.radius = radius;}
	
	
	/**
	* M�todo que simula dibujar un c�rculo
	*/
	public void draw(PrintStream out) {
		out.print("Dibujando el c�rculo: ");
		out.print(" Centro del c�rculo: " + "(" + getPosX() + ", " + getPosY()
				+ ")");
		out.print(" Radio: " + getRadius() + " ");
		out.println("Se empieza a dibujar en X= " + (getRadius() + getPosX()));
	}

}
