package sesion05.shapes;

import java.io.PrintStream;

import sesion05.shapes.Colour.Colouring;

/**
 * Title: Rect�ngulo    
 * @author Gema Rico Pozas
 * @version 1.0
 */

public class Rectangle implements Drawable {
    private int posX;
    private int posY;    
	private int width;
	private int height;
	private Colouring colour;
	
/**
* Constructor de la clase rectangle con par�metros
* 
* @param posY coordenada eje y
* @param posX coordenada eje x
* @param colour color
* @param width anchura
* @param height  altura
* 
*/	
	public Rectangle(int posY,int posX, int width, int height,Colouring colour) {
		setPosY(posY);
		setPosX(posX);
	    setWidth( width);
		setHeight(height);
		setColour(colour);
	}	
//GETTERS Y SETTERS
	/**
	* M�todo que  modifica el atributo color
	*/
	private void setColour(Colouring colour) {
		this.colour = colour;}
	/**
	* M�todo que   modifica el atributo posX
	*/
	private void setPosY(int posY) {
		this.posY = posY;}
	/**
	* M�todo que devuelve el valor de color
	*/
	public Colouring getColour() {
		return colour;}
	/**
	* M�todo que  modifica el atributo posX
	*/
	private void setPosX(int posX) {
		this.posX = posX;}
	/**
	* M�todo que devuelve el valor de posX
	*/
	public int getPosX() {
		return posX;}
	/**
	* M�todo que devuelve el valor de posY
	*/
	public int getPosY() {
		return posY;}
	/**
	* M�todo que devuelve el valor de width
	*/
	public int getWidth() {
		return width;}
	/**
	* M�todo que modifica el atributo width
	*/
	private void setWidth(int width) {
		this.width = width;}
	/**
	* M�todo que devuelve el valor de height
	*/
	public int getHeight() {
		return height;}
	/**
	* M�todo que modifica el atributo height
	*/
	private void setHeight(int height) {
		this.height = height;}	
	
	/**
	* M�todo que simula dibujar un rect�ngulo
	*/
	
	public void draw(PrintStream out) {
		out.print("Dibujando el rectangulo: "+"(" + getPosX() + ", " + getPosY() + ")");		
		out.println("(" + (getPosX()+ getHeight()) + ", "+ (getWidth()-getPosY())+ ")");
	
	}
}
		
	


	

