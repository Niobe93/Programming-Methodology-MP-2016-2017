package sesion05.shapes;

import java.io.PrintStream;

import sesion05.shapes.Colour.Colouring;

/**
 * Title: Triangle
 * @author Gema Rico Pozas
 * @version 1.0
 */
public class Triangle implements Drawable{
	private int posX;
	private int posY; 	
	private int posX2;	
	private int posY2; 
	private int posX3;	
	private int posY3;	
	private Colouring colour;
	
	/**
	* Constructor de la clase triangle con par�metros
	* 
	* @param posY coordenada eje y vertice 1
	* @param posX coordenada eje x vertice 1
	* @param colour color
	* @param posY1 coordenada eje y vertice 2
	* @param posX1 coordenada eje x vertice 2
	* @param posY2 coordenada eje y vertice 3
	* @param posX2 coordenada eje x vertice 3 
	*/		
	public Triangle(int posY,int posX, int posX2, int posY2, int posX3,int posY3,Colouring colour) {	
		setPosX(posX); 
		setPosY(posY);
		setPosX2(posX2)	;
		setPosY2(posY2);
		setPosX3(posX3);
	    setPosY3(posY3); 
	    setColour(colour);
	}
	// GETTERS Y SETTERS
	/**
	 * M�todo que modifica el atributo posX
	 */
	private void setPosX(int posX) {
		this.posX = posX;}
	/**
	 * M�todo que modifica el atributo posY
	 */
	private void setPosY(int posY) {
		this.posY = posY;}
	/**
	 * M�todo que modifica el atributo posX2
	 */
	private void setPosX2(int posX2) {
		this.posX2 = posX2;}
	/**
	 * M�todo que modifica el atributo posY2
	 */
	private void setPosY2(int posY2) {
		this.posY2 = posY2;	}
	/**
	 * M�todo que modifica el atributo posX3
	 */
	private void setPosX3(int posX3) {
		this.posX3 = posX3;	}
	/**
	 * M�todo que modifica el atributo posY3
	 */
	private void setPosY3(int posY3) {
		this.posY3 = posY3;	}
	/**
	 * M�todo que modifica el atributo color
	 */
	private void setColour(Colouring colour) {
		this.colour = colour;}
	/**
	 * M�todo que devuelve el valor del atributo posX
	 */
	public int getPosX() {
		return posX;}
	/**
	 * M�todo que devuelve el valor del atributo posY
	 */
	public int getPosY() {
		return posY;}
	/**
	 * M�todo que devuelve el valor del atributo color
	 */
	public Colouring getColour() {
		return colour;}
	/**
	 * M�todo que devuelve el valor del atributo posX2
	 */
	public int getPosX2() {
		return posX2;}
	/**
	 * M�todo que devuelve el valor del atributo posY2
	 */
	public int getPosY2() {
		return posY2;}
	/**
	 * M�todo que devuelve el valor del atributo posX3
	 */
	public int getPosX3() {
		return posX3;}
	/**
	 * M�todo que devuelve el valor del atributo posY3
	 */
	public int getPosY3() {
		return posY3;}
	
	
	/**
	* M�todo que simula dibujar un triangulo
	*/
	public void draw(PrintStream out){
		out.print("Dibujando el tri�ngulo: ");		
		}		


} 
	
	
	

