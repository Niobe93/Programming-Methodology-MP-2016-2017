package sesion05.shapes;

import sesion05.shapes.Colour.Colouring;

/**
 * Title: Aplicaci�n
 * Description: Clase para ejecutar la aplicaci�n.
 * Copyright: Copyright (c) 2016
 * Escuela de Ingenier�a Inform�tica
 * Metodolog�a de la Programaci�n 
 * @author  Profesores de Metodolog�a de la programaci�n
 * @version 1.0
 */
public class Application {
	
	/**
	 * M�todo principal para la ejecuci�n del programa
	 * 
	 * @param args No son usados
	 */
	public static void main(String[] args) {
		new Application().run();}
	
	/**
	 * Ejecuta la aplicaci�n
	 */
	public void run (){
		Drawing drawing = new Drawing();
		
		Rectangle rectangle1 = new Rectangle(0,0,10,10,Colouring.BLUE);		
		drawing.add(rectangle1);
		
		Rectangle rectangle2 = new Rectangle(3,4,0,0, Colouring.GREEN);		
		drawing.add(rectangle2);
		
		Circle circle1= new Circle(3, 5, 4, Colouring.YELLOW);
		drawing.add(circle1);	
		
		Circle circle2= new Circle(5, 8, 5, Colouring.WHITE);
		drawing.add(circle2);	
		
		Triangle triangle1= new Triangle(3, 6, 3, 5, 1, 6, Colouring.PINK);
		drawing.add(triangle1);	
		
		Triangle triangle2= new Triangle(3, 5, 1, 5, 4, 6, Colouring.BLACK);
		drawing.add(triangle2);	
		
		Picture picture1= new Picture(3,"Arbol", 0, 0);
		drawing.add(picture1);	

		Picture picture2= new Picture(5,"casa", 1, 0);
		drawing.add(picture2);	
		
		
		drawing.draw(System.out);
	}

}
