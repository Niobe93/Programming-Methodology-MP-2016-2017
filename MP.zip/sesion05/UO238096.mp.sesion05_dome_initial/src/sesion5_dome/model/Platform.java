package sesion5_dome.model;

public class Platform {
	public enum Platforms {XBOX, NINTENDO, PLAYSTATION};
}
