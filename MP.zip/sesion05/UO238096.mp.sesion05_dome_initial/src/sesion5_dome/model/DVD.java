package sesion5_dome.model;

import java.io.PrintStream;
/**
 * Title: DVD
 * @author Gema Rico Pozas
 * @version 1.0
 * */

public class DVD extends Item {
	private String director;
	private int playingTime;
	
	/**
	 * Constructor de la clase DVD con parametros
	 * @param theTitle titulo del DVD
	 * @param theBasePrice precio base del DVD
	 * @param theDirector el director del dvd
	 * @param time tiempo total reproducion 
	 */	
	public DVD(String theTitle,double theBasePrice, String theDirector, int time) {
		super(theTitle,theBasePrice);
		setDirector(theDirector);
		setPlayingTime(time);
	}

	// SETTERS AND GETTERS
	/**
	 * Metodo que modifica el valor del atributo director
	 */
	protected void setDirector(String director) {
		if (director.trim().isEmpty())
			throw new RuntimeException("Error: par�metro incorrecto");
		this.director = director;
	}

	/**
	 * Metodo que modifica el valor del atributo playingtime
	 */
	protected void setPlayingTime(int playingTime) {
		if (playingTime < 0)
			throw new RuntimeException("Error: par�metro incorrecto");
		this.playingTime = playingTime;
	}

	/**
	 * Metodo que devuelve el valor de baseprice
	 */
	public double getBasePrice() {
		return this.basePrice;}

	/**
	 * Metodo que devuelve el valor de playingtime
	 */
	public int getPlayingTime() {
		return this.playingTime;}

	/**
	 * Metodo que devuelve el valor de director
	 */
	public String getDirector() {
		return this.director;}

	/**
	 * Metodo que devuelve el valor de finalprice
	 */
	public double getFinalPrice() {
		return this.getBasePrice();}
		
		
	/**
	 *Metodo que imprime por pantalla el responsable del dvd
	 */				
	public void printResponsable(PrintStream out){
    	out.println("Responsable: " + getDirector());}
	
	 /**
	  *Metodo que devuelve una cadena con la informacion del cd
	  */
	public String toString() {
		String cadena="DVD: ";
		cadena += super.toString();
		cadena += (getPlayingTime() + " mins"+ "\n");
		cadena +=("Director: " +getDirector()+ "\n");
		cadena += "\n";		
		return cadena;
	}
	/**
	 *Metodo que compara dos objetos dvd
	 */
	@Override
	public boolean equals(Object item) {
		if (!(item instanceof DVD))
			return false;
		DVD dvd = (DVD)item;
		return ((dvd.getTitle().equals(this.getTitle())) && (dvd.getDirector().equals(this.getDirector())));
		   
		   
	}
	
}
		
	
