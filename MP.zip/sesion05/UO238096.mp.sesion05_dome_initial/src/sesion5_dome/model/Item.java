package sesion5_dome.model;

import java.io.PrintStream;
/**
 * Title: Item
 * @author Gema Rico Pozas
 * @version 1.0
 * */

public abstract class Item {

	private String title;
	private boolean gotIt;
	private String comment;
	protected double basePrice;
	
	/**
	 * Constructor de la clase Item sin parametros
	 */	
	public Item() {
		super();}
	
	/**
	 * Constructor de la clase Item con parametros
	 * @param title titulo del item
	 * @param basePrice precio base del item
	 */	
	public Item(String title,double basePrice) {
		super();
		setTitle(title);
		setOwn(true);
		setComment("Comment:");
		setBasePrice(basePrice);
	}
	
	// SETTERS AND GETTERS
	
	/**
	 * Metodo que modifica el valor del atributo title
	 */
	protected void setTitle(String title) {
		if ((title.trim().isEmpty()))
			throw new RuntimeException("Error: par�metro incorrecto");
		this.title = title;	}

	/**
	 * Metodo que modifica el valor del atributo baseprice
	 */
	protected void setBasePrice(double basePrice) {
		if ((basePrice < 0) | (basePrice > 10000))
			throw new RuntimeException("Error: par�metro incorrecto");
		this.basePrice = basePrice;	}

	/**
	 * Metodo que modifica el valor del atributo ownit
	 */
	protected void setOwn(boolean ownIt) {
		this.gotIt = ownIt;	}

	/**
	 * Metodo que modifica el valor del atributo comment
	 */
	protected void setComment(String comment) {
		if ((comment.trim().isEmpty())) {
			throw new RuntimeException("Error: par�metro incorrecto");}
		this.comment = comment;}

	/**
	 * Metodo que devuelve el valor del atributo comment
	 */
	public String getComment() {
		return comment;	}

	/**
	 * Metodo que devuelve el valor del atributo baseprice
	 */
	public double getBasePrice() {
		return basePrice;}

	/**
	 * Metodo que devuelve el valor del atributo own
	 */
	protected boolean getOwn() {
		return gotIt;}

	/**
	 * Metodo que devuelve el valor del atributo title
	 */
	protected String getTitle() {
		return this.title;}

	/**
	 * Metodo que devuelve el valor del atributo playingtime
	 */
	public int getPlayingTime() {
		return 0;}

	/**
	 * Metodo que devuelve el valor del atributo finalprice
	 */
	public abstract double getFinalPrice();
	
	
	/**
	 *Metodo que imprime por pantalla el responsable del Item
	 */		
	public void printResponsable(PrintStream out){}
	
	/**
	 *Metodo que devuelve una cadena con la informacion del item
	 */	
	public String toString() {
		String cadena = "";
		cadena= this.getTitle();
		if (getOwn()) {
			cadena += " * " + "\n";
		} else {
			cadena += "\n";
		}
		cadena+= getComment()+"\n"+ "Price " +getBasePrice()+"\n";		
		return cadena;
	}

	
}

	