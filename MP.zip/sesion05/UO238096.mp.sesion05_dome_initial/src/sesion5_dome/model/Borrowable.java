package sesion5_dome.model;

/**
 * Title: Borrowable
 * @author Gema Rico Pozas
 * @version 1.0
 * */
public interface Borrowable {
	
	boolean borrow();
	
	/**
	* M�todo devolver
	*/
	void giveBack();
	boolean isAvailableToBorrow();
	}



