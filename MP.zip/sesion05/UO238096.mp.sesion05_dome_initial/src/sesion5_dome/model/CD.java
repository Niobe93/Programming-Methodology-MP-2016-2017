package sesion5_dome.model;

import java.io.PrintStream;
/**
 * Title: CD
 * @author Gema Rico Pozas
 * @version 1.0
 * */

public class CD extends Item implements Borrowable {

	private String artist;
	private int numberOfTracks;
	private int playingTime;
	private boolean isAvailable;
	
	/**
	 * Constructor de la clase CD con parametros
	 * @param theTitle titulo del cd
	 * @param theBasePrice precio base del cd
	 * @param theArtist artista
	 * @param tracks pistas del cd
	 * @param time tiempo total reproducion 
	 */	
	public CD(String theTitle,double theBasePrice, String theArtist, 
			    int tracks, int time,boolean isAvailable) {
		super(theTitle,theBasePrice);
		setArtist(theArtist);
		setNumberOfTracks(tracks);
		setPlayingTime(time);
		setAvailable(isAvailable);
	}	

	//SETTERS AND GETTERS
	/**
	 *Metodo que modifica el valor del atributo artist
	 */
	 protected void setArtist(String artist) {
		if ( artist.trim().isEmpty())
			throw new RuntimeException("Error: par�metro incorrecto");
		this.artist = artist;}
	 /**
	  *Metodo que modifica el valor del atributo available
	  */
	 private void setAvailable(boolean isAvailable) {
			this.isAvailable = isAvailable;
		}
	/**
	 * Metodo que modifica el valor del atributo playingtime
	 */
	protected void setPlayingTime(int playingTime) {
		if (playingTime < 0)
			throw new RuntimeException("Error: par�metro incorrecto");
		this.playingTime = playingTime;
	}

	/**
	 * Metodo que modifica el valor del atributo numberoftracks
	 */
	protected void setNumberOfTracks(int numberOfTracks) {
		if (numberOfTracks <= 0)
			throw new RuntimeException("Error: par�metro incorrecto");
		this.numberOfTracks = numberOfTracks;
	}

	 /**
	 *Metodo que devuelve el valor de playingtime
	 */
	public int getPlayingTime() {
		return this.playingTime;}
	 /**
	 *Metodo que devuelve el valor de available
	*/
	public boolean isAvailable() {
		return isAvailable;
	}
	/**
	 *Metodo que devuelve el valor de preciobase
	 */
	public double getBasePrice() {
		return this.basePrice;}
	
	/**
	 *Metodo que devuelve el valor del finalprice
	 */
	public double getFinalPrice() {
		return  this.basePrice+2.00;}
	
	/**
	 *Metodo que devuelve el valor de artist
	 */
	public String getArtist() {
		return this.artist;	}
	
	/**
	 *Metodo que devuelve el valor de tracks
	 */
	public int getNumberOfTracks() {
		return this.numberOfTracks;	}
	
	
	/**
	 *Metodo que imprime por pantalla el responsable del cd
	 */	
    public void printResponsable(PrintStream out){
    	out.println("Responsable: " + getArtist());	
	}
    
    /**
	 *Metodo que devuelve una cadena con la informacion del cd
	 */
	public String toString() {
		String cadena="CD: ";
		cadena += super.toString();
		cadena += (getPlayingTime() + " mins"+ "\n");
		cadena +=("Artist: " + getArtist()+ "\n");
		cadena +=("Tracks: " + getNumberOfTracks()+"\n");
		cadena += "\n";
		
		return cadena;}
	
	/**
	 *Metodo que compara dos objetos cd
	 */
	 @Override
	 public boolean equals(Object item) {
		if (!(item instanceof CD))
			return false;
		CD cd = (CD)item;
		return ((cd.getTitle().equals(this.getTitle()))
				&& (cd.getArtist().equals(this.getArtist())));}
	
	
	 /**
	* M�todo que devuelve si un objeto est� disponible
	*/
	@Override
	public boolean isAvailableToBorrow() {
		 if ((getOwn()==true) && isAvailable == true)
	         return true;
		 return false;}
	

	/**
	* M�todo que presta un Cd
	*/
	@Override
	public boolean borrow() {
	     boolean previousValue = isAvailable;
	     isAvailable = false;
	     return previousValue; }
   /**
	* M�todo que devuelve un Cd
	*/
	@Override
	public void giveBack() {
	     isAvailable = true; }

}