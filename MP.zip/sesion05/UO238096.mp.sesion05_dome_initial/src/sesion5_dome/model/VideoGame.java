package sesion5_dome.model;

import sesion5_dome.model.Platform.Platforms;
/**
 * Title: VideoGame
 * @author Gema Rico Pozas
 * @version 1.0
 * */

public class VideoGame extends Item {
	
	public final static int MAX_PLAYERS = 50;
	private int numberOfPlayers;
	private String author;
	private Platforms platform;
	
	/**
	 * Constructor de la clase VG con parametros
	 * 
	 * @param theTitle titulo del VG
	 * @param theBasePrice precio base del VG
	 * @param theAuthor autor del VG
	 * @param thePlataform la plataforma de consola usada
	 * @param thePlayers numero de jugadores    
	 */
	public VideoGame(String theTitle, double theBasePrice, String theAuthor,
			Platforms thePlatform, int thePlayers) {
		
		super(theTitle, theBasePrice);
		setAuthor(theAuthor);
		setPlatform(thePlatform);
		setNumberOfPlayers(thePlayers);
	}

	// SETTERS AND GETTERS
	/**
	 * Metodo que modifica el valor del atributo numberofplayers
	 */
	protected void setNumberOfPlayers(int numberOfPlayers) {
		if ((numberOfPlayers <= 0) | (numberOfPlayers > 50))
			throw new RuntimeException("Error: par�metro incorrecto");
		this.numberOfPlayers = numberOfPlayers;
	}

	/**
	 * Metodo que modifica el valor del atributo autor
	 */
	protected void setAuthor(String author) {
		if ((author == null) | (author == (" ")))
			throw new RuntimeException("Error: par�metro incorrecto");
		this.author = author;
	}

	/**
	 * Metodo que modifica el valor del atributo plataforma
	 */
	protected void setPlatform(Platforms platform) {
		if (platform == null)
			throw new RuntimeException("Error: par�metro incorrecto");
		this.platform = platform;
	}
	
	/**
	 * Metodo que devuelve el valor de numberofplayers
	 */
	public int getNumberOfPlayers() {
		return numberOfPlayers;}

	/**
	 * Metodo que devuelve el valor de baseprice
	 */
	public double getBasePrice() {
		return this.basePrice;}

	/**
	 * Metodo que devuelve el valor de finalprice
	 */
	public double getFinalPrice() {
		return (this.basePrice * 0.1) + this.basePrice;}

	/**
	 * Metodo que devuelve el valor de plataform
	 */
	public Platforms getPlatform() {
		return platform;}

	/**
	 * Metodo que devuelve el valor de author
	 */
	public String getAuthor() {
		return author;}

	/**
	 * Metodo que devuelve el valor de playingtime
	 */
	public int getPlayingTime() {
		return 0;}
	
	
	/**
	 *Metodo que compara dos objetos videogame
	 */
	@Override
	public boolean equals(Object item) {
		if (!(item instanceof VideoGame))
			return false;
		VideoGame vg = (VideoGame)item;
		return ((vg.getTitle().equals(this.getTitle())) && (vg.getPlatform().equals(this.getPlatform())));
		     
	}
	
	 /**
	  *Metodo que devuelve una cadena con la informacion del videogame
	  */
	public String toString() {
		String cadena="VIDEOGAME: ";
		cadena += super.toString();
		cadena += ("Author: " + getAuthor()+ "\n");
		cadena += ("Plataform: " + getPlatform()+ "\n");
		cadena +=("Number of players: " + getNumberOfPlayers()+ "\n");
		cadena += "\n";
		
		return cadena;
	}

}
