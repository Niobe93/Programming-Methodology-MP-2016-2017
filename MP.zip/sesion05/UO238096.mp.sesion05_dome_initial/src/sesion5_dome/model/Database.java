package sesion5_dome.model;

import java.io.PrintStream;
import java.util.ArrayList;
/**
 * Title: Database
 * @author Gema Rico Pozas
 * @version 1.0
 * */
public class Database {

	private ArrayList<Item> items;
	private ArrayList<Borrowable> borrowableItems;
	
	/**
	 * Constructor de la clase Database 
	 */
	public Database() {
		this.items = new ArrayList<Item>();
		this.borrowableItems = new ArrayList<Borrowable>();
	}
	
	/**
	 *Metodo que a�ade a la coleccion de Items un objeto Item
	 *
	 *@param objeto item 
	 */	
	public void addItem(Item item) {
		if (item == null)
			throw new RuntimeException("Error, el par�metro no puede ser null");
		items.add(item);}
	
	/**
	 *Metodo que a�ade a las colecciones un objeto item y a la de borrowables si es un cd o un book
	 *
	 *@param objeto item 
	 *
	 */	
	public void add(Item theItem) {
		if (theItem == null)
			throw new RuntimeException("Error, el par�metro no puede ser null");
		items.add(theItem);
		if (theItem instanceof Borrowable)
		    borrowableItems.add((Borrowable)theItem);}
	
	/**
	 *Metodo que lista los items que pueden ser prestados
	 */		
	public void listBorrowableItems(PrintStream out) {
		for (Borrowable item: borrowableItems)
		     out.println(item);}
	/**
	 *Metodo que lista los items que se pueden prestar y est�n
	 * disponibles (no se han prestado a�n)
	 */		
	public void listAvailableItems(PrintStream out) {
		for (Borrowable item: borrowableItems)
		    if (item.isAvailableToBorrow()==true)
		        out.println(item);}
	/**
	 *Metodo que busca si hay un objeto borrowable en la coleccion
	 *
	 *@param un objeto borrowable
	 *@return null si no hay un objeto en la coleccion
	 *@return i como el objeto encontrado
	 */		
	private Borrowable search(Borrowable item) {
		if (item == null)
			throw new RuntimeException("Error, el par�metro no puede ser null");
		for(Borrowable i: borrowableItems){
		     if (i.equals(item)){
		    	 return i;}}
	    return null;}
	/**
	 *Metodo que presta un item que busca previamente que est� en la coleccion 
	 *
	 *@param un objeto borrowable
	 *@return null si no lo encuentra o no esta disponible
	 *@return el item prestado si se puede prestar
	 */			
	public Borrowable borrow(Borrowable item) {
		if (item == null)
			throw new RuntimeException("Error, el par�metro no puede ser null");		
		Borrowable theItem = search(item);
		
		if (theItem == null) 
			return null; 
		
		if (theItem.isAvailableToBorrow()== false)  
			return null;
		
		else{ 
		    theItem.borrow(); 
		    return theItem; }} 
	
	/**
	 *Metodo que devuelve un item que busca previamente que est� en la coleccion 
	 *
	 *@param un objeto borrowable
	 *@return false si no lo encuentra o ya estaba devuelto
	 *@return true si el  item se ha devuelto correctamente
	 */			 
	public boolean giveBack(Borrowable item) {
		if (item == null)
			throw new RuntimeException("Error, el par�metro no puede ser null");
		Borrowable theItem = search(item);
		if (theItem == null) 
		    return false; 
		
		if (theItem.isAvailableToBorrow()==true)
		     return false; 
		
		else{
		theItem.giveBack();
		return true; }
		}
	
	/**
	 * Metodo que devuelve el numero de objetos de la base de datos que tienen propietario
	 * 
	 * @return numero de objetos con propietario
	 */
	public int numberOfItemsOwned() {
		int count = 0;
		for (Item item : items) {
			if (item.getOwn())
				count++;
		}
		return count;
	}

	/**
	 * Metodo que devuelve la suma de los precios de todos los �tems 
	 * 
	 * @return suma de los precios finales
	 */
	public double totalPrice() {
		double count = 0.00;
		for (Item item : items) {
			count = item.getFinalPrice() + count;
		}
		return count;
	}

	/**
	 * Metodo que devuelve el c�digo de todos los �tems de la base de datos unidos por un gui�n
	 * El c�digo ser� una cadena formada por las tres primeras letras
     * del t�tulo y suposici�n en la base de datos
	 */
	public String generateCode() {
		String cad = "";
		for (Item item : items) {
			for (int i = 0; i <= 3; i++) {
				cad = cad + item.getTitle().charAt(i);}
			cad += items.indexOf(item) + "-";}
		return cad;	}

	/**
	 * Metodo que busque en la base de datos un item recibido como par�metro y 
	 * devuelva la posici�n que ocupa o bien -1 si no lo ha encontrado.
	 * @return posicion que ocupa el item recibido
	 * @return -1 si no lo encuentra
	 */
	public int searchItem(Item theItem) {
		if (theItem == null)
			throw new RuntimeException("Error, el par�metro no puede ser null");
		return items.indexOf(theItem);
	}

	/**
	 * Metodo que sume el tiempo asociado a todos los elementos que tiene la base de datos
	 * @return count la suma de los tiempos de todos los items
	 */
	public int gatherAllTime() {
		int count = 0;
		for (Item item : items) {
			count = count + item.getPlayingTime();}
		return count;
	}

	/**
	 * Metodo lista los objetos de la base de datos (llamada a los tostrings de las subclases)
	 *
	 */
	public void list(PrintStream out) {
		for (Item item : items) {
			out.print(item.toString());	}
	}

	/**
	 * Metodo que muestra por pantalla los responsables de los objetos
	 * cd- artista
	 * dvd- director
	 * vg- autor
	 */
	public void printResponsables(PrintStream out) {
		for (Item item : items) {
			if (item.getOwn() == true)
				item.printResponsable(out);	}
	}

	/**
	 *Metodo que compara dos objetos item
	 */
	public Item isEquals(Item item) {
		if (item == null)
			throw new RuntimeException("Error, el par�metro no puede ser null");
		for (Item i : items)
			if (i.equals(item))
				return i;
		return null;

	}

	/**
	 * Metodo que devuelve el tama�o de la coleccion de items
	 * @return tama�o de la coleccion 
	 */
	public int getSize() {
		return items.size();
	}

}
