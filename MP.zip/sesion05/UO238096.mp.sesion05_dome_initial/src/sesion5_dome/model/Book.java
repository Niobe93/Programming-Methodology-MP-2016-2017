package sesion5_dome.model;

import java.io.PrintStream;

/**
 * Title: Book
 * @author Gema Rico Pozas
 * @version 1.0
 * */
public class Book extends Item implements Borrowable {
	
	private String author;
	private String ISBN;
	private String editorial;
	private boolean isAvailable;
	private double basePrice;
	
	/**
	 * Constructor de la clase Book con parametros
	 * @param autor del libro author
	 * @param ISBN (International Standard Book Number)
	 * @param editorial del libro
	 */
	public Book(String title,String author, String ISBN, String editorial,
			    double price,boolean isAvailable) {
		super(title,price);
		setAuthor(author);
		setISBN(ISBN);
		setEditorial(editorial);
		setIsAvailable(isAvailable);}
	
	//GETTERS AND SETTERS
	/**
	* M�todo que  devuelve el atributo autor
	*/
	public String getAuthor() {
		return author;}	
	/**
	* M�todo que  devuelve el atributo finalprice
	*/
	@Override
	public double getFinalPrice() {
		return this.basePrice;}

	/**
	* M�todo que  devuelve el atributo isAvailable
	*/
	public boolean isAvailable() {
		return isAvailable;}
	/**
	* M�todo que  devuelve el atributo ISBN
	*/
	public String getISBN() {
		return ISBN;}
	/**
	* M�todo que  devuelve el atributo editorial
	*/
	public String getEditorial() {
		return editorial;}
	/**
	* M�todo que  modifica el atributo autor
	*/
	protected void setAuthor(String author) {
		if ( author.trim().isEmpty())
			throw new RuntimeException("Error: par�metro incorrecto");
		this.author = author;}
	/**
	* M�todo que  modifica el atributo ISBN
	*/
	protected void setISBN(String ISBN) {
		if ( ISBN.trim().isEmpty())
			throw new RuntimeException("Error: par�metro incorrecto");
		this.ISBN = ISBN;}
	/**
	* M�todo que  modifica el atributo editorial
	*/
	protected void setEditorial(String editorial) {
		if ( editorial.trim().isEmpty())
			throw new RuntimeException("Error: par�metro incorrecto");
		this.editorial = editorial;	}
	/**
	* M�todo que  modifica el atributo baseprice
	*/
	public double getBasePrice() {
		return basePrice;}
	/**
	* M�todo que  modifica el atributo available
	*/
	protected void setIsAvailable(boolean isAvailable) {
		this.isAvailable=isAvailable;}
	/**
	* M�todo que  modifica el atributo baseprice
	*/
	protected void setBasePrice(double basePrice) {
		this.basePrice = basePrice;
	}
		 
    /**
	 *Metodo que devuelve una cadena con la informacion del libro
	 */
	public String toString() {
		String cadena="LIBRO: ";
		cadena += super.toString();
		cadena += ("Author: " + getAuthor()+ "\n");
		cadena +=("ISBN: " + getISBN()+ "\n");
		cadena +=("Editorial: " + getEditorial()+"\n");
		cadena += "\n";
		
		return cadena;}
	
	/**
	 *Metodo que imprime por pantalla el responsable del libro
	 */	
    public void printResponsable(PrintStream out){
    	out.println("Responsable: " + getAuthor());	
	}
	

	/**
	* M�todo que devuelve si el libro esta disponible 
	*/
	@Override
	public boolean isAvailableToBorrow() {
		if (( getOwn() == true)&& (isAvailable()==true))
	        return true; 
		return false;}
	/**
	* M�todo que presta un libro
	*/
	@Override
	public boolean borrow() {
	     boolean previousValue = isAvailable;
	     isAvailable = false;
	     return previousValue; }
	/**
	* M�todo que devuelve un libro
	*/
	@Override
	public void giveBack() {
	     setIsAvailable(true); }

	
	/**
	 *Metodo que compara dos objetos book
	 */
	 @Override
	 public boolean equals(Object item) {
		if (!(item instanceof Book))
			return false;
		Book book = (Book)item;
		return ((book.getTitle().equals(this.getTitle()))
				&& (book.getISBN().equals(this.getISBN())));}

	

}
