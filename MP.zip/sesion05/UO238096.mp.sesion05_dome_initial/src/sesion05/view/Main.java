package sesion05.view;

import sesion5_dome.model.Book;
import sesion5_dome.model.CD;
import sesion5_dome.model.DVD;
import sesion5_dome.model.Database;
import sesion5_dome.model.VideoGame;
import sesion5_dome.model.Platform.Platforms;

/**
 * Clase principal 
 */
public class Main {
	
	/**
	 * Constructor con arg no usados
	 */
	public static void main(String[] args) {
		new Main().run();}
	
	/**
	 * Método run que ejecuta
	 */
	public void run(){
		Database db = new Database();
		db.add(new CD ("Nevermind",10.00, "Nirvana",12,64,true));
		db.add(new CD ("The Queen Is Dead",10.00, "The Smiths",10,51,true));
		db.add(new CD ("A Night at the Opera",10.00, "Queen",12,74,true));	
		db.add(new Book ("El señor de las moscas","William Golding","A25-8512468", "Camelot",14.00, true));
		db.add(new Book ("Cien años de soledad","Gabriel García Márquez","3J5-4216878","Editorial Planeta", 15.00, true));
		db.add(new Book ("Marina","Carlos Ruiz Zafón","125-8512468","Casa del libro", 10.00, true));
		db.addItem(new DVD("Spirited Away",10.00, "‎Hayao Miyazaki",124));
		db.addItem(new DVD ("Into the wild",10.00, "Sean Penn",140));
		db.addItem(new DVD ("Interstellar",10.00, "Christopher Nolan",169));
		db.addItem(new VideoGame ("The last of us",10.00, "‎Naughty Dog",Platforms.PLAYSTATION,1 ));
		db.addItem(new VideoGame ("Halo 5: Guardians",10.00, "‎Microsoft",Platforms.XBOX,24 ));
		db.addItem(new VideoGame ("Super Mario",10.00, "‎Nintendo",Platforms.NINTENDO,2 ));
		
		System.out.println("LISTA ITEMS");
		db.list(System.out);
		System.out.println("LISTA RESPONSABLES");
		db.printResponsables(System.out);		
		System.out.println("LISTA DE OBJETOS PRESTABLES");
		db.listBorrowableItems(System.out);
		System.out.println("LISTA DE OBJETOS PRESTABLES DISPONIBLES");
		db.listAvailableItems(System.out);
		
	}

}
