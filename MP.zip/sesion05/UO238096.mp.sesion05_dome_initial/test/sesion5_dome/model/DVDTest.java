package sesion5_dome.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import sesion5_dome.model.DVD;

public class DVDTest {

	private DVD dvd;
	
	@Before
	public void setUp()
	{
		dvd = new DVD("La guerra de las Galaxias",10.00,"George Lucas",125);
	}

	@Test
	public void testSetTitle() {
		
		// caso 1 introduzco un nombre correcto
		dvd.setTitle("Stars Wars");
		assertEquals("Stars Wars",dvd.getTitle());
		// caso 2 introduzco cadena vacia(espacios en blanco)
		try {
			dvd.setTitle("   ");
			fail();
		} catch (Exception e) {
			assertEquals("Error: par�metro incorrecto", e.getMessage());
				}
	}
	
	@Test
	public void testSetDirector() {
	
		// caso 1 introduzco un nombre correcto
		dvd.setDirector("Jorge Lucas");
		assertEquals("Jorge Lucas",dvd.getDirector());
		// caso 2 introduzco cadena vacia(espacios en blanco)
		try {
			dvd.setDirector("   ");
			fail();
		} catch (Exception e) {
			assertEquals("Error: par�metro incorrecto", e.getMessage());
		}
		
	}
	
	@Test
	public void testSetPlayingTime() {
		
		// caso 1 introduzco un tiempo correcto (positivo)
		dvd.setPlayingTime(126);
		assertEquals(126,dvd.getPlayingTime());
		// caso 2 introduzco tiempo negativo
		try {
			dvd.setPlayingTime(-10);
			fail();
		} catch (Exception e) {
			assertEquals("Error: par�metro incorrecto", e.getMessage());
		}
	}
	
	
	@Test
	public void testSetOwn() {
	
		// caso 1 estando en false paso a true
		dvd.setOwn(true);
		assertEquals(true,dvd.getOwn());
		// caso 2 estando en true paso a false
		dvd.setOwn(false);
		assertEquals(false,dvd.getOwn());
	}
	@Test
	public void testSetComment() {
		
		// caso 1 introduzco un comentario correcto
		dvd.setComment("Excelente");
		assertEquals("Excelente",dvd.getComment());
		// caso 2 introduzco cadena vacia(espacios en blanco)
		try {
			dvd.setComment(" ");
			fail();
		} catch (Exception e) {
			assertEquals("Error: par�metro incorrecto", e.getMessage());
				}
	}
	@Test
	public void testEquals() {
		
		DVD dvd1 = new DVD ("Into the wild",10.00, "Sean Penn",140);
		DVD dvd2 = new DVD ("Interstellar",10.00, "Sean Penn",169);
		
		//CASO 1 comparamos dos objeto DVD diferentes
		assertEquals(false,dvd.equals(dvd1));
		
		//CASO 2 comparamos dos objeto cD iguales
		assertEquals(true, dvd.equals(dvd));
		
		//CASO 3 dos objetos cd que son iguales de director pero diferente titulo
		assertEquals(false, dvd1.equals(dvd2));
		
		//CASO 3 pasamos como par�metro un objeto null
		assertEquals(false, dvd.equals(null));		
	}
	@Test
	public void testToString() {
		String cadena= ("DVD: La guerra de las Galaxias * "+"\n"+
				    "Comment:"+"\n"+
					"Price 10.0"+"\n"+
					"125 mins"+ "\n"+
					"Director: George Lucas"+"\n"+"\n");
	   assertEquals(cadena,dvd.toString());
     }
}
