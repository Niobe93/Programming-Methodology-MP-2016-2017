package sesion5_dome.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class BookTest {
	
	private Book book;

	@Before
	public void setUp() throws Exception {
		book =(new Book ("Cien a�os de soledad","Gabriel Garc�a M�rquez",
				                  "3J5-4216878","Editorial Planeta", 15.00, true));
	}

	@Test
	public void testSetTitle() {
		// caso 1 introduzco un nombre correcto
		book.setTitle("Marina");
		assertEquals("Marina", book.getTitle());
		
		// caso 2 introduzco cadena vacia(espacios en blanco)
		try {
			book.setTitle(" ");
			fail();
		} catch (Exception e) {
			assertEquals("Error: par�metro incorrecto", e.getMessage());
		}}

	@Test
	public void testSetOwn() {

		// caso 1 estando en false paso a true
		book.setOwn(true);
		assertEquals(true, book.getOwn());
		// caso 2 estando en true paso a false
		book.setOwn(false);
		assertEquals(false, book.getOwn());
	}

	@Test
	public void testSetArtist() {

		// caso 1 introduzco un nombre correcto
		book.setAuthor("JK Rowling");
		assertEquals("JK Rowling", book.getAuthor());
	
		// caso 2 introduzco cadena vacia(espacios en blanco)
		try {
			book.setAuthor("    ");
			fail();
		} catch (Exception e) {
			assertEquals("Error: par�metro incorrecto", e.getMessage());
		}
	}
	@Test
	public void testSetComment() {

		// caso 1 introduzco un comentario correcto
		book.setComment("Excelente");
		assertEquals("Excelente", book.getComment());

		// caso 2 introduzco cadena vacia(espacios en blanco)
		try {
			book.setComment("  ");
			fail();
		} catch (Exception e) {
			assertEquals("Error: par�metro incorrecto", e.getMessage());
		}
	}
		
	@Test
	public void testEquals() {
		
		Book book1 = new Book ("Marina","William Golding","A25-8512468", "Camelot",14.00, true);
		Book book2 = new Book ("Marina","Carlos Ruiz Zaf�n","125-8512468","Casa del libro", 10.00, true);
		
		//CASO 1 comparamos dos objeto book diferentes
		assertEquals(false,book.equals(book1));
		
		//CASO 2 comparamos dos objeto cD iguales
		assertEquals(true, book1.equals(book1));
		
		//CASO 3 dos objetos cd que son iguales de titulo pero diferente ISBN
		assertEquals(false, book1.equals(book2));
		
		//CASO 3 pasamos como par�metro un objeto null
		assertEquals(false, book.equals(null));	
	}
	@Test
	public void testToString() {
		String cadena= ("LIBRO: Cien a�os de soledad * "+"\n"+
				    "Comment:"+"\n"+
					"Price 15.0"+"\n"+
					"Author: Gabriel Garc�a M�rquez"+ "\n"+
					"ISBN: 3J5-4216878"+"\n"+
					"Editorial: Editorial Planeta"+"\n"+"\n");
	   assertEquals(cadena,book.toString());
     }
	
	@Test
	public void testIsAvailableToBorrow() {
		//CASO 1 comprobamos que el libro se puede prestar y lo prestamos
		assertEquals(true,book.isAvailableToBorrow());
		book.borrow();
		//CASO 2 comprobamos que el libro ahora esta prestado y por tanto no disponible 
		assertEquals(false,book.isAvailableToBorrow());
		// CASO 3 devolvemos el libro 
		book.giveBack();
		assertEquals(true,book.isAvailableToBorrow());
		//CASO 4 cambiamos el estado de get Own a falso y comprobamos que al no tenerlo en propiedad
		//no podemos darlo prestado
		book.setOwn(false);
		assertEquals(false,book.isAvailableToBorrow());
		
	}
	@Test
	public void testGiveBack() {
		//CASO 1 comprobamos que el libro esta disponible para ser prestado
		assertEquals(true, book.isAvailable());
		// Prestamos el libro
		book.borrow();
		//comprobamos que ahora no esta disponible
		assertEquals(false, book.isAvailable());
		//lo devolvemos con el metodo giveback y comprobamos que vuelve a estar disponible
		book.giveBack();
		assertEquals(true, book.isAvailable());
	}
	
}
