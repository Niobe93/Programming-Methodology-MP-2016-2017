package sesion5_dome.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import sesion5_dome.model.CD;
import sesion5_dome.model.DVD;
import sesion5_dome.model.Database;
import sesion5_dome.model.Item;
import sesion5_dome.model.VideoGame;
import sesion5_dome.model.Platform.Platforms;


public class DatabaseTest {
	private Database db;
	private CD cd;
	private DVD dvd;
	private VideoGame vg;
	private Book book;
	

	@Before
	public void setUp() throws Exception {
		db = new Database();
		cd = new CD("TituloCD1",10.00, "Autor1", 8, 50,true);
		dvd = new DVD("TituloDVD1",10.00, "AutorDVD", 120);
		vg = new VideoGame("Super Mario",10.00, "‎Nintendo",Platforms.NINTENDO,2);
		book=new Book("Marina","Carlos Ruiz Zafón","Editorial Planeta","125-8512468", 10.00, true);
	}

	@Test
	public void testAddItem() {
		// CASO 1 la coleccion está vacía
		assertEquals(0, db.getSize());
		// CASO 2 se añaden varios item
		db.addItem(cd);
		assertEquals(1, db.getSize());
		db.addItem(cd);
		assertEquals(2, db.getSize());
		db.addItem(vg);
		assertEquals(3, db.getSize());
		db.addItem(dvd);
		assertEquals(4, db.getSize());
		db.addItem(book);
		assertEquals(5, db.getSize());
		
		// CASO 3 se añade un item null
		try {
			db.addItem(null);
			fail();
		} catch (Exception e) {
			assertEquals("Error, el parámetro no puede ser null",
					e.getMessage());
		}
	}

	@Test
	public void testNumberOfItemsOwned() {
		// CASO 1 la coleccion está vacía
		assertEquals(0, db.getSize());
		assertEquals(0, db.numberOfItemsOwned());

		// CASO 2 añadimos a la colección un cd que tiene propietario
		cd.setOwn(true);
		db.addItem(cd);
		assertEquals(1, db.numberOfItemsOwned());
		// CASO 2 añadimos a la colección un dvd que tiene propietario
		dvd.setOwn(true);
		db.addItem(dvd);
		assertEquals(2, db.numberOfItemsOwned());
		
		//CASO 3 añadimos un objeto videojuego sin propietario
		vg.setOwn(false);
		db.addItem(vg);
		assertEquals(2, db.numberOfItemsOwned());
		assertEquals(3, db.getSize());	
		
	}

	@Test
	public void testSearchItem() {
		// CASO 1 la coleccion está vacía
		assertEquals(0, db.getSize());
		// CASO 2 añadimos varios objetos
		db.addItem(cd);
		db.addItem(dvd);
		db.addItem(book);
		
		assertEquals(3, db.getSize());
		// CASO 3 pasando como parametro el objeto cd nos tiene que devolver la
		// posicion 0
		assertEquals(0, db.searchItem(cd));
		// CASO 4 pasando como parametro el objeto dvd  y book nos tiene que devolver la
		// posicion 1 y 2
		assertEquals(1, db.searchItem(dvd));
		assertEquals(2, db.searchItem(book));
		// CASO 5 pasando como parametro un objeto que no está en la colección
		Item dvd1 = new DVD("hola",10.00, "gema", 5);
		assertEquals(-1, db.searchItem(dvd1));
		// CASO 6 pasamos un objeto null
		try {
			db.searchItem(null);
			fail();
		} catch (Exception e) {
			assertEquals("Error, el parámetro no puede ser null",
					e.getMessage());
		}

	}
	
	@Test
	public void testGatherAllTime() {
		//CASO 1 probamos el metodo con la colección vacía
		assertEquals(0, db.gatherAllTime());
		//CASO 2 llamamos al metodo despues de añadir un Cd de 50 min y un dvd de 120
		db.addItem(cd);
		db.addItem(dvd);
		assertEquals(170, db.gatherAllTime());
		//CASO 3 llamamos al metodo despues de añadir un Cd de 50 min mas a la coleccion
		db.addItem(cd);
		assertEquals(220, db.gatherAllTime());
		// CASO 4 añadimos un videojuego y un libro que no posee el atributo playing time.
		db.addItem(vg);
		db.addItem(book);
		assertEquals(220, db.gatherAllTime());
				
	}
	
	@Test
	public void testTotalPrice() {
		//CASO 1 añadimos un objeto cd comprobamos que su precio base es 10 y el precio 
		//final seria 10.00+2.00
		db.addItem(cd);
		assertEquals(10.00,0.1,cd.getBasePrice());
		assertEquals(12.00,0.1,db.totalPrice());
		//CASO 2 añadimos un objeto dvd comprobamos que su precio base es igual al final
		//y que la suma total de la coleccion es 22.00
		db.addItem(dvd);
		assertEquals(10.00,0.1,cd.getBasePrice());
		assertEquals(22.00,0.1,db.totalPrice());
		//CASO 3 añadimos un objeto vg comprobamos que su precio base es 10 y el precio 
		//final seria 10.00+10% ,  comprobamos que la suma es correcta
		db.addItem(vg);
		assertEquals(10.00,0.1,cd.getBasePrice());		
		assertEquals(33.00,0.1,db.totalPrice());		
	}

	@Test
	public void testAdd() {
		//CASO 1 comprobamos que se añaden correctamente los items independientemente que sean
		// borrowables o no.
		db.add(book);
		assertEquals(1, db.getSize());
		db.add(vg);
		assertEquals(2, db.getSize());	
		db.add(cd);
		assertEquals(3, db.getSize());	
		db.add(dvd);
		assertEquals(4, db.getSize());		

		// CASO 2 se añade un item null
		try {
			db.add(null);
			fail();
		} catch (Exception e) {
			assertEquals("Error, el parámetro no puede ser null",
					e.getMessage());
		}
	}

	@Test
	public void testGiveBack(){
		//CASO 1 añadimos a la colección dos objetos prestables
		db.add(book);
		db.add(cd);
		assertEquals(2,db.getSize());
		//Llamamos al metodo give back para simular la devolucion de los libros, pero al ser objetos
		//que ya estaban disponibles nos devuelve false
		assertEquals(false,db.giveBack(book));
		assertEquals(false,db.giveBack(cd));
		//CASO 2 cambiamos el estado de disponibilidad a los objetos a prestado y los devolvemos 
		cd.borrow();
		book.borrow();
		assertEquals(true,db.giveBack(cd));
		assertEquals(true,db.giveBack(book));
		//CASO 3 intentamos devolver un objeto null
		try {
			db.giveBack(null);
			fail();
		} catch (Exception e) {
			assertEquals("Error, el parámetro no puede ser null",
					e.getMessage());}
			
	}
	
	@Test
	public void testBorrow(){
		//CASO 1 añadimos a la colección dos objetos prestables no disponibles e intentamos prestarlos
		db.add(book); 
		book.borrow();
		db.add(cd);
		cd.borrow();
		assertEquals(null,db.borrow(cd));
		assertEquals(null,db.borrow(book));
		
		//CASO 2 cambiamos el estado de disponibilidad a los objetos y los prestamos 
		cd.giveBack();
		book.giveBack();
		assertEquals(cd,db.borrow(cd));
		assertEquals(book,db.borrow(book));
	
		//CASO 4 intentamos prestar un objeto null
		try {
		  db.borrow(null);
		  fail();
	}    catch (Exception e) {
		  assertEquals("Error, el parámetro no puede ser null",
		  e.getMessage());}	
	}
	
}