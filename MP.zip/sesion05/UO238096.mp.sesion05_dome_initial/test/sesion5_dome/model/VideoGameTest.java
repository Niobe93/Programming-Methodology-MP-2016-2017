package sesion5_dome.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import sesion5_dome.model.VideoGame;
import sesion5_dome.model.Platform.Platforms;


public class VideoGameTest {
	private VideoGame vg;

	@Before
	public void setUp() throws Exception {
		vg = new VideoGame("The last of us",10.00,"‎Naughty Dog",
				Platforms.PLAYSTATION, 1);
	}

	@Test
	public void testSetNumberOfPlayers() {
		// CASO1 introduzco un número de jugadores limite superior
		vg.setNumberOfPlayers(50);
		assertEquals(50, vg.getNumberOfPlayers());
		// CASO2 introduzco un numero de jugadores correcto
		vg.setNumberOfPlayers(1);
		assertEquals(1, vg.getNumberOfPlayers());
		// CASO2 introduzco un numero de jugadores correcto
		vg.setNumberOfPlayers(20);
		assertEquals(20, vg.getNumberOfPlayers());
		// Pruebas negativas
		// CASO3 introduzco un numero de jugadores 0
		try {
			vg.setNumberOfPlayers(0);
			fail();
		} catch (Exception e) {
			assertEquals("Error: parámetro incorrecto", e.getMessage());
		}
		// CASO4 introduzco un numero de jugadores 60
		try {
			vg.setNumberOfPlayers(60);
			fail();
		} catch (Exception e) {
			assertEquals("Error: parámetro incorrecto", e.getMessage());
		}
		// CASO5 introduzco un numero de jugadores negativos
		try {
			vg.setNumberOfPlayers(-10);
			fail();
		} catch (Exception e) {
			assertEquals("Error: parámetro incorrecto", e.getMessage());
		}
	}

	@Test
	public void testSetAuthor() {
		// CASO1 introduzco un nombre de autor correcto
		vg.setAuthor("Hideo Kojima");
		assertEquals("Hideo Kojima", vg.getAuthor());

		// CASO2 introduzco un nombre de autor null
		try {
			vg.setAuthor(null);
			fail();
		} catch (Exception e) {
			assertEquals("Error: parámetro incorrecto", e.getMessage());
		}

		// CASO3 introduzco un nombre de autor en blanco
		try {
			vg.setAuthor(" ");
			fail();
		} catch (Exception e) {
			assertEquals("Error: parámetro incorrecto", e.getMessage());
		}
	}

	@Test
	public void testSetPlatform() {
		//CASO 1 introduczo un valor de plataforma correcto 
		assertEquals(Platforms.PLAYSTATION ,vg.getPlatform());
		//CASO 2 cambiamos la plataforma y comprobamos que la cambia correctamente
		vg.setPlatform(Platforms.XBOX);
		assertEquals(Platforms.XBOX, vg.getPlatform());
		//CASO 3 cambiamos la plataforma y comprobamos que la cambia correctamente
		vg.setPlatform(Platforms.NINTENDO);
		assertEquals(Platforms.NINTENDO, vg.getPlatform());
		
		// CASO 4 cambiamos la plataforma a un objeto null
		try {
			vg.setPlatform(null);
			fail();
		} catch (Exception e) {
			assertEquals("Error: parámetro incorrecto", e.getMessage());
		}				
	}
	@Test
	public void testEquals() {
		
		VideoGame vg1 = new VideoGame ("Super Mario", 10.00,"‎Microsoft",Platforms.XBOX,24 );
		VideoGame vg2 = new VideoGame ("Super Mario",10.00, "‎Nintendo",Platforms.NINTENDO,2);
		
		//CASO 1 comparamos dos objeto videogame diferentes
		assertEquals(false,vg.equals(vg1));
		
		//CASO 2 comparamos dos objeto videogame iguales
		assertEquals(true, vg.equals(vg));
		
		//CASO 3 dos objetos cd que son iguales de titulo pero diferente plataforma
		assertEquals(false, vg1.equals(vg2));
		
		//CASO 3 pasamos como parámetro un objeto null
		assertEquals(false, vg.equals(null));		
	}
	@Test
	public void testToString() {
		String cadena= ("VIDEOGAME: The last of us * "+"\n"+
				    "Comment:"+"\n"+
					"Price 10.0"+"\n"+
					"Author: ‎Naughty Dog"+"\n"+
					"Plataform: PLAYSTATION"+"\n"+
					"Number of players: 1"+"\n"+"\n");
	   assertEquals(cadena,vg.toString());
	}
}
