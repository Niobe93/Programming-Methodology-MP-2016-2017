package sesion4_dome.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import sesion4_dome.model.CD;

public class CDTest {
	private CD cd;


	@Before
	public void setUp() {
		cd = new CD("Come Together",10.00, "Beatles", 4, 70);
		
	}

	@Test
	public void testSetTitle() {

		// caso 1 introduzco un nombre correcto
		cd.setTitle("Yellow Submarine");
		assertEquals("Yellow Submarine", cd.getTitle());
		
		// caso 2 introduzco cadena vacia(espacios en blanco)
		try {
			cd.setTitle(" ");
			fail();
		} catch (Exception e) {
			assertEquals("Error: par�metro incorrecto", e.getMessage());
		}
		
	}

	@Test
	public void testSetOwn() {

		// caso 1 estando en false paso a true
		cd.setOwn(true);
		assertEquals(true, cd.getOwn());
		// caso 2 estando en true paso a false
		cd.setOwn(false);
		assertEquals(false, cd.getOwn());
	}

	@Test
	public void testSetArtist() {

		// caso 1 introduzco un nombre correcto
		cd.setArtist("John Lennon");
		assertEquals("John Lennon", cd.getArtist());
	
		// caso 2 introduzco cadena vacia(espacios en blanco)
		try {
			cd.setArtist("    ");
			fail();
		} catch (Exception e) {
			assertEquals("Error: par�metro incorrecto", e.getMessage());
		}
	}

	@Test
	public void testSetNumberOfTracks() {

		// caso 1 introduzco un n�mero de pistas correcto
		cd.setNumberOfTracks(50);
		assertEquals(50, cd.getNumberOfTracks());
		// caso 2 introduzco pistas negativas
		try {
			cd.setNumberOfTracks(-10);
			fail();
		} catch (Exception e) {
			assertEquals("Error: par�metro incorrecto", e.getMessage());
		}

	}

	@Test
	public void testSetPlayingTime() {

		// caso 1 introduzco un tiempo correcto (positivo)
		cd.setPlayingTime(10);
		assertEquals(10, cd.getPlayingTime());
		// caso 2 introduzco tiempo negativo
		try {
			cd.setPlayingTime(-10);
			fail();
		} catch (Exception e) {
			assertEquals("Error: par�metro incorrecto", e.getMessage());
		}
	}

	@Test
	public void testSetComment() {

		// caso 1 introduzco un comentario correcto
		cd.setComment("Excelente");
		assertEquals("Excelente", cd.getComment());

		// caso 2 introduzco cadena vacia(espacios en blanco)
		try {
			cd.setComment("  ");
			fail();
		} catch (Exception e) {
			assertEquals("Error: par�metro incorrecto", e.getMessage());
		}
		

	}
	@Test
	public void testEquals() {
		
		CD cd1= new CD ("The Queen Is Dead",10.00, "The Smiths",10,51);
		CD cd2= new CD ("The Queen Is Dead",10.00, "Camela",10,51);
		
		//CASO 1 comparamos dos objeto cD diferentes
		assertEquals(false,cd.equals(cd1));
		
		//CASO 2 comparamos dos objeto cD iguales
		assertEquals(true, cd.equals(cd));
		
		//CASO 3 dos objetos cd que son iguales de titulo pero diferente autor
		assertEquals(false, cd1.equals(cd2));
		
		//CASO 3 pasamos como par�metro un objeto null
		assertEquals(false, cd.equals(null));	
		
	}
	@Test
	public void testToString() {
		String cadena= ("CD: Come Together * "+"\n"+
				    "Comment:"+"\n"+
					"Price 10.0"+"\n"+
					"70 mins"+ "\n"+
					"Artist: Beatles"+"\n"+
					"Tracks: 4"+"\n"+"\n");
	   assertEquals(cadena,cd.toString());
     }
	}
