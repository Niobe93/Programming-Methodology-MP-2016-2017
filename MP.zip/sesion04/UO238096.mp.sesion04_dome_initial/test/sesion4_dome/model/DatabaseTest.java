package sesion4_dome.model;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import sesion4_dome.model.CD;
import sesion4_dome.model.DVD;
import sesion4_dome.model.Database;
import sesion4_dome.model.Item;
import sesion4_dome.model.VideoGame;
import sesion4_dome.model.VideoGame.Platforms;

public class DatabaseTest {
	private Database db;
	private CD cd;
	private DVD dvd;
	private VideoGame vg;

	@Before
	public void setUp() throws Exception {
		db = new Database();
		cd = new CD("TituloCD1",10.00, "Autor1", 8, 50);
		dvd = new DVD("TituloDVD1",10.00, "AutorDVD", 120);
		vg = new VideoGame("Super Mario",10.00, "‎Nintendo",Platforms.NINTENDO,2);

	}

	@Test
	public void testAddItem() {
		// CASO 1 la coleccion está vacía
		assertEquals(0, db.getSize());
		// CASO 2 se añaden varios item
		db.addItem(cd);
		assertEquals(1, db.getSize());
		db.addItem(cd);
		assertEquals(2, db.getSize());
		db.addItem(vg);
		assertEquals(3, db.getSize());
		db.addItem(dvd);
		assertEquals(4, db.getSize());
		
		// CASO 3 se añade un item null
		try {
			db.addItem(null);
			fail();
		} catch (Exception e) {
			assertEquals("Error, el parámetro no puede ser null",
					e.getMessage());
		}
	}

	@Test
	public void testNumberOfItemsOwned() {
		// CASO 1 la coleccion está vacía
		assertEquals(0, db.getSize());
		assertEquals(0, db.numberOfItemsOwned());

		// CASO 2 añadimos a la colección un cd que tiene propietario
		
		db.addItem(cd);
		assertEquals(1, db.numberOfItemsOwned());

		// CASO 2 cambios la condición del propietario al dvd y lo añadimos
		
		db.addItem(dvd);
		assertEquals(2, db.numberOfItemsOwned());
		
		//CASO 3 añadimos un objeto videojuego sin propietario
		vg.setOwn(false);
		db.addItem(vg);
		assertEquals(2, db.numberOfItemsOwned());
		assertEquals(3, db.getSize());	
		
	}

	@Test
	public void testSearchItem() {
		// CASO 1 la coleccion está vacía
		assertEquals(0, db.getSize());
		// CASO 2 añadimos varios objetos
		db.addItem(cd);
		db.addItem(dvd);
		assertEquals(2, db.getSize());
		// CASO 3 pasando como parametro el objeto cd nos tiene que devolver la
		// posicion 0
		assertEquals(0, db.searchItem(cd));
		// CASO 4 pasando como parametro el objeto dvd nos tiene que devolver la
		// posicion 1
		assertEquals(1, db.searchItem(dvd));
		// CASO 5 pasando como parametro un objeto que no está en la colección
		Item dvd1 = new DVD("hola",10.00, "gema", 5);
		assertEquals(-1, db.searchItem(dvd1));
		// CASO 6 pasamos un objeto null
		try {
			db.searchItem(null);
			fail();
		} catch (Exception e) {
			assertEquals("Error, el parámetro no puede ser null",
					e.getMessage());
		}

	}
	
	@Test
	public void testGatherAllTime() {
		//CASO 1 probamos el metodo con la colección vacía
		assertEquals(0, db.gatherAllTime());
		//CASO 2 llamamos al metodo despues de añadir un Cd de 50 min y un dvd de 120
		db.addItem(cd);
		db.addItem(dvd);
		assertEquals(170, db.gatherAllTime());
		//CASO 3 llamamos al metodo despues de añadir un Cd de 50 min mas a la coleccion
		db.addItem(cd);
		assertEquals(220, db.gatherAllTime());
		// CASO 4 añadimos un videojuego que no posee el atributo playing time.
		db.addItem(vg);
		assertEquals(220, db.gatherAllTime());
				
	}
	
	@Test
	public void testTotalPrice() {
		db.addItem(cd);
		assertEquals(10.00,0.1,cd.getBasePrice());
		assertEquals(12.00,0.1,db.totalPrice());
		db.addItem(dvd);
		assertEquals(10.00,0.1,cd.getBasePrice());
		assertEquals(22.00,0.1,db.totalPrice());
		db.addItem(vg);
		assertEquals(10.00,0.1,cd.getBasePrice());		
		assertEquals(33.00,0.1,db.totalPrice());
		
		
		
		
		
		
	}
}