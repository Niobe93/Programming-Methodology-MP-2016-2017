package sesion4_dome.model;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ CDTest.class, DatabaseTest.class, DVDTest.class,
		VideoGameTest.class })
public class AllTests {

}
