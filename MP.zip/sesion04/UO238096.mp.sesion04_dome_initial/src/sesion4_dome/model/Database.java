package sesion4_dome.model;

import java.io.PrintStream;
import java.util.ArrayList;

public class Database {

	private ArrayList<Item> items;

	public Database() {
		this.items = new ArrayList<Item>();
	}

	public void addItem(Item item) {
		if (item == null)
			throw new RuntimeException("Error, el par�metro no puede ser null");
		items.add(item);
	}

	public int numberOfItemsOwned() {
		int count = 0;
		for (Item item : items) {
			if (item.getOwn())
				count++;
		}
		return count;
	}
	public double totalPrice() {
		double count = 0.00;
		for (Item item : items) {
			count=item.getFinalPrice()+count;			
		}
		return count;
	}
	public String generateCode() {
		String cad ="";
		for (Item item : items) {
			for(int i=0; i<=3;i++){
			 cad = cad + item.getTitle().charAt(i);	}
		    cad+=items.indexOf(item)+ "-";}
		
		return cad;}	

	public int searchItem(Item theItem) {
		if (theItem == null)
			throw new RuntimeException("Error, el par�metro no puede ser null");
		return items.indexOf(theItem);
	}

	public int gatherAllTime() {
		int count = 0;
		for (Item item : items) {
		       count = count + item.getPlayingTime();}	
		
		return count;

	}

	public void list(PrintStream out) {
		for (Item item : items) {
			 out.print(item.toString());
		}
	}
	

	public void printResponsables(PrintStream out) {
		for (Item item : items) {
			if (item.getOwn() == true) 
				item.printResponsable(out);	}
	}
	
	public Item isEquals(Item item){
		for(Item i : items)
		    if (i.equals(item))
		    	return i;		
		return null;
		
	}

	public int getSize() {
		return items.size();
	}

}
