package sesion4_dome.model;

import java.io.PrintStream;

public class DVD extends Item {
	private String director;
	private int playingTime;

	public DVD(String theTitle,double theBasePrice, String theDirector, int time) {
		super(theTitle,theBasePrice);
		setDirector(theDirector);
		setPlayingTime(time);
	}

	protected void setDirector(String director) {
		if( director.trim().isEmpty())
			throw new RuntimeException("Error: par�metro incorrecto");

		this.director = director;
	}
	public double getBasePrice() {
		return this.basePrice;
	}
	
	protected void setPlayingTime(int playingTime) {
		if (playingTime < 0)
			throw new RuntimeException("Error: par�metro incorrecto");

		this.playingTime = playingTime;
	}
	public void printResponsable(PrintStream out){
    	out.println("Responsable: " + getDirector());
		
	}
	public int getPlayingTime() {
		return this.playingTime;
	}

	public String getDirector() {
		return this.director;
	}
	@Override
	public boolean equals(Object item) {
		if (!(item instanceof DVD))
			return false;
		DVD dvd = (DVD)item;
		return ((dvd.getTitle().equals(this.getTitle())) && (dvd.getDirector().equals(this.getDirector())));
		   
		   
	}
	public String toString() {
		String cadena="DVD: ";
		cadena += super.toString();
		cadena += (getPlayingTime() + " mins"+ "\n");
		cadena +=("Director: " +getDirector()+ "\n");
		cadena += "\n";
		
		return cadena;
	}

	
	public double getFinalPrice() {
		return this.getBasePrice() ;
	}
}
		
	
