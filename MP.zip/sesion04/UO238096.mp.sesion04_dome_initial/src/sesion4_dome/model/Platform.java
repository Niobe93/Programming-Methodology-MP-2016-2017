package sesion4_dome.model;

public class Platform {
	public enum Platforms {XBOX, NINTENDO, PLAYSTATION};
}
