package sesion4_dome.model;

public class VideoGame extends Item {
	public enum Platforms {XBOX, NINTENDO, PLAYSTATION};
	public final static int MAX_PLAYERS = 50;

	private int numberOfPlayers;
	private String author;
	private Platforms platform;

	public VideoGame(String theTitle,double theBasePrice, String theAuthor, Platforms thePlatform,
																		int thePlayers) {
		super(theTitle,theBasePrice);
		setAuthor(theAuthor);
		setPlatform(thePlatform);
		setNumberOfPlayers(thePlayers);
	}

	protected void setNumberOfPlayers(int numberOfPlayers) {
		if ((numberOfPlayers <=0)| (numberOfPlayers >50))
			throw new RuntimeException("Error: par�metro incorrecto");
		this.numberOfPlayers = numberOfPlayers;
	}

	protected void setAuthor(String author) {
		if ((author == null) | ( author == (" ")))
			throw new RuntimeException("Error: par�metro incorrecto");
		this.author = author;
	}

	protected void setPlatform(Platforms platform) {
		if (platform == null)
			throw new RuntimeException("Error: par�metro incorrecto");
		this.platform = platform;
	}

	public int getNumberOfPlayers() {
		return numberOfPlayers;
	}
	public double getBasePrice() {
		return this.basePrice;
	}
	public double getFinalPrice() {
		return (this.basePrice*0.1)+ this.basePrice;
	}

	public Platforms getPlatform() {
		return platform;
	}

	public String getAuthor() {
		return author;
	}

	public int getPlayingTime() {
		return 0;
	}
	@Override
	public boolean equals(Object item) {
		if (!(item instanceof VideoGame))
			return false;
		VideoGame vg = (VideoGame)item;
		return ((vg.getTitle().equals(this.getTitle())) && (vg.getPlatform().equals(this.getPlatform())));
		     
	}

	public String toString() {
		String cadena="VIDEOGAME: ";
		cadena += super.toString();
		cadena += ("Author: " + getAuthor()+ "\n");
		cadena += ("Plataform: " + getPlatform()+ "\n");
		cadena +=("Number of players: " + getNumberOfPlayers()+ "\n");
		cadena += "\n";
		
		return cadena;
	}

}
