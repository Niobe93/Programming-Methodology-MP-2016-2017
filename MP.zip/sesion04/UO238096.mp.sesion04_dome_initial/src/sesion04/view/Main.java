package sesion04.view;

import sesion4_dome.model.CD;
import sesion4_dome.model.DVD;
import sesion4_dome.model.Database;
import sesion4_dome.model.VideoGame;
import sesion4_dome.model.VideoGame.Platforms;

public class Main {

	public static void main(String[] args) {
		new Main().run();

	}
	public void run(){
		Database db = new Database();
		db.addItem(new CD ("Nevermind",10.00, "Nirvana",12,64));
		db.addItem(new CD ("The Queen Is Dead",10.00, "The Smiths",10,51));
		db.addItem(new CD ("A Night at the Opera",10.00, "Queen",12,74));
		db.addItem(new DVD("Spirited Away",10.00, "‎Hayao Miyazaki",124));
		db.addItem(new DVD ("Into the wild",10.00, "Sean Penn",140));
		db.addItem(new DVD ("Interstellar",10.00, "Christopher Nolan",169));
		db.addItem(new VideoGame ("The last of us",10.00, "‎Naughty Dog",Platforms.PLAYSTATION,1 ));
		db.addItem(new VideoGame ("Halo 5: Guardians",10.00, "‎Microsoft",Platforms.XBOX,24 ));
		db.addItem(new VideoGame ("Super Mario",10.00, "‎Nintendo",Platforms.NINTENDO,2 ));
		
		db.numberOfItemsOwned();
		db.list(System.out);
		db.printResponsables(System.out);
		
	}

}
