package search;

public class Algorithms {


public static int search(Object[] vector, Object object){
	    for (int i = 0 ; i<vector.length; i++){
	    	if (vector[i].equals(object))
	    		return i;}
	    return -1;
	
}

}