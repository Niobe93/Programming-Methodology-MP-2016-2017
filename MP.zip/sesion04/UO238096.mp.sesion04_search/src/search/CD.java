package search;

import java.io.PrintStream;

public class CD extends Item {

	private String artist;
	private int numberOfTracks;
	private int playingTime;
	
	public CD(String theTitle,double theBasePrice, String theArtist, int tracks, int time) {
		super(theTitle,theBasePrice);
		setArtist(theArtist);
		setNumberOfTracks(tracks);
		setPlayingTime(time);
	}

	public void setArtist(String artist) {
		if ( artist.trim().isEmpty())
			throw new RuntimeException("Error: par�metro incorrecto");
		this.artist = artist;
	}
	protected void setPlayingTime(int playingTime) {
		if (playingTime < 0)
			throw new RuntimeException("Error: par�metro incorrecto");

		this.playingTime = playingTime;
	}
	public int getPlayingTime() {
		return this.playingTime;
	}
	public double getBasePrice() {
		return this.basePrice;
	}
	public double getFinalPrice() {
		return  this.basePrice+2.00;
	}

	public void setNumberOfTracks(int numberOfTracks) {

		if (numberOfTracks <= 0)
			throw new RuntimeException("Error: par�metro incorrecto");

		this.numberOfTracks = numberOfTracks;
	}

	public String getArtist() {
		return this.artist;
	}

	public int getNumberOfTracks() {
		return this.numberOfTracks;
	}
    public void printResponsable(PrintStream out){
    	out.println("Responsable: " + getArtist());
		
	}

	public String toString() {
		String cadena="CD: ";
		cadena += super.toString();
		cadena += (getPlayingTime() + " mins"+ "\n");
		cadena +=("Artist: " + getArtist()+ "\n");
		cadena +=("Tracks: " + getNumberOfTracks()+"\n");
		cadena += "\n";
		
		return cadena;
	}

	@Override
	public boolean equals(Object item) {
		if (!(item instanceof CD))
			return false;
		CD cd = (CD)item;
		return ((cd.getTitle().equals(this.getTitle()))
				&& (cd.getArtist().equals(this.getArtist())));
		   
		   
	}
}