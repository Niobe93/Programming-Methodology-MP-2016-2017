package search;

import java.io.PrintStream;

public abstract class Item {

	private String title;
	private boolean gotIt;
	private String comment;
	protected double basePrice;

	public Item() {
		super();
	}

	public Item(String title,double basePrice) {
		super();
		setTitle(title);
		setOwn(true);
		setComment("Comment:");
		setBasePrice(basePrice);
	}

	protected void setTitle(String title) {
		if ((title.trim().isEmpty()))
			throw new RuntimeException("Error: par�metro incorrecto");

		this.title = title;
	}
	protected void setBasePrice(double basePrice) {
		if ((basePrice <0 )| (basePrice>10000))
			throw new RuntimeException("Error: par�metro incorrecto");

		this.basePrice= basePrice;
		}

	protected void setOwn(boolean ownIt) {
		this.gotIt = ownIt;
		}	

	protected void setComment(String comment) {
		if ((comment.trim().isEmpty())){
			throw new RuntimeException("Error: par�metro incorrecto");}

		this.comment = comment;
	}

	protected String getComment() {
		return comment;
	}
	protected double getBasePrice() {
		return basePrice;
	}
	protected boolean getOwn() {
		return gotIt;
	}

	protected String getTitle() {
		return this.title;
	}
	public int getPlayingTime() {
		return 0;
	}
	public void printResponsable(PrintStream out){		
	}
	public abstract double getFinalPrice();

	
	public String toString() {
		String cadena = "";
		cadena= this.getTitle();
		if (getOwn()) {
			cadena += " * " + "\n";
		} else {
			cadena += "\n";
		}
		cadena+= getComment()+"\n"+ "Price " +getBasePrice()+"\n";
		
		return cadena;
	}

	public abstract boolean equals(Object item) ;	
		
	

	
	}

	