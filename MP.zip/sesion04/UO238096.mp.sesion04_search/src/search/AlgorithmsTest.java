package search;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;



public class AlgorithmsTest {
	

	@Before
	public void setUp() throws Exception {
		
	}
	

	@Test
	public void testSearchInteger() {
		Integer[]integers ={1,2,3,4,5,6,7,8,9};
		assertEquals(1,Algorithms.search(integers, 2));
		assertEquals(7,Algorithms.search(integers, 8));
		assertEquals(8,Algorithms.search(integers, 9));
		assertEquals(-1,Algorithms.search(integers, 11));
	}
	@Test
	public void testSearchStrings() {
		String[]strings ={"ABCDEF","Hola","Adios"};
		assertEquals(2,Algorithms.search(strings,"Adios"));
		assertEquals(1,Algorithms.search(strings,"Hola"));
		assertEquals(0,Algorithms.search(strings,"ABCDEF"));
		assertEquals(-1,Algorithms.search(strings,"3"));
		
	}
	@Test
	public void testSearchCD() {
		Object[]cds={new CD("Nevermind",10.00,"Nirvana",12,64),
				 new CD ("The Queen Is Dead",10.00, "The Smiths",10,51)};					
		assertEquals(1,Algorithms.search(cds,new CD("The Queen Is Dead",10.00, "The Smiths",10,51)));
	}
	
}
	

		
		
	

