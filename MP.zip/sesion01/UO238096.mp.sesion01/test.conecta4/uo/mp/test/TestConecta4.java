package uo.mp.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import sesion01.Conecta4;

public class TestConecta4 {
	private Conecta4 tablero;

	@Before
	public void setUp() throws Exception {
		tablero = new Conecta4();
	}

	@Test
	public void testConecta4Play() {
		// CASO 1: Con un bucle jugamos una serie de partidas de modo que el
		// tablero quede lleno ocupando tambien las columnas
		// l�mites 0 y 6 ,y comprobamos que nos devuelve true en todas las
		// jugadas.
		for (int i = 0; i < (tablero.getBoard().length); i++){
			for (int j = 0; j < (tablero.getBoard().length + 1); j++)
				assertEquals(true, tablero.play(j));}	
		
		// CASO 2: teniendo el tablero lleno intenamos jugar una partida 
		// . Por tanto devuelve false
		assertEquals(false,tablero.play(0));
		assertEquals(false,tablero.play(5));
		assertEquals(false,tablero.play(6));

		// CASO 3: Comprobamos que si intentamos jugar con un numero de
		// columna superior al l�mite nos salta la excepcion
		try {
			tablero.play(7);
		} catch (Exception e) {
			assertEquals("Error: el numero de columnas es incorrecto",
					e.getMessage());
		}
		// CASO 4: Comprobamos que si intentamos jugar con un numero de
		// columna inferior al l�mite nos salta la excepcion
		try {
			tablero.play(-1);
		} catch (Exception e) {
			assertEquals("Error: el numero de columnas es incorrecto",
					e.getMessage());
		}
		
	}

	@Test
	public void testWinnerRow() {
        //CASO 1: Llamando al metodo play jugamos de manera que quede un 
		//ganador en fila
		assertEquals(true, tablero.play(0));// turno ganador
		assertEquals(true, tablero.play(6));
		assertEquals(true, tablero.play(1));// turno ganador
		assertEquals(true, tablero.play(6));
		assertEquals(true, tablero.play(2));// turno ganador
		assertEquals(true, tablero.play(6));
		assertEquals(true, tablero.play(3));// mov.ganador
		assertEquals(true, tablero.finished());
	}

	@Test
	public void testWinnerColumn() {
		//CASO 1: Llamando al metodo play jugamos de manera que quede un 
		//ganador en columna
		assertEquals(true, tablero.play(0));
		assertEquals(true, tablero.play(6)); // turno ganador
		assertEquals(true, tablero.play(1));
		assertEquals(true, tablero.play(6)); // turno ganador
		assertEquals(true, tablero.play(2));
		assertEquals(true, tablero.play(6)); // turno ganador
		assertEquals(true, tablero.play(0));
		assertEquals(true, tablero.play(6)); // mov. ganador
		assertEquals(true, tablero.finished());

	}

	@Test
	public void testWinnerDiagonalLeft() {
		//CASO 1: Llamando al metodo play jugamos de manera que quede un 
		//ganador en diagonal empezando por la iquierda
		assertEquals(true, tablero.play(0)); // turno ganador
		assertEquals(true, tablero.play(1));
		assertEquals(true, tablero.play(1)); // turno ganador
		assertEquals(true, tablero.play(2));
		assertEquals(true, tablero.play(2)); // turno ganador
		assertEquals(true, tablero.play(3));
		assertEquals(true, tablero.play(2)); // turno ganador
		assertEquals(true, tablero.play(3));
		assertEquals(true, tablero.play(3)); // turno ganador
		assertEquals(true, tablero.play(6));
		assertEquals(true, tablero.play(3)); // mov. ganador
		assertEquals(true, tablero.finished());

	}
	@Test
	public void testWinnerDiagonalRight() {
		//CASO 1: Llamando al metodo play jugamos de manera que quede un 
		//ganador en diagonal empezando por la derecha
		assertEquals(true, tablero.play(6)); // turno ganador
		assertEquals(true, tablero.play(5));
		assertEquals(true, tablero.play(5)); // turno ganador
		assertEquals(true, tablero.play(4));
		assertEquals(true, tablero.play(4)); // turno ganador
		assertEquals(true, tablero.play(3));
		assertEquals(true, tablero.play(4)); // turno ganador
		assertEquals(true, tablero.play(3));
		assertEquals(true, tablero.play(3)); // turno ganador
		assertEquals(true, tablero.play(0));
		assertEquals(true, tablero.play(3)); // mov. ganador
		assertEquals(true, tablero.finished());

	}
	@Test
	public void testToString() {
		String cadena = ("");
		for (int i = 0; i < tablero.getBoard().length; i++) {			
			  cadena =  cadena + "\n";
			for (int j = 0; j < (7); j++)
				cadena = " " + cadena + tablero.getBoard()[i][j] + " ";}
		
	assertEquals(cadena ,tablero.toString());
		
		
		
	}}


