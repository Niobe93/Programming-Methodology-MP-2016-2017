package sesion01;

/**
 * Clase Conecta4
 */
public class Conecta4 {

	// definici�n de constantes
	public static final char HUECO = '.';
	public static final int COLUMNS = 7;
	public static final int ROWS = 6;

	// definici�n de propiedades
	private char winnerPlayer;// atributo del jugador ganador
	private char currentPlayer; // atributo del jugador actual
	private char[][] board; // matriz del tablero

	/**
	 * Constructor sin parametros de la clase conecta4 Crea un tablero de 6x7,
	 * lo rellena con el caracter '.' y establece quien ser� el primer jugador
	 */
	public Conecta4() {

		board = new char[ROWS][COLUMNS];
		setCurrentPlayer('*');
		for (int i = 0; i < board.length; i++)
			for (int j = 0; j <= (COLUMNS - 1); j++)
				board[i][j] = HUECO;
	}


	/**
	 * Constructor con parametros de la clase conecta4 Crea un tablero con las
	 * dimensiones especificadas por los par�metros, lo rellena con el caracter
	 * '.' y establece quien ser� el primer jugador.
	 * 
	 * @param higt
	 *            - corresponde al numero de filas
	 * @param width
	 *            - corresponde al numero de columnas
	 */
	public Conecta4(int higt, int width) {

		if ((higt <= 0) || (width <= 0))
			throw new RuntimeException(
					"Error: el numero debe ser mayor que cero");
		board = new char[higt][width];
		setCurrentPlayer('*');
		for (int i = 0; i < higt; i++)
			for (int j = 0; j <= (width - 1); j++)
				board[i][j] = HUECO;
	}

	/**
	 * Metodo que devuelve el valor del atributo currentPlayer Devuelve el valor
	 * del atributo currentPlayer (un car�cter (asterisco o suma) indicando el
	 * turno del jugador)
	 * 
	 * @return el jugador actual '*' o '+'
	 */
	public char getCurrentPlayer() {
		return currentPlayer;
	}

	/**
	 * Metodo que simula el turno en el que un jugador introduce una ficha. Si
	 * se puede colocar la ficha se cambia adem�s el turno del jugador.
	 * 
	 * @return true si ha podido colocar con �xito la ficha
	 * @return false si NO ha podido colocar con �xito la ficha
	 */
	public boolean play(int column) {

		if ((column < 0) || (column >= COLUMNS))
			throw new RuntimeException(
					"Error: el numero de columnas es incorrecto");

		if (isHole(column) == true) {
			insertPiece(column);
			changeCurrentPlayer();
			return true;
		}

		return false;
	}

	/**
	 * Metodo que indica si se ha llegado o no al final de la partida. Es el
	 * final de la partida cuando hay un ganador o ya no hay m�s huecos en el
	 * tablero para colocar fichas. Habr� un jugador ganador si al examinar las
	 * filas, columnas o diagonales se encuentran cuatro iguales consecutivas.
	 * 
	 * @return true si el tablero est� completo o hay un jugador ganador
	 * @return false en caso contrario
	 * 
	 */
	public boolean finished() {
		if ((this.fullBoard() == true) | (this.isWinner() == true))
			return true;

		return false;
	}

	/**
	 * Metodo que determina quien es el jugador ganador o si quedaron en tablas
	 * 
	 * @return un caracter representando la ficha del ganador o el caracter
	 *         hueco indicando que hubo tablas
	 */
	public char winner() {

		if (this.isWinner() == true) {
			this.changeCurrentPlayer();
			setWinnerPlayer(getCurrentPlayer());
			return getWinnerPlayer();
		} else
			return HUECO;
	}

	/**
	 * Metodo que devuelve una cadena de texto con la informaci�n del tablero
	 * por l�neas con el siguiente formato . . . . . . . . . . . . . . . . . . +
	 * . * * . *
	 * 
	 */
	public String toString() {

		String cadena = ("");
		for (int i = 0; i < board.length; i++) {			
			  cadena =  cadena + "\n";
			for (int j = 0; j <= (COLUMNS - 1); j++)
				cadena = " " + cadena + board[i][j] + " ";
		}

		return cadena;
	}

	/**
	 * M�TODOS PRIVADOS
	 * 
	 * 
	 * /** Metodo que determina si queda alg�n hueco libre en el tablero o est�
	 * lleno completamente
	 * 
	 * @return true si no queda ningun hueco libre
	 * @return false si queda hueco libre
	 */
	private boolean fullBoard() {

		for (int j = 0; j < COLUMNS; j++) {
			if (board[0][j] == HUECO)
				return false;
		}
		return true;
	}

	/**
	 * Metodo que determina si hay alg�n ganador examinado las fichas colocadas
	 * en las filas, columnas o diagonales
	 * 
	 * @return true si hay alg�n ganador
	 * @return false si no hay ganador
	 */
	private boolean isWinner() {

		if ((this.isWinnerColumn() == true) || (this.isWinnerRow() == true)
				|| (this.isWinnerDiagonal() == true))
			return true;
		return false;
	}

	/**
	 * Metodo que determina si hay alg�n ganador examinado las fichas colocadas
	 * en las filas
	 * 
	 * @return true si hay alg�n ganador
	 * @return false si no hay ganador
	 */
	private boolean isWinnerRow() {

		int contador = 1;

		for (int i = (board.length - 1); i >= 0; i--) {
			contador = 1;
			for (int j = 0; j < COLUMNS; j++) {
				if (board[i][j] != HUECO)
					if (j + contador < (COLUMNS - 3)) {
						while ((contador < 5)
								&& (board[i][j + contador] == board[i][j]))
							contador++;
					}
				if (contador >= 4)
					return true;
			}
		}

		return false;
	}

	/**
	 * Metodo que determina si hay ganador examinado las fichas colocadas en las
	 * diagonales
	 * 
	 * @return true si hay alg�n ganador
	 * @return false si no hay ganador
	 */
	private boolean isWinnerDiagonal() {

		int contador = 1;
		// Bucle que recorre la matriz de izquierda a derecha
		for (int i = (board.length - 1); i > 2; i--) {
			contador = 1;
			for (int j = 0; j < (COLUMNS - 3); j++) {
				if (board[i][j] != HUECO) {
					while ((contador < 5)
							&& (board[i - contador][j + contador] == board[i][j]))
						contador++;
				}
				if (contador >= 4)
					return true;
			}
		}

		// Bucle que recorre la matriz de derecha a izquierda
		for (int i = (board.length - 1); i > 2; i--) {
			contador = 1;
			for (int j = (COLUMNS - 1); j > 2; j--) {
				if (board[i][j] != HUECO) {
					while ((contador < 5)
							&& (board[i - contador][j - contador] == board[i][j]))
						contador++;
				}
				if (contador >= 4)
					return true;
			}
		}

		return false;
	}

	/**
	 * Metodo que determina si hay alg�n ganador examinado las fichas colocadas
	 * en las columnas
	 * 
	 * @return true si hay alg�n ganador
	 * @return false si no hay ganador
	 */
	private boolean isWinnerColumn() {

		int contador = 1;
		for (int j = 0; j < COLUMNS; j++) {
			contador = 1;
			for (int i = (board.length - 1); i > 0; i--) {
				if (board[i][j] != HUECO)
					if (i + contador > 2) {
						while ((contador < 5)
								& (board[i - contador][j] == board[i][j]))
							contador++;
					}
				if (contador == 4)
					return true;
			}
		}

		return false;
	}

	/**
	 * Metodo que cambia el turno del jugador
	 * 
	 * 
	 */
	private void changeCurrentPlayer() {

		if (getCurrentPlayer() == '*')
			setCurrentPlayer('+');
		else
			setCurrentPlayer('*');

	}

	/**
	 * Metodo que simula el proceso de introducir una ficha hasta el final del
	 * tablero o hasta encontrar otra ficha
	 * 
	 * @param column
	 * @return false si no se pudo colocar la ficha
	 * @return true si se pudo colocar una ficha en la columna indicada
	 */
	private boolean insertPiece(int column) {

		if ((column < 0) || (column > (COLUMNS)))
			throw new RuntimeException("Error");

		for (int i = (board.length - 1); i >= 0; i--) {
			if (board[i][column] == HUECO) {
				board[i][column] = getCurrentPlayer();
				return true;
			}
		}

		return false;
	}

	/**
	 * Metodo que determina si se puede colocar una ficha en el tablero
	 * 
	 * @param column
	 * @return false si no se puede colocar una ficha en la columna
	 * @return true si a�n se puede colocar una ficha en la columna
	 */
	private boolean isHole(int column) {

		if (board[0][column] != HUECO)
			return false;
		return true;
	}

	/**
	 * Metodo que modifica el valor del atributo currentplayer
	 * 
	 * @param currentPlayer
	 */
	private void setCurrentPlayer(char currentPlayer) {
		this.currentPlayer = currentPlayer;
	}

	/**
	 * Metodo que modifica el valor del atributo winnerplayer
	 * 
	 * @param winnerPlayer
	 */
	private void setWinnerPlayer(char winnerPlayer) {
		this.winnerPlayer = winnerPlayer;
	}

	/**
	 * Metodo que devuelve el valor del atributo winnerPlayer
	 * 
	 * @return winnerPlayer
	 */
	public char getWinnerPlayer() {
		return winnerPlayer;
	}
	/**
	 * Metodo que devuelve la matriz
	 * @return el tablero creado
	 */
	public char[][] getBoard() {
			return board;
		}
}
