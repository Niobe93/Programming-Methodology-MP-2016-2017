package uo238096.sesion09.stack;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import uo238096.sesion09.stack.ListStack;

/**
 * Title: ListStackTest
 * 
 * @author Gema Rico Pozas
 * @version 1.0
 */
public abstract class ListStackTest<T> {

	@SuppressWarnings("rawtypes")
	private ListStack list;

	@Before
	public void setUp() {
		list = createList();

	}

	@SuppressWarnings("rawtypes")
	protected abstract ListStack createList();

	@SuppressWarnings("unchecked")
	@Test
	public void pushTest() {
		// CASO 1 llamamos al metodo push y apilamos un objeto, comprobando que
		// el tama�o de la
		// coleccion crece y que el objeto a que apunta peek( cima de la pila)
		// es correcto
		list.push(1);
		assertEquals(1, list.peek());
		assertEquals(1, list.size());
		// CASO 2 llamamos al metodo push y apilamos un objeto, comprobando que
		// el tama�o de la
		// coleccion crece y que el objeto a que apunta peek( cima de la pila)
		// es correcto
		list.push(2);
		assertEquals(2, list.size());
		assertEquals(2, list.peek());
		// CASO 3 llamamos al metodo push y apilamos un objeto, comprobando que
		// el tama�o de la
		// coleccion crece y que el objeto a que apunta peek( cima de la pila)
		// es correcto
		list.push(3);
		assertEquals(3, list.size());
		assertEquals(3, list.peek());
		// CASO 4 desapilamos un objeto ( LIFO --> deber�a salir el ultimo que
		// ha entrado)
		list.pop();
		assertEquals(2, list.size());
		assertEquals(2, list.peek());
		list.pop();
		// CASO 5 desapilamos un objeto ( LIFO --> deber�a salir el ultimo que
		// ha entrado)
		assertEquals(1, list.size());
		assertEquals(1, list.peek());
		// CASO 6 provamos con un objeto null
		try {
			list.push(null);
			fail();
		} catch (Exception e) {
			assertEquals("Error el par�metro no puede ser null", e.getMessage());
		}

	}

	@SuppressWarnings("unchecked")
	@Test
	public void peekTest() {
		// CASO 1 llamamos al metodo push y apilamos varios objetos, comprobando
		// que el tama�o de la
		// coleccion crece y que el objeto a que apunta peek( cima de la pila)
		// es correcto
		list.push("H");
		list.push("o");
		list.push("l");
		list.push("a");
		assertEquals(4, list.size());
		assertEquals("a", list.peek());
		// CASO 2 desapilamos un objeto ( LIFO --> deber�a salir el ultimo que
		// ha entrado) y por tanto
		// peek apunta al suguente el la lista
		list.pop();
		assertEquals("l", list.peek());
		// CASO 3 desapilamos un objeto ( LIFO --> deber�a salir el ultimo que
		// ha entrado) y por tanto
		// peek apunta al suguente el la lista
		list.pop();
		assertEquals("o", list.peek());
		// CASO 4 desapilamos con la lista vac�a
		list.pop();
		list.pop();
		assertEquals(null, list.peek());

	}

	@SuppressWarnings("unchecked")
	@Test
	public void popTest() {
		// CASO 1 llamamos al metodo push y apilamos varios objetos, comprobando
		// que el tama�o de la
		// coleccion crece
		list.push("H");
		list.push("o");
		list.push("l");
		list.push("a");
		assertEquals(4, list.size());
		// CASO 2 llamamos al metodo pop y desapilamos varios objetos,
		// comprobando que el tama�o de la
		// coleccion decrece
		list.pop();
		list.pop();
		assertEquals(2, list.size());
		assertEquals("o", list.peek());
		// CASO 3 desapilamos con la lista vac�a
		list.pop();
		list.pop();// lista vacia
		assertEquals(null, list.pop());

	}
}
