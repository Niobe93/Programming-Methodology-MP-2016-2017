package uo238096.sesion09.stack;

import uo238096.sesion09.stack.ArrayListStack;
import uo238096.sesion09.stack.ListStack;

/**
 * Title: ArrayListStacktest
 * 
 * @author Gema Rico Pozas
 * @version 1.0
 */
public class ArrayListStackTest<T> extends ListStackTest<T> {

	@SuppressWarnings("rawtypes")
	@Override
	protected ListStack createList() {
		return new ArrayListStack();
	}

}
