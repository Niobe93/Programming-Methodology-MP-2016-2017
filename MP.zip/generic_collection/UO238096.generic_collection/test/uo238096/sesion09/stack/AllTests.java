package uo238096.sesion09.stack;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ ArrayListStackTest.class, LinkedListStackTest.class })
public class AllTests {

}
