package uo238096.sesion09.queue;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ ArrayListQueueTest.class, LinkedListQueueTest.class })
public class AllTests {

}
