package uo238096.sesion09.queue;

import uo238096.sesion09.queue.ArrayListQueue;
import uo238096.sesion09.queue.ListQueue;

/**
 * Title: ArrayListQueuetest
 * 
 * @author Gema Rico Pozas
 * @version 1.0
 */
public class ArrayListQueueTest<T> extends ListQueueTest<T> {

	@SuppressWarnings("rawtypes")
	@Override
	protected ListQueue createList() {
		return new ArrayListQueue();
	}

}
