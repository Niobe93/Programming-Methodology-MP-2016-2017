package uo238096.sesion09.collections;

import uo238096.sesion09.collections.ArrayList;
import uo238096.sesion09.collections.List;

/**
 * Title: ArrayListtest
 * 
 * @author Gema Rico Pozas
 * @version 1.0
 */
public class ArrayListTest<T> extends ListTest<T> {

	@SuppressWarnings("rawtypes")
	@Override
	protected List createList() {
		return new ArrayList();
	}

}
