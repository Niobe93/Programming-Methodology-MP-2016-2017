package uo238096.sesion09.collections;

import java.util.Iterator;

/**
 * Title: ArrayList
 * 
 * @author Gema Rico Pozas
 * @version 1.0
 */

public class ArrayList<T> implements List <T> {

	private final static int INITIAL_CAPACITY = 20;
	private Object[] elements;
	private int numberOfElements;

	public ArrayList(int capacity) {
		elements = new Object[capacity];
		numberOfElements = 0;
	}

	public ArrayList() {
		this(INITIAL_CAPACITY);
	}

	@SuppressWarnings("unchecked")
	@Override
	public Iterator<T> iterator() {
		return (Iterator<T>) new ArrayListIterator();
	}

	@Override
	public boolean contains(T o) {
		return false;
	}

	@Override
	public int size() {
		return numberOfElements;
	}

	@Override
	public boolean isEmpty() {
		if (this.size() == 0)
			return true;
		else
			return false;
	}

	@Override
	public void add(T element) {
		if (size() >= elements.length)
			moreMemory(size() + 1);
		elements[size()] = element;
		numberOfElements++;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("[");
		if (this.isEmpty() == false) {
			for (int i = 0; i < size() - 1; i++) {
				sb.append(elements[i].toString()).append(", ");
			}
			sb.append(elements[size() - 1].toString());
		}
		sb.append("]");
		return sb.toString();
	}

	@Override
	public int hashCode() {
		int position = 0;
		int hashCode = 1;
		for (Object e = elements[0]; e != null; e = elements[position + 1])
			hashCode = 31 * hashCode + (e == null ? 0 : e.hashCode());
		return hashCode;
	}

	@Override
	public boolean equals(Object o) {
		if (o == this)
			return true;
		if (!(o instanceof List))
			return false;
		@SuppressWarnings("rawtypes")
		List other = (List) o;
		if (this.size() != other.size())
			return false;

		for (int i = 0; i < size() - 1; i++) {
			if (!(elements[i].equals(other.get(i)))) {
				return false;
			}
		}

		return true;
	}

	@Override
	public T remove(T element) {
		checkElement(element);
		checkState();
		int position = this.indexOf(element);
		if (position != -1)
			return this.remove(position);
		return null;
	}

	@Override
	public void clear() {
		elements = null;
		numberOfElements = 0;
	}

	@Override
	public void add(int index, T element) {
		if (size() >= elements.length)
			moreMemory(size() + 1);
		for (int i = size(); i > index; i--)
			elements[i] = elements[i - 1];
		elements[index] = element;
		numberOfElements++;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T remove(int index) {
		if ((index < 0) | index > this.size())
			throw new RuntimeException("Error el par�metro es incorrecto");
		Object value = elements[index];
		for (int j = index; j < size() - 1; j++)
			elements[j] = elements[j + 1];
		numberOfElements--;
		return (T) value;
	}

	@Override
	public int indexOf(Object o) {
		int position = 0;
		while (position < size()) {
			if (elements[position].equals(o))
				return position;
			position++;
		}
		return -1;
	}

	@SuppressWarnings("unchecked")
	@Override
	public T get(int index) {
		return (T) elements[index];
	}

	@Override
	public T set(int index,T element) {
		elements[index] = element;
		return element;
	}

	private void moreMemory(int numElem) {
		if (numElem > elements.length) {
			Object[] aux = new Object[Math.max(numElem, 2 * elements.length)];
			System.arraycopy(elements, 0, aux, 0, elements.length);
			elements = aux;
		}
	}

	private void checkElement(T object) {
		if (object == null)
			throw new IllegalArgumentException(
					"Error el par�metro no puede ser null");
	}

	private void checkState() {
		if (isEmpty())
			throw new IllegalStateException("Error la lista esta vacia");
	}

	// implementaciobn de iterador

	private class ArrayListIterator implements Iterator<Object> {

		private int next = 0;
		@SuppressWarnings("rawtypes")
		private ArrayList list = new ArrayList();

		@Override
		public boolean hasNext() {
			if (next < list.size())
				return true;
			else
				return false;
		}

		@SuppressWarnings("unchecked")
		@Override
		public T next() {
			return (T) list.get(next++);
		}
	}

	@Override
	public void addFirst(T element) {
		this.checkElement(element);
		this.add(0, element);
	}

}
