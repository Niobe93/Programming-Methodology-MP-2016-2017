package uo238096.sesion09.queue;

import uo238096.sesion09.collections.LinkedList;

/**
 * Title: LinkedListQueue
 * 
 * @author Gema Rico Pozas
 * @version 1.0
 */

@SuppressWarnings("rawtypes")
public class LinkedListQueue <T> extends ListQueue implements Queue<T>{

	public LinkedListQueue() {
		super(new LinkedList());
	}
}
