package uo238096.sesion09.queue;

import uo238096.sesion09.collections.ArrayList;

/**
 * Title: ArrayListQueue
 * 
 * @author Gema Rico Pozas
 * @version 1.0
 */
@SuppressWarnings("rawtypes")
public class ArrayListQueue<T> extends ListQueue implements Queue<T> {

	
	public ArrayListQueue() {
		super(new ArrayList());
	}

	
}
