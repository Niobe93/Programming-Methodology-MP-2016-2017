package uo238096.sesion09.queue;

import uo238096.sesion09.collections.List;

/**
 * Title: ListQueue
 * 
 * @author Gema Rico Pozas
 * @version 1.0
 */
public class ListQueue<T> {
	@SuppressWarnings("rawtypes")
	private List list;

	@SuppressWarnings("rawtypes")
	public ListQueue(List list) {
		this.list = list;
	}

	/**
	 * A�ade un objeto en la parte posterior (final) de la cola
	 * 
	 * @param element
	 *            El elemento a a�adir
	 */
	@SuppressWarnings("unchecked")
	public void enqueue(T element) {
        this.checkElement(element);
		list.add(element);
	}

	/**
	 * Devuelve el objeto de la parte delantera (inicio) de la cola sin quitarlo
	 * 
	 * @return El elemento de la parte delantera (inicio) de la cola
	 */
	@SuppressWarnings("unchecked")
	public T peek() {
		if (isEmpty())
			return null;

		return (T) list.get(0);
	}

	/**
	 * Borra y devuelve un objeto de la parte delantera (inicio) de la cola
	 * 
	 * @return El elemento borrado
	 */
	@SuppressWarnings("unchecked")
	public T dequeue() {

		if (isEmpty())
			return null;
		return (T) list.remove(0);
	}

	/**
	 * Devuelve el n�mero de elementos de la cola
	 * 
	 * @return El n�mero de elementos de la cola
	 */
	public int size() {
		return list.size();
	}

	/**
	 * Indica si la cola est� vac�a o no
	 * 
	 * @return true si la cola est� vac�a ; false en caso contrario.
	 */
	public boolean isEmpty() {
		if (this.size() == 0)
			return true;
		else
			return false;
	}
	
	private void checkElement(T object) {
		if (object == null)
			throw new IllegalArgumentException(
					"Error el par�metro no puede ser null");
	}

}
