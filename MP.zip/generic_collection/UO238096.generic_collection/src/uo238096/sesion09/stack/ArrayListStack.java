package uo238096.sesion09.stack;

import uo238096.sesion09.collections.ArrayList;

/**
 * Title: ArrayListStack
 * 
 * @author Gema Rico Pozas
 * @version 1.0
 */

public class ArrayListStack<T> extends ListStack<T> implements Stack<T> {
	
	@SuppressWarnings("rawtypes")
	public ArrayListStack() {
		super(new ArrayList());

	}

}