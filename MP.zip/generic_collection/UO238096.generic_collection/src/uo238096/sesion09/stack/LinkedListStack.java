package uo238096.sesion09.stack;

import uo238096.sesion09.collections.LinkedList;

/**
 * Title: LinkedListStack
 * 
 * @author Gema Rico Pozas
 * @version 1.0
 */

@SuppressWarnings("rawtypes")
public class LinkedListStack<T> extends ListStack<T> implements Stack<T> {

	public LinkedListStack() {
		super(new LinkedList());

	}
}